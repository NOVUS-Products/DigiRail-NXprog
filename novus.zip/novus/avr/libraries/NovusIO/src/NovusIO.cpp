/* ---------.---------.---------.---------.---------.---------.---------.
 * ESTA É A BIBLIOTECA BÁSICA DESENVOLVIDA PARA CONFIGURAÇÃO E CONTROLE 
 * DOS CANAIS DO MIXIO. A PARTIR DELA É POSSIVEL CONFIGURAR TODOS OS
 * MODOS DE ENTRADA/SAIDA ANALOGICOS/DIGITAIS DO MIXIO, BEM COMO REALIZAR
 * A LEITURA E A ESCRITA DOS VALORES DOS CANAIS.
 *
 * BASICAMENTE, AQUI FAZEMOS USO DA BIBLIOTECA INTERNCOMMUNICATION, ENVIANDO
 * OS PDUs MODBUS PARA O RENESAS. OS VALORES DE LEITURA FICAM ARMAZENADOS DENTRO
 * DA ESTRUTURA 'RES.VALOR' E, CASO ALGUM ERRO OCORRA, ELE ESTARÁ DISPONÍVEL NA 
 * ESTRUTURA 'RES.ERRO'.
 *
 *    As funções:
 *--- analogRead
 *--- analogWrite
 *--- digitalWrite
 *--- digitalRead
 *--- digitalReadCounter
 *--- digitalReadTimer
 *
 * Realizam a leitura e escrita dos canais, sendo que as de leitura retornam o valor
 * desejado. 
 *
 * TODO: MELHORAR A LÓGICA DO NUMERO DE CASAS DECIMAIS DA LEITURA ANALÓGICA. FUNCIONA
 * BEM PARA TEMPERATURA, JÁ QUE É FIXO EM 1 CASA DECIMAL. PARA ENTRADAS LINEARES QUE 
 * UTILIZAM ESCALA DE ENGENHARIA, PODEM OCORRER COMPORTAMENTOS INESPERADOS.....
 *
 *
 * As demais funções realizam a configuração dos canais. Para cada uma, há um comentario
 * com seu funcionamento dentro de sua declaração.
 * Cabe lembrar que após a utilização de qualquer função de configuração, é necessario 
 * enviar um applyConfig.
 *
 */

#include "NovusIO.h"
#include <Arduino.h>


/* --------------------------------------------------------------------------------------
 *								     IO Manipulating
 * -------------------------------------------------------------------------------------- */
float NovusClass::analogRead(int pin)
{
	uint32_t ret=0;
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)(Modbus.AI_READ_LO+2*(pin-1)),1,0);
	Modbus.Check_Error();
	ret=VALOR;
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)(Modbus.AI_READ_HI+2*(pin-1)),1,0);
	ret=ret|(((uint32_t)VALOR)<<16);
	Modbus.Check_Error();
	if(anCFG[pin][0]>9)
	{ //Linear input
		//Todo: adicionar aqui alguma lógica que dependa do Scale do usuário...
//		return (((float)ret)/(DECIMAL*10.0)); // retorna o valor em float, dependendo do numero de casas decimais.
		return (ret); // retorna o número de contagens do conversor AD
	}
	else
	{ //Temperature input. Always use just 1 decimal point
		return (((float)ret)/(10.0));
	}
}

void NovusClass::analogWrite(int pin, float value)
{		
	uint16_t u16value = 0;
	
	//Mapping the value into a 0~32000bits range
	//This range is set in analogOutput_Modefunction
	if (aoCFG[pin-1] == _0_20mA) 
	{
		u16value  = map(value*100, 0, 2000, 0, 32000);
	}
	else if (aoCFG[pin-1] == _4_20mA) 
	{
		u16value  = map(value*100, 400, 2000, 0, 32000);
	}
	else if (aoCFG[pin-1] == _0_10V) 
	{
		u16value  = map(value*100, 0, 1000, 0, 32000);
	}
	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)(Modbus.AO_VALUE+(pin-1)),1,&u16value);
	Modbus.Check_Error();
}

int NovusClass::digitalRead(int pin)
{
	/*
	* Reads value in digital Input Channel, when it's  set as Instant (LOGIC) Value.
	*/
	int value =0;
	Modbus.Send(FUNC_READSINGLE,(uint16_t)(Modbus.DI_STATE-1+pin),1,0);
	Modbus.Check_Error();
	
	
    return VALOR;
}

int NovusClass::digitalReadCounter(int pin)
{
	/*
	* Reads Counter value for digital Input Channel, when it's  set as a Counter.
	*/
	
	uint32_t ret=0;

	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)(Modbus.DI_COUNTER_LO+2*(pin-1)),1,0);
	ret=VALOR;
	Modbus.Check_Error();
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)(Modbus.DI_COUNTER_HI+2*(pin-1)),1,0);
	ret=ret|(((uint32_t)VALOR)<<16);
	
	Modbus.Check_Error();
    return ret;
}

int NovusClass::digitalReadTimer(int pin, int onoff)
{
	/*
	  Read timer register if digital input mode is set as Timer Counter.
	  pin: channel
	  onoff: [0] Time in OFF state, [1] Time in ON state
	
	*/
	// todo: testar e melhorar comentario
	// todo: read timer da entrada digital NÃO funciona (problema renesas)
	uint32_t ret=0;
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)((onoff == 1 ? Modbus.DI_TIMEON_LO : Modbus.DI_TIMEOFF_LO)+2*(pin-1)),1,0);
	ret=VALOR;
	Modbus.Check_Error();
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)((onoff == 1 ? Modbus.DI_TIMEON_HI : Modbus.DI_TIMEOFF_HI)+2*(pin-1)),1,0);
	ret=ret|(((uint32_t)VALOR)<<16);
	
	Modbus.Check_Error();
    return ret;
}

void NovusClass::digitalWrite(int pin, int value)
{
	/*
	* Writes value in digital output Channel, when it's  set as Instant Value.
	* Also, writing 1 in channel starts pulse train, when pin is set as Pulse Train.
	*/
	
	uint16_t config[1]={value};

	
    Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.DO_VALUE-1)+pin),1,&config[0]);
	Modbus.Check_Error();
}

/* --------------------------------------------------------------------------------------
 *								  Analog IO configurations	
 * -------------------------------------------------------------------------------------- */
void NovusClass::analogOutput_Mode(int pin, int type, float powerON, float safeState) 
{
	/* Configure a pin (channel) as Analog Output
	   type: 0-20mA [0], 4-20mA [1],  0-10V [2]. See documentation
	   powerON: Value set after power on
	   safeState: Value set if error detected
	*/

	uint16_t config[6]={0};
	int pON = powerON;
	int safe = safeState;
	

	config[0]=1; //Enable
	if ((type == _0_20mA)||(type == 0))
	{
		config[1]=0; //Type (0-20mA)
		aoCFG[pin-1] = _0_20mA;
	}
	else if ((type == _4_20mA)||(type == 1))
	{
		config[1]=1; //Type (4-20mA)
		aoCFG[pin-1] = _4_20mA;
		
	}
	else if ((type == _0_10V)||(type == 2))
	{
		config[1]=2; //Type (4-20mA)
		aoCFG[pin-1] = _0_10V;
	}
	config[2]=1; // keep range fixed in 0 to 32k	
	if(pON==0)
	{
		config[3]=0;//pON state is off
	}
	else
	{
		config[3]=1;//pON state is a configured value	
	}
	config[4]=pON; //pON value
	config[5]=safe; //Safe value
	
	
	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.AO_ENABLE)+(50*(pin-1))),1,&config[0]); //enable port	
	Modbus.Check_Error();
	
	Modbus.Send(FUNC_WRITEMULTIPLE,(uint16_t)((Modbus.AO_TYPE)+(50*(pin-1))),2,&config[1]); //Send Type and Range	
	Modbus.Check_Error();
	
	Modbus.Send(FUNC_WRITEMULTIPLE,(uint16_t)((Modbus.AO_PON_STATE)+(50*(pin-1))),3,&config[3]); //Send Pon State, Pon Value and Safe
	Modbus.Check_Error();
	
}

void NovusClass::analogInput_Mode(int pin, int type, int temp, float safeState) //tempo = C ou F
{
	/* Configure a pin (channel) as analog Input
	   Type: Termopar, PT, 0-10V, 0-20mA, etc. See documentation
	   Temp: CELCIUS (0) OR FAHRENHEIT (1)
	   safeState: Value if error detected
	*/
	uint16_t config[5]={0};
	int safe = safeState;


	config[0]=1; // Enable 
	config[1]=type; // Type of input
	config[2]=temp; //temperature unit
	config[3]=(safe & 0xFF); //Safe value Low byte 
	config[4]=safe>>8;; //Safe value High Byte
	
	
	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.AI_ENABLE)+(50*(pin-1))),1,&config[0]); //enable port
	Modbus.Check_Error();
	
	Modbus.Send(FUNC_WRITEMULTIPLE,(uint16_t)((Modbus.AI_TYPE)+(50*(pin-1))),2,&config[1]); //Send Type and temperature
	Modbus.Check_Error();
	
	Modbus.Send(FUNC_WRITEMULTIPLE,(uint16_t)((Modbus.AI_SAFE_VALUE_LO)+(50*(pin-1))),2,&config[3]); //Send Safe Value
	Modbus.Check_Error();
	
	switch (type)
	{ //For linear inputs it's needed to set a scale value.	
		//Todo: testar o funcionamento dos mV e mA... para 0-10V ta ok.
		case NTC: //ntc
			analogInput_enScale(pin,0,100*DECIMAL);
			break;
		case _0_60mV: //0-60mV
			analogInput_enScale(pin,0,600*DECIMAL);
			break;
		case _0_5V: //0-5V
			analogInput_enScale(pin,0,50*DECIMAL);	
			break;
		case _0_10V: //0-10V
			analogInput_enScale(pin,0,100*DECIMAL);	
			break;
		case _0_20mA: //0-20mA
			analogInput_enScale(pin,0,200*DECIMAL);
			break;			
		case _4_20mA: //4-20mA
			analogInput_enScale(pin,40,2000);
			break;
		default:
			anCFG[pin][1]=0; 
			anCFG[pin][2]=0;
			break;
	}
	
	anCFG[pin][0]=type; //save pin configuration

}

void NovusClass::analogInput_enScale(int pin, int low, int high)
{
	/* Enables scale for linear input (AnInput Mode > 9)
	   High: High scale
	   Low: Low scale
	*/
	uint16_t config[4]={0};
	uint32_t int_high = high;
	uint32_t int_low = low;
	anCFG[pin][1]=low; 
	anCFG[pin][2]=high;


	config[0]=(int_low & 0xFFFF); //Low scale low byte
	config[1]=int_low>>16; //low scale high byte
	config[2]=(int_high & 0xFFFF); //high scale Low byte
	config[3]=int_high>>16; //High scale High Byte
	
	
	Modbus.Send(FUNC_WRITEMULTIPLE,(uint16_t)((Modbus.AI_LOWSCALE_LO)+(50*(pin-1))),2,&config[0]); //Send low scale
	Modbus.Check_Error();
	
	Modbus.Send(FUNC_WRITEMULTIPLE,(uint16_t)((Modbus.AI_HIGHSCALE_LO)+(50*(pin-1))),2,&config[2]); //Send high scale
	Modbus.Check_Error();
}

/* --------------------------------------------------------------------------------------
 *								Digital IO configurations	
 * -------------------------------------------------------------------------------------- */
void NovusClass::digitalInput_Mode(int pin, int func, int type, int debounce)
{
	/* Config a pin (channel) as digital input
       Func : [ 0 LOGIC; 1 COUNTER_UP; 2 COUNTER_DOWN; 3 TIME ]
	   Type: [ 0 PNP; 1 NPN; 2 Contato_Seco]
	   Debounce: Value in ms
	*/
	// todo: no parametro FUNC receber 1 2 3 4? Documentar pro usuário que
	//		 ele deve usar os defines (LOGIC, COUNTER_UP, ETC)
	       
	
	int config[5]={0};
	
	config[0]=1; // Enable
	config[1]=func; //
	config[2]=type; //Type... Contato seco, 
	config[3]=debounce;
	config[4]=0; //Don't Force

	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.DI_ENABLE)+(50*(pin-1))),1,&config[0]); //enable port
	Modbus.Check_Error();
	Modbus.Send(FUNC_WRITEMULTIPLE,(uint16_t)((Modbus.DI_FUNCTION)+(50*(pin-1))),3,&config[1]); //Send func(mode), type and debounce
	Modbus.Check_Error();
	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.DI_FORCE)+(50*(pin-1))),1,&config[4]);

}

void NovusClass::digitalOutput_enInstant(int pin, int powerON, int safeState)
{
	/* Configure channel as digital output instant value.
	   powerON: Power on value
	   safeState: safe state value
	*/
	int config[5]={0};

	config[0]=1; //enable
	config[1]=0; //function as instant value
	if(powerON==0)
	{
		config[2]=0;//pON state is off
	}
	else
	{
		config[2]=1;//pON state is a configured value	
	}
	config[3]=powerON; //pON value
	config[4]=safeState; //Safe value
	

	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.DO_ENABLE)+(50*(pin-1))),1,&config[0]); //enable port
	Modbus.Check_Error();
	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.DO_FUNCTION)+(50*(pin-1))),1,&config[1]); //FUNCTION AS INSTANT VALUE
	Modbus.Check_Error();
	Modbus.Send(FUNC_WRITEMULTIPLE,(uint16_t)((Modbus.DO_PON_STATE)+(50*(pin-1))),3,&config[2]); //pON state, pON value and safe state
	Modbus.Check_Error();
}	

void NovusClass::digitalOutput_enPulse(int pin, int pulseTime, int pulsePeriod, int nPulse)
{
	/* Config digital output as pulse train 
	   pulseTime: High Time(x*100ms)
	   pulsePeriod: Total wave time (x*100ms)
	   nPulse: Number of pulses (max 16 bits)
	*/
	int config[5]={0};
	
	config[0]=1; //Enable

	if(nPulse==0)
	{
		config[1]=0;// Disable pulse, enable instant value
	} 
	else if(nPulse==1)
	{
		config[1]=1;//Single Pulse
	} 
	else
	{
		config[1]=2;// Pulse Train
	} 
	
	config[2]=pulseTime;
	config[3]=pulsePeriod;
	config[4]=nPulse;
	
	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.DO_ENABLE)+(50*(pin-1))),1,&config[0]); //enable or disable port
	Modbus.Check_Error();

	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.DO_FUNCTION)+(50*(pin-1))),1,&config[1]); //function as single or pulse train
	Modbus.Check_Error();
	
	Modbus.Send(FUNC_WRITEMULTIPLE,(uint16_t)((Modbus.DO_PULSE_TIME)+(50*(pin-1))),3,&config[2]); //pulse time, period and number
	Modbus.Check_Error();

}

/* --------------------------------------------------------------------------------------
 *								Communication with IO Module	
 * -------------------------------------------------------------------------------------- */

void NovusClass::applyConfig()
{
	Modbus.applyConfig();
}

void NovusClass:: disablePin(int pin, int type, int mode)
{
	/* Disables a pin based on its Type and Mode.
	*	type:	(digital = 1, analog = 2)
	*	mode:	(input = 1, output = 2)
	*/
	int config[1]={0}; //Disable
	

	if(type==1 && mode==1)//Digital Input
	{
		Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.DI_ENABLE)+(50*(pin-1))),1,&config[0]); //Disable port
	}
	else if(type==1 && mode==2)//Digital Output
	{
		Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.DO_ENABLE)+(50*(pin-1))),1,&config[0]); //Disable port
	}
	else if(type==2 && mode==1)//Analog Input
	{
		Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.AI_ENABLE)+(50*(pin-1))),1,&config[0]); //Disable port
	}
	else if(type==2 && mode==2)//Analog output
	{
		Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.AO_ENABLE)+(50*(pin-1))),1,&config[0]); //Disable port	
	}
	
}

NovusClass Novus;


