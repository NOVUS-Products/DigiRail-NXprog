/* ---------.---------.---------.---------.---------.---------.---------.
 * 	  NovusIO.h is the necessary library to use NOVUS MixIO as an arduino
 * prototype shield, it was made by Igor F. Diesel, Jorge Luiz P. Bürger
 * and Pedro Henrique M. Pereira in NOVUS automation, Brazil. In this library
 * will be found several functions to allow the user communicate with NOVUS
 * MixIO. The user can configure all inputs and outputs provided
 * in the product, as listed in docummentation. NOVUS MixIO
 * provides 7 digital channels, where 4 of them are output; and 4 analog
 * channels, where 2 of them are output. All the digital outputs can be 
 * configured as a switch (ON/OFF) or pulse train. All the digital
 * inputs can be configured as an instantaneous reading (ON/OFF), a
 * counting of borders, or timer. All the analog output supports: 0-20mA, 
 * 4-20mA or 0-10V. The analog inputs supports different kinds of thermocouple, 
 * PT100 and PT100, it's also possible to measures 0-20mA, 4-20mA or 0-10V. 
 
 TODO: revisar texto e validar se é preciso outras informações
 
 \/\/\/ TODO: ver se é necessário manter esse comentario no produto final \/\/\/
 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

 
#include <stdint.h>
#include "InternCommunication.h"
#define NovusOperatingFrequency(x) (Modbus.setFrequency(x))

/* ANALOG INPUT */
#define tc_J 0
#define tc_K 1
#define tc_T 2
#define tc_E 3
#define tc_N 4
#define tc_R 5
#define tc_S 6
#define tc_B 7
#define Pt100 8
#define Pt1000 9
#define NTC 10
#define _0_60mV 11
#define _0_5V 12
#define _0_10V 13
#define _0_20mA 14
#define _4_20mA 15
#define CELSIUS 0
#define FAHRENHEIT 1

/* DIGITAL INPUT */
#define LOGIC 0
#define COUNTER_UP 1 //Counter border up
#define COUNTER_DOWN 2 //Counter border down
#define TIME 3 //Counter border down

#define PNP 0 //Type choosed PNP
#define NPN 1 //Type choosed NPN
#define DRY_CONTACT 2 //Type choosed dry contact

/* DIGITAL OUTPUT */
// There are different functions for each case of use

/* ANALOG OUTPUT */
//Use defines from Analog input
//#define _0_10V
//#define _0_20mA
//#define _4_20mA


#define LAST 2 //last nonvolatile for Power on and safe state
#define ENABLE 1
#define DISABLE 0

// Communication
#define getError() ERROR



#define DECIMAL 100 //1 for 1, 10 for 2, 100 for 3....

	
class NovusClass
{
  private:
	/* 2 linhas = ch1 e ch2 anInput
	   3 colunas = type min_Scale max_Scale */
	uint16_t anCFG[3][3];
	
	/* 3 linhas = ch1, ch2, ch3 anOutput mode */
	uint16_t aoCFG[3]={0xFF}; 
	 
    
  public:
	/* ....................................................................................................
	   ........................................ Using the IO pins .........................................
	   .................................................................................................... */
    float analogRead(int pin);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows users to get the value read in the analog input channels of NOVUS IO Module.
	 * It's necessary inform the pin wich will be read, after all, the read value will be returned to user.
	 *
	 * How to use: 		float Answer = Novus.analogRead(pin);
	 *
	 * Input: pin	  - Pin that will be read;
	 * Output: Answer - Read value from the pin;
	 *
	 * ----------------------------------------------------------------------------------------------------	*/
	
	void analogWrite(int pin, float value);	
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to write some value in the analog output channels of NOVUS IO Module.
	 * It's necessary inform the pin wich will be written and also the value to write in it.
	 *
	 * How to use: 		Novus.analogWrite(pin, value);
	 *
	 * Input: pin	  - Pin that will be written;
	 * 		  value	  - Value to write;
	 * Output: this function does not return a value;
	 *
	 * ----------------------------------------------------------------------------------------------------	*/
    int digitalRead(int pin);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to get the value read in the digital input channels of NOVUS IO Module.
	 * It's necessary inform the pin wich will be read, after all, the read value will be returned to user.
	 *
	 * How to use: 		int Answer = Novus.digitalRead(pin);
	 *
	 * Input: pin	  - Pin that will be read;
	 * Output: Answer - Read value from the pin;
	 *
	 /* ---------------------------------------------------------------------------------------------------- */
 
    int digitalReadCounter(int pin);
	/* ----------------------------------------------------------------------------------------------------
	 *	 This function allows user to get the number of borders occurred accordingly it's configuration as 
	 *	COUNTER BORDER UP or COUNTER BORDER DOWN.
	 *  It's necessary inform the pin wich will be read, after all, the read value will be returned to user.
	 *
	 * How to use: 		int Answer = Novus.digitalRead(pin);
	 *
	 * Input: pin	  - Pin that will be read;
	 * Output: Answer - Read value from the pin;
	 *
	 /* ---------------------------------------------------------------------------------------------------- */
	   int digitalReadTimer(int pin, int onoff); //todo: Mudar o comentario q ta errado
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to get the value read in the digital input channels of NOVUS IO Module.
	 * It's necessary inform the pin wich will be read, after all, the read value will be returned to user.
	 *
	 * How to use: 		int Answer = Novus.digitalRead(pin);
	 *
	 * Input: pin	  - Pin that will be read;
	 * Output: Answer - Read value from the pin;
	 *
	 /* ---------------------------------------------------------------------------------------------------- */

    void digitalWrite(int pin, int value);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to write some value in the digital Output channels of NOVUS IO Module.
	 * It's necessary inform the pin wich will be written and also the value to write in it.
	 *
	 * How to use: 		Novus.digitalWrite(pin, value);
	 *
	 * Input: pin	  - Pin that will be written;
	 * 		  value	  - Value to write;
	 * Output: this function does not return a value;
	 *
	 * ----------------------------------------------------------------------------------------------------	*/
	 
	
	/* ....................................................................................................
	   .................................. Configuration analog Output .....................................
	   .................................................................................................... */
	void analogOutput_Mode(int pin, int type, float powerON, float safeState); //cpp ok 
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	
	/* ....................................................................................................
	   ................................... Configuration analog input .....................................
	   .................................................................................................... */
	void analogInput_Mode(int pin, int type, int temp, float safeState); //temp = C ou F //cpp ok 
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void analogInput_enScale(int pin, int low, int high); //cpp ok 
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
		
	/* ....................................................................................................
	   .................................. Configuration digital input .....................................
	   .................................................................................................... */
	void digitalInput_Mode(int pin,int func, int type, int debounce); 
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	
	/* ....................................................................................................
	   ................................. Configuration digital Output .....................................
	   .................................................................................................... */
	void digitalOutput_enInstant(int pin, int powerON, int safeState); //cpp ok for instant value
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void digitalOutput_enPulse(int pin, int pulseTime, int pulsePeriod, int nPulse); //cpp ok
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	 
	 
	 //TODO: Fazer comentario sobre as funcoes descritas acima.

	/* ....................................................................................................
	   .......................................... Miscellaneous ...........................................
	   .................................................................................................... */
	void applyConfig();
	/* ----------------------------------------------------------------------------------------------------
	 * This function is used to trigger a reconfiguration procedure inside the uC. It's possible to call 
	 * many configuration functions before calling Novus.applyConfig(), but if this function is not called,
	 * none of the modifications will be active.
	 *
	 * MUST BE CALLED AFTER ANY PIN/PORT/CHANNEL RECONFIGURATION!
	 *
	 * Ex.: 
	 * Novus.digitalOutput_mode(...); //Sets pin as digital output
	 * Novus.analogInput_mode(...); // Sets pin as analog input
	 * Novus.applyConfig(); //Reconfigure uC based on previous configuration set
	 * ----------------------------------------------------------------------------------------------------	*/	
	void disablePin(int pin, int type, int mode );
	/* ----------------------------------------------------------------------------------------------------
	 *	Disables a pin based on its:
	 *	type:	(digital = 1, analog = 2, all = 0)
	 *	mode:	(input = 1, output = 2, all = 0)
	 *
	 *  
	 * 
	 *
	 * ----------------------------------------------------------------------------------------------------	*/
};

extern NovusClass Novus;
