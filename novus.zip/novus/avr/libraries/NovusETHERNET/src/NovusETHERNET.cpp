/* ---------.---------.---------.---------.---------.---------.---------.
 * BIBLIOTECA UTILIZADA PARA CONFIGURAÇÃO DA ETHERNET DO MODULO MIXIO.
 * AQUI, FAZEMOS USO DA BIBLIOTECA IPAddress.h DO ARDUINO, QUE FACILITA
 * MUITO A DECLARAÇÃO DE IP's.  
 * PARA DECLARAR UM IP, É SÓ UTILIZAR: IPAddress nome_variavel(192,168,11,214);
 * DEPOIS, É POSSIVEL ACESSAR OS OCTETOS POR nome_variavel[0].
 *
 * ATÉ O MOMENTO, APENAS PODEMOS HABILITAR A ETHERNET DO MIXIO COMO ESCRAVO MODBUS TCP
 *
 *
 * --- Função enable (Novus_ETHERNET.enable)
 * * DEPOIS DO ENABLE, É SEMPRE NECESSÁRIO CHAMAR UM applyConfig !!!!
 * *
 * * Dois prototipos foram criadoes para função enable:
 * * Caso DHCP=1, não é necessário enviar os IP's desejados.
 * *  
 * * Caso DHCP=0, devemos enviar IP, mask, gateway e DNS.
 * * 
 * * O resto do procedimento é padrão, escreve os valores nos registradores do RENESAS.
 * *  ***CUIDADO***: A parte baixa dos IPs é salvo no primeiro registrador do RENESAS,
 * * e a alta no registrador seguinte. 
 * --- 
 *
 * --- Função disable
 * * Trivial. Desabilita a ETHERNET.
 * --- 
 *
 * --- Função readConfig
 * * Cópia da função disponível na biblioteca READ_DEVICE
 * * Achei importante manter aqui para o usuário verificar qual IP foi
 * * obtido pelo DHCP, por exemplo. 
 * * 
 * * Printa no Monitor Serial do Arduino todos os IPs.
 * ---  
 * 
 * --- Função applyConfig
 * * Aplica as configurações no RENESAS.
 * * Necessário chamar após algum ENABLE ou DISABLE.
 * ---
 *
 *
 *
 * TODO: FALTA FAZER : 
 * Criar uma função para modificar as configurações do MODBUS TCP,
 * como PORTA, etc. Verificar o que é necessário pelo NX e replicar.
 * 
 * Implementar um "Send_Byte" e "Receive_Byte" para a ETHERNET
 * 
 */

#include "NovusETHERNET.h"
#include <Arduino.h>

/* --------------------------------------------------------------------------------------
 *								  	ETHERNET communication	
 * -------------------------------------------------------------------------------------- */
 void ETHERNETClass::enable(int DHCP)
 {	
	/*
	 * Enables ETHERNET Communication in NOVUS mixIO
	 * If function is sent just with DHCP parameter, 
	 * there is no need to set Static IPs. 
	 */
	 uint16_t config[2]={0};
	 config[0]=1; // Enable
	 config[1]=	DHCP; // 0-TCP, 1-DHCP

	 Modbus.Send(16,(uint16_t)Modbus.ETHERNET_ENABLE,2,&config[0]);
	 
	// Modbus.applyConfig();
 }
 
  void ETHERNETClass::enable(int DHCP, IPAddress ip, IPAddress mask, IPAddress gateway, IPAddress DNS)
 {	
	/*
	 * Enables ETHERNET Communication in NOVUS mixIO
	 * If DHCP is set do 0, it's needed to send all IP parameters 
	 * for Static IP use.
	 */
	 uint16_t config[10]={0};
	 config[0]=1; // Enable
	 config[1]=DHCP; // 0-TCP, 1-DHCP
	 
	 config[2]=(((uint16_t)ip[0])<<8)|((uint16_t)ip[1]); //Ip 0 e 1
	 config[3]=(((uint16_t)ip[2])<<8)|((uint16_t)ip[3]); //Ip 2 e 3	 
	 	 
	 config[4]=(((uint16_t)mask[0])<<8)|((uint16_t)mask[1]); //mask 0 e 1
	 config[5]=(((uint16_t)mask[2])<<8)|((uint16_t)mask[3]); //mask 2 e 3
	 
	 config[6]=(((uint16_t)gateway[0])<<8)|((uint16_t)gateway[1]); //gateway 0 e 1
	 config[7]=(((uint16_t)gateway[2])<<8)|((uint16_t)gateway[3]); //gateway 2 e 3
	 
	 config[8]=(((uint16_t)DNS[0])<<8)|((uint16_t)DNS[1]); //DNS 0 e 1
	 config[9]=(((uint16_t)DNS[2])<<8)|((uint16_t)DNS[3]); //DNS 2 e 3
	 
	 
	 
	 Modbus.Send(16,(uint16_t)Modbus.ETHERNET_ENABLE,2,&config[0]); //Enable e DHCP
	 Modbus.Send(16,(uint16_t)Modbus.ETHERNET_IP0,2,&config[2]); //IP	 
	 Modbus.Send(16,(uint16_t)Modbus.ETHERNET_MASK0,2,&config[4]); //MASK	 
	 Modbus.Send(16,(uint16_t)Modbus.ETHERNET_GATE0,2,&config[6]); //Gateway	 
	 Modbus.Send(16,(uint16_t)Modbus.ETHERNET_DNS0,2,&config[8]); //DNS
	 
	// Modbus.applyConfig();
 }
 
 
 void ETHERNETClass::disable()
 {
	 uint16_t config[1]={0};
	 // Writing the mode
	 Modbus.Send(6,(uint16_t)Modbus.ETHERNET_ENABLE,1,&config[0]);
	// Modbus.applyconfig();
	 if (ERROR !=0)
	 {
		 return ERROR;
	 }
	 else
	 {
		 delay(100);
		 Modbus.Send(3,(uint16_t)Modbus.ETHERNET_ENABLE,1,&config[0]);
		 if (ERROR !=0)
		 {
			 return ERROR;
		 }
		 else
		 {
			 if (VALOR == 0)
			 {
				 //Success
				 return 0;
			 }
		 }
	 }	 
 }
 void ETHERNETClass::send()
 {
	
 }
 void ETHERNETClass::receive()
 {
	
 }
 
 void ETHERNETClass::readConfig()
{
	Serial.begin(9600);
	Serial.println(F("\n-------------------------------------------------------------"));
	Serial.println(F("	MixIO ETHERNET is configured as the following states:\n"));
	
	Serial.print(F("       Status: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_ENABLE,1,0); //ETH enable
	/*if(Modbus.res.erro!=0)
	{
		Serial.println(Modbus.res.erro);
	}*/
	if (Modbus.res.valor == 1)
	{
		Serial.print(F("Enabled"));
	}
	else
	{
		Serial.print(F("Disabled"));
	}
	
	Serial.print(F("       DHCP: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_DHCP_ENABLE,1,0); //DHCP enable
	if (Modbus.res.valor == 1)
	{
		Serial.println(F("Enabled"));
	}
	else
	{
		Serial.println(F("Disabled"));
	}
	
	Serial.println(F("********** IP Desejado (estático) ************"));
	
	Serial.print(F("       IPV4: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_IP0,1,0); //IP0 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F("."));
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_IP1,1,0); //IP2 
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 

	
	Serial.print(F("       SUBNET MASK: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_MASK0,1,0); //MASK 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_MASK1,1,0); //MASK 
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	
	Serial.print(F("       GATEWAY: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_GATE0,1,0); //GATEWAY 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_GATE1,1,0); //GATEWAY 
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF));
	
	Serial.print(F("       DNS: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_DNS0,1,0); //DNS 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_DNS1,1,0); //DNS 
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	Serial.println(F("-------------------------------------------------------------\n"));

	
	Serial.println(F("********** IP Utilizados ************"));
	
	Serial.print(F("       IPV4: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_IP0,1,0); //IP0
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_IP1,1,0); //IP2
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 

	
	Serial.print(F("       SUBNET MASK: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_MASK0,1,0); //MASK0
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F("."));
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F("."));
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_MASK1,1,0); //MASK2
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	
	Serial.print(F("       GATEWAY: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_GATE0,1,0); //GATEWAY0
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_GATE1,1,0); //GATEWAY2
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	
	Serial.print(F("       DNS: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_DNS0,1,0); //DNS0 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_DNS1,1,0); //DNS2
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	Serial.println(F("-------------------------------------------------------------\n"));
	
	
	Serial.println(F("			Finished reading"));	
	Serial.println(F("-------------------------------------------------------------\n"));
}
 
 void ETHERNETClass::applyConfig()
 {
	 Modbus.applyConfig();
 }

ETHERNETClass Novus_ETHERNET;


