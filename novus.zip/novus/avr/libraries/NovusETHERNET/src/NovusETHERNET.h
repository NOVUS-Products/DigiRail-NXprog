/* 
 *
 * 	
 */
 
#include <stdint.h>
#include "InternCommunication.h"
#define NovusOperatingFrequency(x) (Modbus.setFrequency(x))
#include <IPAddress.h>

/* Constants */
#define TCP 0
	
class ETHERNETClass
{
  private:
  
		
  public:
  
	void enable(int DHCP); //if DHCP, no need to send IP address...
	
	void enable(int DHCP, IPAddress ip, IPAddress mask, IPAddress gateway, IPAddress DNS); //If static IP, send IP address
	
	
	void disable();
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void send();
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void receive();
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void readConfig();
	void applyConfig();
	 //TODO: Criar funções necessárias para ethernet 
};

extern ETHERNETClass Novus_ETHERNET;
