/*
 *
 * 	| End |  Fun | Num | Pin | Sin | D00 | D01 | D02 | D03 | D04 | D05 | D06 | D07 | D08 | Crc | Crc |  --> Pacote de mensagem
 * 	| End |  Fun | Num | Pin | D00 | D01 | D02 | D03 | D04 | D05 | D06 | D07 | D08 | D09 | Crc | Crc |  --> Pacote de configuração 
 *
 *	xxxx.xxxx.xxxx.xxxx --> 16 Bytes
 *  ||||.||||.||||.||||
 *  ||||.||||.||||.|||V
 *  ||||.||||.||||.||V--- CRC baixo
 *  ||||.|VVV.VVVV.VV---- CRC alto
 *  ||||.V---.----.------ Dados
 *  |||V.----.----.------ Dados ( SINAL )
 *  ||V-.----.----.------ Dados ( PINO )
 *  |V--.----.----.------ Dados ( Nº Bytes )
 *  V---.----.----.------ Função
 *  ----.----.----.------ Endereço
 * 
 *	-----------------------------
 *	-- Standard Payload Modbus --
 *	-----------------------------
 *
 * | Address | Function | High Register | Low Register | High Value | Low Value | Low CRC | Low CRC |
 * 		--> return ( ECHO )
 * | Address | Function | High Register | Low Register | High Quantity Registers | Low Quantity Registers | Low CRC | Low CRC |
 *		--> return( | Address | Function | Bytes Readen | High Value | Low Value | ... | Low CRC | Low CRC |
 *
 * Writting in a book and reading a book: Registers allways sequentially.
 *
 *	----------------------
 *	-- Modbus Functions --
 *	----------------------
 * 
 *	 3- Read single/block register
 * 	 6- Write single register
 * 	16- Write block of registers
 *
 *
 * COMENTARIOS ADICIONAIS NO ARQUIVO .CPP
 */
 
#include <stdint.h>

#ifndef INTERNCOMMUNICATION_H
#define INTERNCOMMUNICATION_H

/* Changing code */
//#define DEBUG

/* Constants */
// Communication
#define Slave_addr 7
#define BaudRate 115200
#define timeout_com 200
#define cont_tries 3

#define IO_RECONFIG_ALL 1082
#define MAIN_FREQ  1024
	
/* Modbus functions */	
#define FUNC_READSINGLE 3
#define FUNC_WRITESINGLE 6		
#define FUNC_WRITEMULTIPLE 16

#define ERROR Modbus.res.erro
#define VALOR Modbus.res.valor


class InternClass
{
  private:
  
  public:
  /******** DEFINES DOS REGISTRADORES *****/
  
	typedef enum
	{
		RS485_MODBUS_MODE = 1027,
		RS485_MODBUS_ADDR, 
		RS485_BAUDRATE,
		RS485_PARITY,
		RS485_STOPBIT,

	} RS485;
  
  	typedef enum
	{
		ETHERNET_INFO_IP0 = 100,
		ETHERNET_INFO_IP1,
		
		ETHERNET_INFO_MASK0 = 108,
		ETHERNET_INFO_MASK1,
		
		ETHERNET_INFO_GATE0 = 116,
		ETHERNET_INFO_GATE1,
		
		ETHERNET_INFO_DNS0 = 124,
		ETHERNET_INFO_DNS1,
		
		ETHERNET_ENABLE = 1033,

		ETHERNET_DHCP_ENABLE = 1036,
		ETHERNET_IP0,
		ETHERNET_IP1,
		
		ETHERNET_MASK0 = 1045,
		ETHERNET_MASK1,
		
		ETHERNET_GATE0 = 1053,
		ETHERNET_GATE1,
		
		ETHERNET_DNS0 = 1061,
		ETHERNET_DNS1,

	} Ethernet;
	
	
		/* Registers for Digital Output */
	typedef enum
	{
	DO_VALUE = 500, //SET CH1
	DO_ENABLE= 1900,
	DO_FUNCTION=1925, //INSTANT 0 PULSE 1 PULSE_TRAIN 2
	DO_PULSE_TIME, //CASE PULSE OR PULSE_TRAIN
	DO_PULSE_PERIOD, //CASE PULSE OR PULSE_TRAIN
	DO_NUMBER_OF_PULSES, //CASE PULSE OR PULSE_TRAIN
	DO_PON_STATE, //OFF 0 CONFIGURED_VALUE 1 LAST 2
	DO_PON_VALUE, 
	DO_SAFE_STATE,
	} DigOutput;
  
	/* Registers for Digital Input */
	typedef enum
	{
		DI_STATE = 70, //READ CH1	
		DI_COUNTER_LO=22, //READ LOW BYTE COUNTER VALUE
		DI_COUNTER_HI, //READ HIGH BYTE COUNTER VALUE
		DI_TIMEON_LO=38, //TIME_ON VALUE
		DI_TIMEON_HI,
		DI_TIMEOFF_LO=54, //TIME_OFF VALUE
		DI_TIMEOFF_HI,
		
		DI_ENABLE=1500,
		DI_FUNCTION=1525, //LOGIC 0 COUNTER_UP 1 COUNTER_DOUNW 2 TIME 3
		DI_TYPE,
		DI_DEBOUNCE,  //Debounce in ms
		DI_FORCE=1533,
		DI_PAUSE //PAUSE COUNTER OR TIME
	} DigInput;

   /* Registers for Analog Output */
	typedef enum
	{
		AO_VALUE = 524, //SET VALUE CH1
		AO_ENABLE=2700,
		AO_TYPE=2725, //0-20mA 0 4-20mA 1 0-10V 2
		AO_RANGE, //%x100 0 0-32000 1 
		AO_PON_STATE, //OFF 0 CONFIGURED_VALUE 1 LAST 2
		AO_PON_VALUE,
		AO_SAFE_VALUE,
	} AnOutput;
   		
	/* Registers for Analog Input */
	typedef enum
	{
		AI_READ_LO=14,
		AI_READ_HI,
		
		AI_ENABLE=2300,
		AI_TYPE=2325, //TCJ TCK ....
		AI_UNIT, //TEMPERATURE UNIT - CELCIUS 0 F 1
		AI_FILTER, //FIRST ORDER FILTER
		
		AI_LOWSCALE_LO,
		AI_LOWSCALE_HI,
		AI_HIGHSCALE_LO,
		AI_HIGHSCALE_HI,
		
		AI_SAFE_VALUE_LO=2336,
		AI_SAFE_VALUE_HI,

  } AnInput;
  
 

	
    struct resposta{
		int erro; // Return 0 if 'OK' and other values according to errors.txt 
		uint16_t valor; // Return the value read in the input pins.
	};
	
	resposta res;
  	
	void Send(uint8_t function, uint16_t reg, uint16_t quantity, uint16_t* value);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function is intern, the communication with renesas is established here. DO NOT MODIFY
	 * ----------------------------------------------------------------------------------------------------	*/ 
	
	uint16_t getCRC( uint8_t *pBufferSerial, uint8_t u8NumBytes );
	/* ----------------------------------------------------------------------------------------------------
	 *	This function is intern, the communication with renesas is established here. DO NOT MODIFY
	 * ----------------------------------------------------------------------------------------------------	*/ 
	 
	bool verificaCRC( uint8_t *pBufferSerial, uint8_t u8Index );
	/* ----------------------------------------------------------------------------------------------------
	 *	This function is intern, the communication with renesas is established here. DO NOT MODIFY
	 * ----------------------------------------------------------------------------------------------------	*/ 
	 
	void Check_Error();
	/* ----------------------------------------------------------------------------------------------------
	 *	This function is intern, the communication with renesas is established here. DO NOT MODIFY
	 * ----------------------------------------------------------------------------------------------------	*/ 
	 
	void applyConfig();
	/* ----------------------------------------------------------------------------------------------------
	 *	This function is intern, the communication with renesas is established here. DO NOT MODIFY
	 * ----------------------------------------------------------------------------------------------------	*/
	
	void setFrequency(int freq);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function is intern, the communication with renesas is established here. DO NOT MODIFY
	 * ----------------------------------------------------------------------------------------------------	*/
};

extern InternClass Modbus;


#endif