/* ---------.---------.---------.---------.---------.---------.---------.
 * ESTA BIBLIOTECA É UTILIZADA POR TODAS AS DEMAIS BIBLIOTECAS NOVUS,
 * PORÉM NÃO É ACESSADA DIRETAMENTE PELO USUÁRIO (IDE ARDUINO).
 *
 * Sua função é a comunicação direta com o RENESAS, ou seja, é nesta biblioteca
 * que o PDU Modbus é montado e o PDU de resposta do RENESAS é tratado.
 *
 * --- Função SEND (Modbus.Send)
 * * Cria o PDU de acordo com a função MODBUS (escrita, leitura) desejada, 
 * * com o registro a ser acessado e o valor a ser atribuido (caso escrita);
 * *
 * * Depois de enviar o PDU pro RENESAS, aguarda uma resposta, até que todos os bytes cheguem
 * * ou um timeout_com ocorra. 
 * * 
 * * Caso o PDU de resposta esteja correto (checa Endereço, CRC, Função, ...) salva o valor lido 
 * * na variavel 'valor' da estrutura 'res' (res.valor).
 * * 
 * * Caso algum erro seja detectado, res.valor = 0, e o erro encontrado é atribuido a variavel
 * * res.erro (diversos padroes de erro foram criados, verificar documentação)
 * --- 
 *
 * --- Funções getCRC e verificaCRC
 * * getCRC      - cria o CRC a partir do PDU
 * * verificaCRC - testa se o CRC recebido é correto.
 * ---
 *
 * --- Função applyConfig
 * * Esta função deve ser chamada sempre que for necessário reconfigurar o RENESAS,
 * * como, por exemplo, após a configuração de alguma entrada/saída analogica/digital;
 * *
 * * Escreve no registrador de reconfiguração do RENESAS e aguarda o mesmo retornar para zero.
 * *
 * * Após escrever 1 no registrador, lê o mesmo 3 vezes. Caso o registrador não retornar para zero,
 * * indica que ocorreu algum erro de configuração (espera-se que isso nunca ocorra caso as funções
 * * de configuração sejam utilizadas CORRETAMENTE... mas usuário é usuário).
 * ---
 *
 * --- Função setFrequency
 * * Modifica o registrador que indica a frequencia de trabalho da rede eletrica (50Hz ou 60Hz).
 * * TODO: MELHORIAS: PROVAVELMENTE ESTA FUNÇÃO SERÁ MOVIDA PARA A BIBLIOTECA EXPERT.
 * ---
 *
 * TODO: Tem que traduzir essa descrição? Entendo que ela é para utilização interna e a versão
 * final enviada para o usuário nao precisa dessa descrição;
 */


#include "InternCommunication.h"
#include <Arduino.h>
InternClass::resposta res;

/* --------------------------------------------------------------------------------------
 *								  	intern communication	
 * -------------------------------------------------------------------------------------- */
void InternClass::Send(uint8_t function, uint16_t reg, uint16_t quantity, uint16_t* value)
{
	res.erro=0;
	res.valor=0;
	if ((quantity <= 0))
	{
		res.erro = 1;
	}
	if ((function != 3)&&(function != 6)&&(function != 16))
	{
		res.erro = 2; //Function unexpected
	}
	
	if (res.erro == 0)
	{	
		 int MAX = 8;
		 uint8_t Modbus_PDU[16]={0}; 
		 uint8_t Modbus_PDU_r[16]={0}; 
		 
		 /* Max PDU supported by renesas: 16 bytes --> that means only 3 Bytes of data
		  *                          |   0   |   1  |    2    |    3    |   4   |   5   |   6   |   7   |   8  |   9  |  10  |  11  |  12  |   13  |   14  |
		  * Read register(s):  3 --> | Slave | Func | Regst H | Regst L | Qnt H | Qnt L | CRC L | CRC H | 
		  * Write register  :  6 --> | Slave | Func | Regst H | Regst L | Val H | Val L | CRC L | CRC H |
		  * Write registers : 16 --> | Slave | Func | Start H | Start L | Qnt H | Qnt L |  2*N  |  V0 H | V0 L | V1 H | V1 L | V2 H | V2 L | CRC L | CRC H |
		  *
		  */
		  
		 Modbus_PDU[0] = Slave_addr; 							// Slave address
		 Modbus_PDU[1] = function; 								// 3- Read single register | 6- Write single register | 16- Write multiple register
		 Modbus_PDU[2] = ((reg & 0xFF00) >> 8); 					// High byte of register
		 Modbus_PDU[3] = ((reg & 0x00FF) >> 0); 					// Low byte of register
		 if (function == 3)
		 {
			Modbus_PDU[4] = ((quantity >> 8) & 0xFF); 			// High byte of quantity
			Modbus_PDU[5] = ((quantity >> 0) & 0xFF); 			// Low byte of quantity
			MAX = 8;
		 }
		 else if (function == 6)
		 {
			Modbus_PDU[4] = ((*value >> 8) & 0xFF); 			// High byte of value
			Modbus_PDU[5] = ((*value >> 0) & 0xFF); 			// Low byte of value
			MAX = 8;
		 }
		 else if (function == 16)
		 {
			Modbus_PDU[4] = ((quantity >> 8) & 0xFF); 			// High byte of quantity
			Modbus_PDU[5] = ((quantity >> 0) & 0xFF); 			// Low byte of quantity
			Modbus_PDU[6] = 2*quantity; 						// byte count
			MAX = 9 + 2*quantity;
			 
			for (int x=0; x<quantity ;x++)
			{
				Modbus_PDU[7+2*x] = ((*(value+x) >> 8) & 0xFF); // High byte of value
				Modbus_PDU[8+2*x] = ((*(value+x) >> 0) & 0xFF); // Low byte of value
			}		 
		 }
		 
		 //Calcular CRC
		 uint16_t u16CRC = getCRC( &(Modbus_PDU[0]),(function == 16 ? 2*quantity+7 : 6));
		 Modbus_PDU[(function == 16 ? 2*quantity+7 : 6) + 1]      =  (uint8_t) (u16CRC >> 8);
		 Modbus_PDU[(function == 16 ? 2*quantity+7 : 6)]  =  (uint8_t) (u16CRC & 0xFF); 
		 
#ifdef DEBUG
		 if(function == 3)
		 {
			 Serial.println(F("exm: [ Ad Fn Rh Rl Qh Ql Cl Ch ]"));
		 }
		 else if (function == 6)
		 {
			 Serial.println(F("exm: [ Ad Fn Rh Rl Vh Vl Cl Ch ]"));
		 }
		 else if (function == 16)
		 {
			 Serial.println(F("exm: [ Ad Fn Sh Sl Qh Ql NB Vh Vl Vh Vl Vh Vl Cl Ch ]"));
		 }
		 Serial.print(F("PDU: [ "));
		 for (int x=0; x < MAX; x++)
		 {
			 if (Modbus_PDU[x] > 0XF) 
			 {
				 Serial.print(Modbus_PDU[x],HEX);
			 }
			 else
			 {
				Serial.print(F("0"));
				Serial.print(Modbus_PDU[x],HEX);
			 }
			 
			 Serial.print(F(" "));
			 if (x == (MAX-1))
			 {
				 Serial.print(F("]\nP_r: [ "));
			 }
		 }
#endif
		 
		 int tries = 0;
		 do
		 {
			 res.erro=0;
			 
			 if (function == 3) 
			 {
				 MAX = 8;
			 }
			 else if (function == 6)
			 {
				 MAX = 8;
			 }
			 else if (function == 16) 
			 {
				 MAX = 9 + 2*quantity; 
			 }
			 
			 // Enviando PDU
			 for (int x=0; x < MAX; x++)
			 {
				 Serial1.write(Modbus_PDU[x]); //Enviar o valor do byte para o Renesas
				 //delay(1);
			 }
			 
			 int cont=0;
			 unsigned long current=0, previous = millis();
			 
			 if (function == 3)
			 {
				 MAX = 5 + quantity*2;
			 }
			 else if (function == 6) 
			 {
				 MAX = MAX;
			 }
			 else if (function == 16) 
			 {
				 MAX = 8; 
			 }
			 
			 //Recebendo PDU
			 do
			 {
				 current = millis();
				 if (current - previous >= timeout_com )
				 {
#ifdef DEBUG
					 Serial.print(F("Timeout, received "));
					 Serial.print(cont);
					 Serial.println(F(" bytes."));
#endif
					 res.erro = 99; //timeout
					 break;
				 } 
				 
				 if (Serial1.available()) //Esperar a chegada de um byte
				 {
					Modbus_PDU_r[cont]= Serial1.read();
					cont++;
					//delay(1);
				 }
			 } while(cont < MAX); //Aguardar a mensagem completa
			 
			 tries = (res.erro == 99 ? tries + 1 : cont_tries);
		}while(tries < cont_tries);
		
		 delay(10); //Delay between sends
		
#ifdef DEBUG
		 for (int x=0; x < MAX; x++)
		 {
			if (Modbus_PDU_r[x] > 0XF) 
			{
				Serial.print(Modbus_PDU_r[x],HEX);
			}
			else
			{
			  Serial.print(F("0"));
			  Serial.print(Modbus_PDU_r[x],HEX);
			}
			Serial.print(" ");
			if (x == (MAX-1))
			{
				Serial.println(F("]\n"));
			}
		 }
#endif
		if (res.erro == 0)
		{
			 // Validação da resposta
			 if(!verificaCRC(Modbus_PDU_r,MAX-2))
			 {
				 res.erro=3; // CRC is right ?
			 }
			 if(Modbus_PDU_r[0] != Modbus_PDU[0])
			 {
				 res.erro = 4; // Same slave address ?
			 }
			 if(Modbus_PDU_r[1] != Modbus_PDU[1])
			 {
				 res.erro = 5; // Same function number ?
			 }
			 if(function != 3)
			 {
				 for (int x=0; x < 6; x++)
				 {	
					if (Modbus_PDU[x] != Modbus_PDU_r[x])
					{	
						res.erro = 10; // Write returned echo ?
					}
				 }
			 } 

			 // Pegando a leitura
			 if ((function == 3) && (quantity == 1))
			 {
				 res.valor = ((uint16_t)Modbus_PDU_r[3]<<8) + Modbus_PDU_r[4];
			 }
		}
	}
}
 
uint16_t InternClass::getCRC( uint8_t *pBufferSerial, uint8_t u8NumBytes )
{
	/* Calculate CRC  from the byte '0' until the number of bytes indicated by 'u8NumBytes' */
    uint16_t u16CRC;
    uint16_t u16Index;
    uint8_t bLSB;
    uint8_t u8Aux;

    u16CRC = 0xffff;

   // Passing throught all the bytes
    for( u16Index = 0; u16Index < u8NumBytes; u16Index++ )
    {
        // XOR between frames byte and Low part of CRC
        u8Aux = pBufferSerial[u16Index] ^ (uint8_t)(u16CRC & 0xff);

        u16CRC &= 0xff00;
        u16CRC |= u8Aux;

        u8Aux = 8;
        while( u8Aux-- )
        {
            // stop when LSB = 1
            bLSB = u16CRC & 0x01; // Extracion do LSB
            u16CRC = u16CRC>>1;

            if( bLSB )
            {
                u16CRC = u16CRC ^ 0xA001;   // XOR between CRC and 0xA001
            }
        }
    }

    return u16CRC;

}

bool InternClass::verificaCRC( uint8_t *pBufferSerial, uint8_t u8Index )
{
	// Retorna FALSE sempre que houver erro de CRC.
    uint16_t u16CRC;

    // ucIndex indica o número de bytes.
    // Não leva em consideração o CRC, então deve subtrair 2
    u8Index -= 2;

    u16CRC = getCRC( pBufferSerial, u8Index );

    if( (pBufferSerial[u8Index++] == (uint8_t)(u16CRC & 0xff)) && (pBufferSerial[u8Index] == (uint8_t)(u16CRC>>8)) )
    {
        return false;
    }
    else
    {
        return true;
    }

}

void InternClass::Check_Error(void)
{
	
#ifdef DEBUG
	switch (res.erro)
	{
		case 0: 
				Serial.println(F("No error occured"));
				break;
		case 1:
				Serial.println(F("ERROR DETECTED: Underflow "));
				break;
		case 2:
				Serial.println(F("ERROR DETECTED: Overflow "));
				break;
		case 3:
				Serial.println(F("ERROR DETECTED: Modbus Function "));
				break;
		case 4:
				Serial.println(F("ERROR DETECTED: Underflow "));
				break;
		case 5:
				Serial.println(F("ERROR DETECTED: Overflow "));
				break;
		case 6:
				Serial.println(F("ERROR DETECTED: Timeout "));
				break;
		case 7:
				Serial.println(F("ERROR DETECTED: CRC "));
				break;
		case 8:
				Serial.println(F("ERROR DETECTED: Slave address "));
				break;
		case 9:
				Serial.println(F("ERROR DETECTED: function response "));
				break;
		case 10:
				Serial.println(F("ERROR DETECTED: echo "));
				break;
		case 11:
				Serial.println(F("ERROR DETECTED: Configuration Failed"));
				break;
		default:
				Serial.print(F("Unkwnon error. UPDATE Check_error with N: "));
				Serial.println(res.erro);
				break;				
	}
#endif
	
}

void InternClass::applyConfig()
{
	int config[1] = {1};
	int i=1;
	
#ifdef DEBUG	
	Serial.println(F(" Apply your configuration in the module."));
#endif
	//Trigger reconfig
	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)(IO_RECONFIG_ALL),1,&config[0]); 	
#ifdef DEBUG
	Serial.println(F("reading register reconfig"));
#endif
	
	do
	{
		delay(500*i); //primeira vez espera 500m, segunda 1s, ...
		Modbus.Send(FUNC_READSINGLE,(uint16_t)(IO_RECONFIG_ALL),1,&config[0]);
		i++;
		if(i==4 && VALOR==1)
		{
			// Tried 3 times and config didn't end, break and send an error
			Modbus.res.erro=11;
			break;
		}		
	}while(VALOR==1);
}

void InternClass::setFrequency(int freq)
{	
	/* 
	   Write the frequency choosed by user:
	   if typed 50, frequnecy will be 50Hz
	   Other values, frequency will be 60Hz
	*/
	uint16_t config[1]={(freq == 50 ? 1 : 2)};
	Modbus.Send(6,(uint16_t)MAIN_FREQ,1,&config[0]);
}
InternClass Modbus;


