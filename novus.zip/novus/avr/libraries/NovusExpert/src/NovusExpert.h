/*
 *
 * 	
 */
 
#include <stdint.h>
#include "InternCommunication.h"
#define NovusOperatingFrequency(x) (Modbus.setFrequency(x))

/* Constants */
// Communication

/* CAN */
// constants
	
class ExpertClass
{
  private:
  	typedef enum
	{
	DO_VALUE = 500, //SET CH1
	DO_ENABLE= 1900,
	DO_FUNCTION=1925, //INSTANT 0 PULSE 1 PULSE_TRAIN 2
	DO_PULSE_TIME, //CASE PULSE OR PULSE_TRAIN
	DO_PULSE_PERIOD, //CASE PULSE OR PULSE_TRAIN
	DO_NUMBER_OF_PULSES, //CASE PULSE OR PULSE_TRAIN
	DO_PON_STATE, //OFF 0 CONFIGURED_VALUE 1 LAST 2
	DO_PON_VALUE, 
	DO_SAFE_STATE,
	} DigOutput;
		
  public:
  
	void setFrequency(int freq);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void analogInput_enFilter(int pin, int mode); //cpp ok 
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void analogInput_enAvg(int pin, int mode, int time); //todo
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void analogInput_enIntegral(int pin, int mode, int time);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void analogInput_enDerivative(int pin, int mode, int time);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	void analogInput_enCalibration(int pin, int mode, int unknown);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to ...
	 * ---------------------------------------------------------------------------------------------------- */
	
	 //TODO: Criar funções necessárias para CAN 	 
};

extern ExpertClass Novus_Expert;
