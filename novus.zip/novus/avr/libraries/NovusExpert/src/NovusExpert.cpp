/* ---------.---------.---------.---------.---------.---------.---------.
 * BIBLIOTECA COM FUNÇÕES EXPERT, OU SEJA, NÃO NECESSÁRIAS PARA O FUNCIONAMENTO
 * BÁSICO DO MIXIO. 
 * 
 * Possivelmente algumas funções presentes nas demais bibliotecas serão migradas
 * para a biblioteca EXPERT, como 'setFrequency' que modifica a frequencia de trabalho
 * da rede elétrica.
 *
 * Por sugestão de Marcus Bergel, as seguintes funcionalidades seriam interessantes
 * de serem implementadas nesta biblioteca:
 *
 * 1. Possibilidade de definir a janela de aquisição e, consequentemente, o período de amostragem;
 * 2. Possibilidade de definir a frequência da rede elétrica (necessário para janelas de aquisição não múltiplas de 100ms);
 * 3. Configuração de 3 níveis de filtro de moda para as entradas analógicas (solução para sistemas ruidosos);
 * 4. Configuração de uma saída PWM nativa à saída digital (muito útil para utilização da saída digital em um loop de controle PID); 
 *
 *
 * Caso forem implemetadas, necessário verificar seu funcionamento com o RENESAS.
 *
 */


#include "NovusExpert.h"
#include <Arduino.h>


void ExpertClass::setFrequency(int freq)
{
	uint16_t config[1]={(freq == 50 ? 1 : 2)};
	Modbus.Send(6,(uint16_t)MAIN_FREQ,1,&config[0]);
}
void ExpertClass::analogInput_enFilter(int pin, int mode)
{
	
	/* Enable first order digital filter
	   Mode: ENABLE (1) DISABLE (0)
	*/
	// todo: verificar utilizaçao
	int config[1]={0};

	config[0]=mode;	
	Modbus.Send(FUNC_WRITESINGLE,(uint16_t)((Modbus.AI_FILTER)+(50*(pin-1))),1,&config[0]); 
	Modbus.Check_Error();
}

void ExpertClass::analogInput_enAvg(int pin, int mode, int time)
{
	/* Habilita média por intervalo de tempo.
	   Mode: ENABLE (1) DISABLE (0)
	   time: Tempo de calculo
	   Codigo interno: 4
	*/
	int config[4]={0};

	config[0]=pin;
	config[1]=4; //Codigo interno
	config[2]=mode;	
	config[3]=time;
	
	//TODO: Modbus_send(...)
	Modbus.Check_Error();

}

void ExpertClass::analogInput_enIntegral(int pin, int mode, int time)
{
	/* Habilita Integral por intervalo de tempo.
	   Mode: ENABLE (1) DISABLE (0)
	   time: Tempo de calculo
	   Codigo interno: 5
	*/
	int config[4]={0};

	config[0]=pin;
	config[1]=5; //Codigo interno 
	config[2]=mode;	
	config[3]=time;

	//TODO: Modbus_send(...)
	Modbus.Check_Error();
}

void ExpertClass::analogInput_enDerivative(int pin, int mode, int time)
{
	/* Habilita Derivada por intervalo de tempo.
	   Mode: ENABLE (1) DISABLE (0)
	   time: Tempo de calculo
	   Codigo interno: 6
	*/
	int config[4]={0};

	config[0]=pin;
	config[1]=6; //Codigo interno 
	config[2]=mode;	
	config[3]=time;

	//TODO: Modbus_send(...)
	Modbus.Check_Error();
}

void ExpertClass::analogInput_enCalibration(int pin, int mode, int unknown)
{
	/* Habilita Calibração

	   Mode: ENABLE (1) DISABLE (0)
	   unknown: calibration params
	*/
	// todo: é necessario liberar pro usuário?
	int config[4]={0};

	config[0]=pin;
	config[1]=7; //Codigo interno 
	config[2]=mode;	
	config[3]=unknown;

	//TODO: Modbus_send(...)
	Modbus.Check_Error();
}

ExpertClass Novus_Expert;


