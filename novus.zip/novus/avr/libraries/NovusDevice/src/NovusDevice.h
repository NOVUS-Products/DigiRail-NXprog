/* ---------.---------.---------.---------.---------.---------.---------.
 * 	  NovusIO.h is the  library used to verify which configuration
 * NOVUS MixIO is using. To use the function here, the user MUST be
 * connected to a computer, because this library uses the Serial Monitor 
 * provided by Arduino IDE. User choose which channel, type and mode
 * he wants to read configuration, and the library will print in Serial
 * Monitor the correspondent configuration.
 *
 * Follow the rules specified in function Configs.
 *
 */
 
#include <stdint.h>
#include "InternCommunication.h"
#define NovusOperatingFrequency(x) (Modbus.setFrequency(x))

/* Constants */

// Communication
#define ALL	0
#define digital 1
#define analog 2
#define input 1
#define output 2

	
class ConfigurationClass
{
  private:
  
	#define MAX_DI 4  // MAX number of Digital Inputs
	#define MAX_DO 3  // MAX number of Digital Outputs
	#define MAX_AI 2  // MAX number of Analog Inputs
	#define MAX_AO 2  // MAX number of Analog Outputs
	void readDigtalInput(uint8_t channel);
	void readDigtalOutput(uint8_t channel);
	void readAnalogInput(uint8_t channel);
	void readAnalogOutput(uint8_t channel);
	
  public:
	void Configs(uint8_t channel, uint8_t type, uint8_t mode);
	void RS485Config(void);
	void ETHERNETConfig(void);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function shows to user, how NOVUS MixIO is configured. According to  following rule:
	 *
	 *			type:	(digital = 1, analog = 2, all = 0)
	 *			mode:	 (input = 1, output = 2, all = 0)
	 *	
	 *			chan | type | mode | result	
	 *	
	 *			  X  |  0   |  0   | Read configuration of ALL channels
	 *			  X  |  0   |  1   | Read configuration of ALL input channels
	 *			  X  |  0   |  2   | Read configuration of ALL output channels
	 *			  X  |  1   |  0   | Read configuration of ALL digital channels
	 *			  X  |  1   |  1   | Read configuration of digital input channels
	 *			  X  |  1   |  2   | Read configuration of digital output channels
	 *			  X  |  2   |  0   | Read configuration of ALL analog channels
	 *			  X  |  2   |  1   | Read configuration of analog input channels
	 *			  X  |  2   |  2   | Read configuration of analog output channels
	 *
	 * How to use: 		ReadDevice.Configs(channel, type, mode);
	 *
	 * Input: channel	- the choosen channel to read, accepts from 0 to 4, where 0 will read ALL channels
	 *        type	- the choosen type to read, accepts from 0 to 2, where 0 will read ALL channels, 1 will
					  read only DIGITAL channels and 2 will read only ANALOG channels
	 *        mode	- the choosen mode to read, accepts from 0 to 2, where 0 will read ALL channels, 1 will
					  read only INPUT channels and 2 will read only OUTPUT channels
	 * Output: Answer - Read value from the pin;
	 * ----------------------------------------------------------------------------------------------------	*/
};

extern ConfigurationClass ReadDevice;
