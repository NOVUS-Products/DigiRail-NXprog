/* ESTA BIBLIOTECA LÊ TODOS OS REGISTRADORES DE CONFIGURAÇÃO
 * DE TODAS AS ENTRADAS/SAIDAS ANALÓGICAS/DIGITAIS DE MANEIRA A
 * INFORMAR PELO MONITOR SERIAL DO ARDUINO QUAL É A CONFIGURAÇÃO
 * ATUAL DO MÓDULO MIXIO. -- MUITO ÚTIL PARA TESTES --
 *
 *
 * Basicamente, foram criadas funções separadas para leitura de 	
 * cada entrada/saída (como readDigtalInput)
 * A chamada dessas funções é gerenciada pela função 'Configs', 
 * que printa as informações de cada canal no monitor serial.
 *
 * O mesmo ocorre para a configuração da ETHERNET e RS485.
 */


#include "NovusDevice.h"
#include <Arduino.h>

void ConfigurationClass::Configs(uint8_t channel, uint8_t type, uint8_t mode)
{
	if ((channel<0)||(channel>4)||(type<0)||(type>2)||(mode<0)||(mode>2))	return;
		
	Serial.begin(9600);
	Serial.println(F("\n-------------------------------------------------------------"));
	Serial.println(F("	MixIO is configured as the following states:\n"));
	if (((type == digital)||(type == ALL))&&((mode == input)||(mode == ALL)))
	{
		Serial.println(F("\n -> Digital input"));
		if (channel == 0)
		{
			for( int x=1; x<=MAX_DI; x++)
			{
				channel=x;
				readDigtalInput(x);
			}
			channel=0;
		}
		else
		{
			if (channel <= MAX_DI)
			{
				readDigtalInput(channel);
			}
			else
			{
				Serial.println(F(" ** Digital input doesn't supports this channel"));
			}
		}
	}
	/* --------------------------------------------------------------------------------------- */
	if (((type == digital)||(type == ALL))&&((mode == output)||(mode == ALL)))
	{
		Serial.println(F("\n -> Digital output"));
		if (channel == 0)
		{
			for( int x=1; x<=MAX_DO; x++)
			{
				channel=x;
				readDigtalOutput(x);
			}
			channel=0;
		}
		else
		{
			if (channel <= MAX_DO)
			{
				readDigtalOutput(channel);
			}
			else
			{
				Serial.println(F(" ** Digital output doesn't supports this channel"));
			}
		}
	}
	/*--------------------------------------------------------------------------------------- */
	if (((type == analog)||(type == ALL))&&((mode == input)||(mode == ALL)))
	{
		Serial.println(F("\n -> Analog input"));
		if (channel == 0)
		{
			for( int x=1; x<=MAX_AI; x++)
			{
				channel=x;
				readAnalogInput(x);
			}
			channel=0;
		}
		else
		{
			if (channel <= MAX_AI)
			{
				readAnalogInput(channel);
			}
			else
			{
				Serial.println(F(" ** Analog input doesn't supports this channel"));
			}
		}
	}
	/*--------------------------------------------------------------------------------------- */
	if (((type == analog)||(type == ALL))&&((mode == output)||(mode == ALL)))
	{
		Serial.println(F("\n -> Analog output"));
		if (channel == 0)
		{
			for( int x=1; x<=MAX_AO; x++)
			{
				channel=x;
				readAnalogOutput(x);
			}
			channel=0;
		}
		else
		{
			if (channel <= MAX_AO)
			{
				readAnalogOutput(channel);
			}
			else
			{
				Serial.println(F(" ** Analog output doesn't supports this channel"));
			}
		}
	}
	/*--------------------------------------------------------------------------------------- */
	Serial.println(F("			Finished reading"));	
	Serial.println(F("-------------------------------------------------------------\n"));
}

void ConfigurationClass::RS485Config()
{
	Serial.begin(9600);
	Serial.println(F("\n-------------------------------------------------------------"));
	Serial.println(F("	MixIO RS485 is configured as the following states:\n"));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.RS485_MODBUS_MODE,1,0);
	if (Modbus.res.erro == 0)
	{
		Serial.print(F("\n -> RS485 is working as "));
		if (Modbus.res.valor == 0)
		{
			Serial.print(F("SLAVE number "));	
			Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.RS485_MODBUS_ADDR,1,0);
			if (Modbus.res.erro == 0)
			{
				Serial.println(VALOR);						
			}
		}
		else if (Modbus.res.valor == 1)
		{
			Serial.println(F("GATEWAY"));					
		}
		else if (Modbus.res.valor == 2)
		{
			Serial.println(F("MASTER"));					
		}
		else if (Modbus.res.valor == 3)
		{
			Serial.println(F("SNIFFER"));					
		}
	}
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.RS485_BAUDRATE,1,0);
	if (Modbus.res.erro == 0)
	{
		Serial.print(F("	* Baudrate: "));
		if (Modbus.res.valor == 0)
		{
			Serial.println(F("1200"));					
		}
		else if (Modbus.res.valor == 1)
		{
			Serial.println(F("2400"));					
		}
		else if (Modbus.res.valor == 2)
		{
			Serial.println(F("4800"));					
		}
		else if (Modbus.res.valor == 3)
		{
			Serial.println(F("9600"));					
		}
		else if (Modbus.res.valor == 4)
		{
			Serial.println(F("19200"));					
		}
		else if (Modbus.res.valor == 5)
		{
			Serial.println(F("38400"));					
		}
		else if (Modbus.res.valor == 6)
		{
			Serial.println(F("57600"));					
		}
		else if (Modbus.res.valor == 7)
		{
			Serial.println(F("115200"));					
		}
	}
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.RS485_PARITY,1,0);
	if (Modbus.res.erro == 0)
	{
		Serial.print(F("	* Parity: "));
		if (Modbus.res.valor == 0)
		{
			Serial.println(F("NONE"));					
		}
		else if (Modbus.res.valor == 1)
		{
			Serial.println(F("EVEN"));					
		}
		else if (Modbus.res.valor == 2)
		{
			Serial.println(F("ODD"));					
		}
	}
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.RS485_STOPBIT,1,0);
	if (Modbus.res.erro == 0)
	{
		Serial.print(F("	* Stop bits: "));
		Serial.println(VALOR+1);
	}
	Serial.println(F("			Finished reading"));	
	Serial.println(F("-------------------------------------------------------------\n"));
}


void ConfigurationClass::ETHERNETConfig()
{
	Serial.begin(9600);
	Serial.println(F("\n-------------------------------------------------------------"));
	Serial.println(F("	MixIO ETHERNET is configured as the following states:\n"));
	
	Serial.print(F("       Status: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_ENABLE,1,0); //ETH enable
	/*if(Modbus.res.erro!=0)
	{
		Serial.println(Modbus.res.erro);
	}*/
	if (Modbus.res.valor == 1)
	{
		Serial.print(F("Enabled"));
	}
	else
	{
		Serial.print(F("Disabled"));
	}
	
	Serial.print(F("       DHCP: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_DHCP_ENABLE,1,0); //DHCP enable
	if (Modbus.res.valor == 1)
	{
		Serial.println(F("Enabled"));
	}
	else
	{
		Serial.println(F("Disabled"));
	}
	
	Serial.println(F("********** IP Desejado (estático) ************"));
	
	Serial.print(F("       IPV4: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_IP0,1,0); //IP0 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F("."));
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_IP1,1,0); //IP2 
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 

	
	Serial.print(F("       SUBNET MASK: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_MASK0,1,0); //MASK 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_MASK1,1,0); //MASK 
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	
	Serial.print(F("       GATEWAY: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_GATE0,1,0); //GATEWAY 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_GATE1,1,0); //GATEWAY 
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF));
	
	Serial.print(F("       DNS: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_DNS0,1,0); //DNS 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_DNS1,1,0); //DNS 
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	Serial.println(F("-------------------------------------------------------------\n"));

	
	Serial.println(F("********** IP Utilizados ************"));
	
	Serial.print(F("       IPV4: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_IP0,1,0); //IP0
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_IP1,1,0); //IP2
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 

	
	Serial.print(F("       SUBNET MASK: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_MASK0,1,0); //MASK0
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F("."));
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F("."));
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_MASK1,1,0); //MASK2
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	
	Serial.print(F("       GATEWAY: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_GATE0,1,0); //GATEWAY0
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_GATE1,1,0); //GATEWAY2
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	
	Serial.print(F("       DNS: "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_DNS0,1,0); //DNS0 
	Serial.print((Modbus.res.valor>>8));
	Serial.print(F(".")); 
	Serial.print((Modbus.res.valor & 0xFF));
	Serial.print(F(".")); 
	
	Modbus.Send(FUNC_READSINGLE,(uint16_t)Modbus.ETHERNET_INFO_DNS1,1,0); //DNS2
	Serial.print((Modbus.res.valor>>8)); 
	Serial.print(F("."));
	Serial.println((Modbus.res.valor & 0xFF)); 
	Serial.println(F("-------------------------------------------------------------\n"));
	
	
	Serial.println(F("			Finished reading"));	
	Serial.println(F("-------------------------------------------------------------\n"));
}


void ConfigurationClass::readDigtalInput(uint8_t channel)
{

	// enable		500 
	// function		525 (logic, up, down, time)
	// type 		526 (PNP, NPN, touch)
	// debounce 	527 (user)
	
Serial.print(F("	* Channel "));
Serial.print(channel);
Serial.println(F(": "));
Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.DI_ENABLE)+(50*(channel-1))),1,0);
if (Modbus.res.erro == 0)
{
	if (Modbus.res.valor== 0)
	{
		Serial.println(F("	  Channel is DISABLED\n"));
	}
	else if (Modbus.res.valor== 1)
	{
		Serial.println(F("	  Channel is Enabled"));
		Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.DI_FUNCTION)+(50*(channel-1))),1,0);
		if(Modbus.res.erro ==0)
		{
			if (Modbus.res.valor== 0)	
			{
				Serial.println(F("	  Channel acting as logic"));
			}
			else if (Modbus.res.valor== 1)	
			{
				Serial.println(F("	  Channel acting as counter UP"));
			}
			else if (Modbus.res.valor== 2)	
			{
				Serial.println(F("	  Channel acting as counter DOWN"));
			}
			else if (Modbus.res.valor== 3)	
			{
				Serial.println(F("	  Channel acting as counter of TIME"));
			}
		}
		Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.DI_TYPE)+(50*(channel-1))),1,0);
		if(Modbus.res.erro ==0)
		{
			if (Modbus.res.valor== 0)
			{
				Serial.println(F("	  Channel is configured with PNP MODE"));
			}
			else if (Modbus.res.valor== 1)	
			{
				Serial.println(F("	  Channel is configured with NPN MODE"));
			}
			else if (Modbus.res.valor== 2)
			{
				Serial.println(F("	  Channel is configured with DRY CONTACT MODE"));
			}
		}
		Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.DI_DEBOUNCE)+(50*(channel-1))),1,0);
		if(Modbus.res.erro ==0)
		{
			Serial.print(F("	  Channel's debounce is "));
			Serial.print(Modbus.res.valor);
			Serial.println(F(" ms\n"));
		}
	}
	}	
}
void ConfigurationClass::readDigtalOutput(uint8_t channel)
{
	
		// enable		900
		// function		925 (instant, pulse, train)
		// pulse HIGH	926 (user) --> se type > 0
		// pulse TOTAL 	927 (user) --> se type > 0
		// pulse NUM	928 (user) --> se type > 1
		
	int aux=0;
	Serial.print(F("	* Channel "));
	Serial.print(channel);
	Serial.println(F(": "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.DO_ENABLE)+(50*(channel-1))),1,0);
	if(Modbus.res.erro ==0)
	{
		if (Modbus.res.valor== 0)
		{
			Serial.println(F("	  Channel is DISABLED\n"));
		}
		else if (Modbus.res.valor== 1)
		{
			Serial.println(F("	  Channel is Enabled"));
			Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.DO_FUNCTION)+(50*(channel-1))),1,0);
			if(Modbus.res.erro ==0)
			{
				if (Modbus.res.valor== 0)
				{
					Serial.println(F("	  Channel acting as logic"));
				}
				else if (Modbus.res.valor== 1)
				{
					Serial.println(F("	  Channel acting as a single pulse"));
				}
				else if (Modbus.res.valor== 2)
				{
					Serial.println(F("	  Channel acting as a multiple pulses"));
				}
				aux=Modbus.res.valor;
			}
			if ((aux > 0)&&(aux < 3))
			{
				Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.DO_PULSE_TIME)+(50*(channel-1))),1,0);
				if(Modbus.res.erro ==0)
				{
					Serial.print(F("	  Pulse is HIGH for "));
					Serial.print(Modbus.res.valor);
					Serial.println(F(" x 100ms"));
				}
				Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.DO_PULSE_PERIOD)+(50*(channel-1))),1,0);
				if(Modbus.res.erro ==0)
				{
					Serial.print(F("	  Pulse TOTAL length is "));
					Serial.print(Modbus.res.valor);
					Serial.println(F(" x 100ms"));
				}
				if (aux == 2)
				{
					Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.DO_NUMBER_OF_PULSES)+(50*(channel-1))),1,0);
					if(Modbus.res.erro ==0)
					{
						Serial.print(F("	  Number of Pulses is "));
						Serial.print(Modbus.res.valor);
						Serial.println(F("\n"));
					}
					
				}
				else 
				{
					Serial.println(F(""));
				}
			}
		}
	}
}
void ConfigurationClass::readAnalogInput(uint8_t channel)
{
		
		// enable		1300
		// function		1325 (tcj, tck, tct, tcn, tcr, tcs, tcb, tce, pt100, pt1000, ntc, 0-60mV, 0-5V, 0-10V, 0-20mA, 4-20mA)
		// unity 		1326 (ºC, ºF)
		// scale low 	1328 e 1329 (user) --> se type > 9
		// scale high 	1330 e 1331 (user) --> se type > 9
		
	Serial.print(F("	* Channel "));
	Serial.print(channel);
	Serial.println(F(": "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AI_ENABLE)+(50*(channel-1))),1,0);
	if(Modbus.res.erro ==0)
	{
		if (Modbus.res.valor== 0)	
		{
			Serial.println(F("	  Channel is DISABLED\n"));
		}
		else if (Modbus.res.valor== 1)
		{
			Serial.println(F("	  Channel is Enabled"));
			Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AI_TYPE)+(50*(channel-1))),1,0);
			if(Modbus.res.erro ==0)
			{
				if (Modbus.res.valor== 0)
				{
					Serial.println(F("	  Channel reading a thermocouple type J"));
				}
				else if (Modbus.res.valor== 1)
				{
					Serial.println(F("	  Channel reading a thermocouple type K"));
				}
				else if (Modbus.res.valor== 2)
				{
					Serial.println(F("	  Channel reading a thermocouple type T"));
				}
				else if (Modbus.res.valor== 3)
				{
					Serial.println(F("	  Channel reading a thermocouple type N"));
				}
				else if (Modbus.res.valor== 4)
				{
					Serial.println(F("	  Channel reading a thermocouple type R"));
				}
				else if (Modbus.res.valor== 5)
				{
					Serial.println(F("	  Channel reading a thermocouple type S"));
				}
				else if (Modbus.res.valor== 6)
				{
					Serial.println(F("	  Channel reading a thermocouple type B"));
				}
				else if (Modbus.res.valor== 7)
				{
					Serial.println(F("	  Channel reading a thermocouple type E"));
				}
				else if (Modbus.res.valor== 8)
				{
					Serial.println(F("	  Channel reading a PT100"));
				}
				else if (Modbus.res.valor== 9)
				{
					Serial.println(F("	  Channel reading a PT1000"));
				}
				else if (Modbus.res.valor== 10)
				{
					Serial.println(F("	  Channel reading a NTC"));
				}
				else if (Modbus.res.valor== 11)
				{
					Serial.println(F("	  Channel reading 0-60mV"));
				}
				else if (Modbus.res.valor== 12)
				{
					Serial.println(F("	  Channel reading 0-5V"));
				}
				else if (Modbus.res.valor== 13)
				{
					Serial.println(F("	  Channel reading 0-10V"));
				}
				else if (Modbus.res.valor== 14)	
				{
					Serial.println(F("	  Channel reading 0-20mA"));
				}
				else if (Modbus.res.valor== 15)
				{
					Serial.println(F("	  Channel reading 4-20mA"));
				}
			}
			if (Modbus.res.valor < 10)
			{
				Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AI_UNIT)+(50*(channel-1))),1,0);
				if(Modbus.res.erro ==0)
				{
					if (Modbus.res.valor== 0)
					{
						Serial.println(F("	  Channel reading the temperature in Celsius degrees\n"));
					}
					else if (Modbus.res.valor== 1)
					{
						Serial.println(F("	  Channel reading the temperature in Fahreneit degrees\n"));
					}
				}
			}
			else
			{
				uint32_t aux2=0;
				Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AI_LOWSCALE_LO)+(50*(channel-1))),1,0);
				if(Modbus.res.erro ==0)
				{
					aux2=Modbus.res.valor;
				}
				Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AI_LOWSCALE_HI)+(50*(channel-1))),1,0);
				if(Modbus.res.erro ==0)
				{
					aux2+=(uint32_t)(Modbus.res.valor<<16);
				}
				
				Serial.print(F("	  The scale goes from ")); 
				Serial.print(aux2);
				Serial.print(F(" to "));
				
				
				Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AI_HIGHSCALE_LO)+(50*(channel-1))),1,0);
				if(Modbus.res.erro ==0)
				{
					aux2=Modbus.res.valor;
				}
				Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AI_HIGHSCALE_HI)+(50*(channel-1))),1,0);
				if(Modbus.res.erro ==0)
				{
					aux2+=(uint32_t)(Modbus.res.valor<<16);
				}
				
				Serial.print(aux2);
				Serial.println(F("\n"));
			}
		}
	}
}
void ConfigurationClass::readAnalogOutput(uint8_t channel)
{
	
		// enable		1400
		// function		1425 (0-20mA, 4-20mA, 0-10V)
		// range		1426 (%x100, 0-32k)
		
	Serial.print(F("	* Channel "));
	Serial.print(channel);
	Serial.println(F(": "));
	Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AO_ENABLE)+(50*(channel-1))),1,0);
	if(Modbus.res.erro ==0)
	{
		if (Modbus.res.valor== 0)
		{
			Serial.println(F("	  Channel is DISABLED\n"));
		}
		else if (Modbus.res.valor== 1)
		{
			Serial.println(F("	  Channel is Enabled"));
			Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AO_TYPE)+(50*(channel-1))),1,0);
			if(Modbus.res.erro ==0)
			{
				if (Modbus.res.valor== 0)
				{
					Serial.println(F("	  Channel acting as 0-20mA"));
				}
				else if (Modbus.res.valor== 1)
				{
					Serial.println(F("	  Channel acting as 4-20mA"));
				}
				else if (Modbus.res.valor== 2)
				{
					Serial.println(F("	  Channel acting as 0-10V"));
				}
			}
			Modbus.Send(FUNC_READSINGLE,(uint16_t)((Modbus.AO_RANGE)+(50*(channel-1))),1,0);
			if(Modbus.res.erro ==0)
			{
				if (Modbus.res.valor== 0)
				{
					Serial.println(F("	  Channel acting in percent scale\n"));
				}
				else if (Modbus.res.valor== 1)
				{
					Serial.println(F("	  Channel acting in 0-32.000 scale\n"));
				}
			}
		}
	}
}


ConfigurationClass ReadDevice;


