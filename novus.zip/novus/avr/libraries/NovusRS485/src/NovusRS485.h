/*
 *
 * 	
 */
 
#include <stdint.h>
#include "InternCommunication.h"
#define NovusOperatingFrequency(x) (Modbus.setFrequency(x))

/* Constants */
//#define DEBUG_485

/* RS485 */
// Mode
#define SERVER 0
#define GATEWAY 1
#define MASTER 2
#define SNIFFER 3

// Baudrate
#define _1200 0
#define _2400 1
#define _4800 2
#define _9600 3
#define _19200 4
#define _38400 5
#define _57600 6
#define _115200 7

//Parity
#define NONE 0
#define EVEN 1
#define ODD 2

	
class RS485Class
{
  private:
	int RS485_active = 1;
		

  public:	
	
	int enable(uint8_t mode, uint8_t Address,uint32_t Baudrate, uint8_t Parity, uint8_t Stopbits);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to confiure the RS485 use. User MUST provide the following parameters,
	 * Address used in the ModBus communication, the desired Baud Rate, the numbers of Parity and Stop bits
	 * with this filled the communication is enable and working.
	 *
	 * How to use: 		int error = NovusRS485.enable(Address, Baudrate, Parity, stopbits);
	 *
	 * Input: Mode		- Select the desired opperation mode, Slave(0), Gateway(1), Master(2), Sniffer(3)
	 *		  Address	- Address of Modbus
	 *		  Baudrate	- Baudrate of communication following documentation
	 *		  Parity	- Number of parity bits, receives between 0 and 2
	 *		  stopbits	- Pin that will be read, receives 1 or 2
	 *
	 * Output: error	- 0 if no error occurred otherwise return the correspondent value of error.
	 * ----------------------------------------------------------------------------------------------------	*/
	void disable();
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to disable RS485.
	 *
	 * How to use: 		NovusRS485.disable();
	 *
	 * ----------------------------------------------------------------------------------------------------	*/
	int communicate(uint16_t* sendValue, uint16_t sendBytes, uint16_t* receiveValue, uint16_t receiveBytes);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to send a data stream to RS485, and will receive in the same function the
	 * response. User must knonw at least the number of bytes received in the response.
	 *
	 * How to use: 		int error = NovusRS485.communicate(&send[0], sendBytes, &receive[0], receiveBytes);
	 *
	 * Input: &send[0]		- Pointer to Data input to RS485
	 *		  sendBytes		- Number of bytes sent to RS485
	 *		  &receive[0]	- Pointer to Data output from RS485
	 *		  receiveBytes	- Number of bytes received from RS485
	 *
	 * Output: error		- 0 if no error occurred otherwise return the correspondent value of error.
	 * ----------------------------------------------------------------------------------------------------	*/
	void flush(uint16_t* receiveValue, uint16_t receiveBytes);
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to reset all values of data output from RS485 to 0.
	 *
	 * How to use: 		NovusRS485.flush(&receive[0], receiveBytes);
	 *
	 * Input: &receive[0]	- Pointer to Data output from RS485
	 *		 receiveBytes	- Number of bytes received from RS485
	 *
	 * ----------------------------------------------------------------------------------------------------	*/
	void sniffer_seconds(uint16_t time);// TODO: testar
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to listen the network for "time" provided in seconds.
	 * Function receives an uint32, so  user can sniffer for 18 hours.	
	 *
	 * How to use: 		NovusRS485.sniffer_seconds(time);
	 *
	 * Input: time - time to listen the network
	 *
	 * ----------------------------------------------------------------------------------------------------	*/
	int sniffer_bytes(uint16_t size, uint16_t Timeout, uint16_t* receiveValue);// TODO: testar
	/* ----------------------------------------------------------------------------------------------------
	 *	This function allows user to listen the network for the number of bytes provided in "size".
	 * Function receives an uint32, so  user can sniffer 65525 frames.
	 *
	 * How to use: 		NovusRS485.sniffer_bytes(quantity,timeout,&receive[0]);
	 *
	 * Input: quantity 		- Number of bytes to receive
	 *		  timeout		- Had a timeout and the number of bytes wasn't received
	 *		  &receive[0]	- Pointer to Data output from RS485	  
	 *
	 * Output: error		- 0 if no error occurred otherwise return the correspondent value of error.
	 * ----------------------------------------------------------------------------------------------------	*/
	void applyConfig();
	/* ----------------------------------------------------------------------------------------------------
	 * This function is used to trigger a reconfiguration procedure inside the uC. It's possible to call 
	 * many configuration functions before calling Novus.applyConfig(), but if this function is not called,
	 * none of the modifications will be active.
	 *
	 * MUST BE CALLED AFTER ANY PIN/PORT/CHANNEL RECONFIGURATION!
	 *
	 * Ex.: 
	 * Novus.digitalOutput_mode(...); //Sets pin as digital output
	 * Novus.analogInput_mode(...); // Sets pin as analog input
	 * Novus.applyConfig(); //Reconfigure uC based on previous configuration set
	 * ----------------------------------------------------------------------------------------------------	*/
};

extern RS485Class Novus_RS485;
