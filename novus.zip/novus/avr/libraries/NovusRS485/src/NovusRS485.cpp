/* ---------.---------.---------.---------.---------.---------.---------.
 * ESTA BIBLIOTECA PERMITE A UTILIZAÇÃO DA INTERFACE RS485 DO MIXIO.
 * DIFERENTES MODOS DE TRABALHO SÃO SUPORTADOS, SENDO ELES:
 *
 * -- Slave
 * * Habilita o modo SLAVE da 485 do MixIO. Este funcionamento é o padrão
 * * do dispositivo.
 * --
 *
 * -- Gateway
 * * Caso a ETHERNET estiver habilitada e a RS485 em modo gateway,
 * * se o PDU recebido pela ETHERNET nao for para o endereço do MixIO,
 * * o PDU vindo da ETHERNET é repassado para a RS485.
 * --
 *
 * -- Master
 * * Permite o envio de qualquer mensagem desejada para a RS485.
 * * O envio da mensagem é realizado pela função 'communicate', onde
 * * a mensagem deve ser passada pelo vetor sendValue. Após o envio da 
 * * mesma, o dispositivo aguarda uma resposta vinda da 485 e a retorna
 * * no vetor 'receiveValue'. 
 * --
 *
 * -- Sniffer
 * * No modo SNIFFER, o dispositivo é conectado a alguma rede RS485 e retorna
 * * ao usuário a mensagem encontrada.
 * * Pela função sniffer_bytes o usuário especifica o numero de bytes a serem
 * * lidos da 485.
 * *
 * * TODO: implementar um modo sniffer por tempo, onde tudo é enviado para o Monitor Serial do arduino?
 * --
 *
 *
 * O MODO DE TRABALHO É SELECIONADO POR MEIO DA FUNÇÃO ENABLE.
 * 
 * Um applyConfig deve ser enviado após a utilização de qualquer comando de configuração.
 *
 * IMPORTANTE: DIVERSAS MODIFICAÇÕES FORAM REALIZADAS NO FIRMWARE DO RENESAS
 * PARA PERMITIR O CORRETO FUNCIONAMENTO DOS NOVOS MODOS (MASTER E SNIFFER) 
 * DA 485. 
 * EX.: Para informar ao Renesas que uma mensagem deve ser escrita na RS485, 
 * primeiramente enviamos um PDU MODBUS com a função 'exception' (função modbus 43), 
 * onde estará encapsulada a mensagem real que deve ser enviada a RS485. 
 * Procedimento análogo ao 'tunelamento' da mensagem. 
 */


#include "NovusRS485.h"
#include <Arduino.h>

/* --------------------------------------------------------------------------------------
 *								  	RS485 communication	
 * -------------------------------------------------------------------------------------- */
 
 int RS485Class::enable(uint8_t Mode,uint8_t Address,uint32_t Baudrate, uint8_t Parity, uint8_t Stopbits)
 {
	 /*
	  * 
	  * mode: { 0- SLAVE, 1- GATEWAY, 2- MASTER, 3- SNIFFER }
	  * Baudrate: { 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200 }
	  * Parity: {NONE, EVEN, ODD}	or	{0, 1, 2}
	  * stopbits: {1, 2}
	  * 
	  */
	 if ((Mode < 0)||(Mode > 3))
	 {
		 return 40;
	 }
	 if ((Address < 0)||(Address > 247))
	 {
		 return 41;
	 }
	 if ((Baudrate < 0)||(Baudrate > 7))
	 {
		 if ((Baudrate != 1200)&&(Baudrate != 2400)&&(Baudrate != 4800)&&
			 (Baudrate != 9600)&&(Baudrate != 19200)&&(Baudrate != 38400)&&
			 (Baudrate != 57600)&&(Baudrate != 115200))
		 {
			 return 42;
		 }
	 }
	 if ((Parity < 0)||(Parity > 2))
	 {
		 return 43;
	 }
	 if ((Stopbits < 1)||(Stopbits > 2))
	 {
		 return 44;
	 }
	 
	 uint16_t config[5] = {0};
	  
	 //Configure Mode and address
	 if (Mode > 0)
	 {
		config[0] = Mode;
		config[1] = 1;
	 }
	 else
	 {
		 config[0] = 0;
		 if (Address == 0)
		 {
			Address = 1;
		 }
		 config[1] = Address;
	 }
	 
	 // Configure Baudrate
	 if ((Baudrate >= 0) && (Baudrate <= 7))
	 {
		 config[2] = Baudrate;
	 }
	 else if (Baudrate == 1200)
	 {
		 config[2] = 0;		 
	 }
	 else if (Baudrate == 2400)
	 {
		 config[2] = 1;		 
	 }
	 else if (Baudrate == 4800)
	 {
		 config[2] = 2;		 
	 }
	 else if (Baudrate == 9600)
	 {
		 config[2] = 3;		 
	 }
	 else if (Baudrate == 19200)
	 {
		 config[2] = 4;		 
	 }
	 else if (Baudrate == 38400)
	 {
		 config[2] = 5;		 
	 }
	 else if (Baudrate == 57600)
	 {
		 config[2] = 6;		 
	 }
	 else if (Baudrate == 115200)
	 {
		 config[2] = 7;		 
	 }
	 else
	 {
		 config[2] = 4; // Default Baud rate: 19200
	 }
	 
	 // Configure Parity
	 if ((Parity<0) || (Parity>2))
	 {
		 config[3] = 2; //Default value: ODD parity
	 }
	 else
	 {
		 config[3] = Parity;
	 }
	 
	 // Configure Stop bits
	 if ((Stopbits<1) || (Stopbits>2))
	 {
		 config[4] = 0; //Default value: 1 Stop bit
	 }
	 else
	 {
		 config[4] = Stopbits-1;
	 }
	 
	 // Writing the mode
	 Modbus.Send(16,(uint16_t)Modbus.RS485_MODBUS_MODE,2,&config[0]);
	 if (ERROR !=0)
	 {
		 return ERROR;
	 }
	 // Configuring RS485
	 Modbus.Send(16,(uint16_t)Modbus.RS485_BAUDRATE,3,&config[2]);
	 if (ERROR !=0)
	 {
		 return ERROR;
	 }
	 
	Modbus.applyConfig();
	return ERROR;
 }
 
 void RS485Class::disable()
 {
	 // Disable RS485
	 RS485_active = 0;
 }
 
 int RS485Class::communicate(uint16_t* sendValue, uint16_t sendBytes, uint16_t* receiveValue, uint16_t receiveBytes)
 {
	if(RS485_active == 1)
	{
		if ((sendBytes <= 0)||(sendBytes > 256))
		{
			return 47;
		}
		if ((receiveBytes < 0)||(receiveBytes > 256))
		{
			return 48;
		}
		 uint8_t Modbus_PDU[sendBytes + 6]={0};
		 uint8_t Modbus_PDU_r[receiveBytes + 6]={0};
		 
		 /* Max PDU: 262 ( Slave + MB function + NOVUS function + Quantity + 2*CRC ==> 256*Data )
		  *                           |   0   |   1  |   2   |        3   	   |	  4   ... | 4 + N | 5 + N |
		  * Encapsulate:  43 (48) --> | Slave | 0x2B | rs485 |   sendBytes(N)  | ... Data ... | CRC L | CRC H |
		  * Return:       43 (48) <-- | Slave | 0x2B | rs485 | receiveBytes(N) | ... Data ... | CRC L | CRC H |
		  *
		  * note: receiveBytes can be different then sendBytes;
		  */
		  
		 Modbus_PDU[0] = Slave_addr; 	// Slave address
		 Modbus_PDU[1] = 43; 			// 43- Exception function
		 Modbus_PDU[2] = 48; 			// Function ( RS485 )
		 Modbus_PDU[3] = sendBytes; 	// sendBytes
		 for (int x=0; x<sendBytes; x++)
		 {
			 Modbus_PDU[4+x] = *(sendValue+x); // Data
		 }				 
		   
		 //Calcular CRC
		 uint16_t u16CRC = Modbus.getCRC( &(Modbus_PDU[0]), sendBytes + 4);
		 Modbus_PDU[4 + sendBytes + 1] 	=  (uint8_t) (u16CRC >> 8);
		 Modbus_PDU[4 + sendBytes]  		=  (uint8_t) (u16CRC & 0xFF); 
		 
#ifdef DEBUG_485
		 Serial.println(F("exm: [ Ad Ex Fn Qn | ... DATA ... | Cl Ch ]"));
		 Serial.print(F("PDU: [ "));
		 for (int x=0; x < (sendBytes + 6); x++)
		 {
			 if (Modbus_PDU[x] > 0XF)
			 {
				 Serial.print(Modbus_PDU[x],HEX);
			 }
			 else
			 {
				Serial.print(F("0"));
				Serial.print(Modbus_PDU[x],HEX);
			 }
			 
			 Serial.print(F(" "));
			 if (x == 3)
			 {
				 Serial.print(F("| "));
			 }
			 if (x == (3 + sendBytes))
			 {
				 Serial.print(F("| "));
			 }
			 if (x == (sendBytes + 5))
			 {
				 Serial.print(F("]\nP_r: [ "));
			 }
		 }
#endif
		 
		 int erro=0;
		 int tries = 0;
		 do 
		 { 
			 erro=0;
			  
			 // Enviando PDU
			 for (int x=0; x < (sendBytes + 6); x++)
			 {
				 Serial1.write(Modbus_PDU[x]); //Enviar o valor do byte para o Renesas
				 //delay(1);
			 }
			 
			 int cont=0;
			 unsigned long current=0, previous = millis();
			 erro=0;
			 //Recebendo PDU
			 do
			 {
				 current = millis();
				 if (current - previous >= 4000 )
				 {
#ifdef DEBUG_485
					 Serial.print(F("Timeout, received: "));
					 Serial.print(cont);
					 Serial.print(F(" bytes\n"));
#endif
					 if ((cont == 7)&&(Modbus_PDU_r[3] == 1))
					 {
						 if (Modbus_PDU_r[4] == 0x0F)
						 {
							 erro = 51; // erro:modo slave
						 }
						 else if (Modbus_PDU_r[4] == 0xF0)
						 {
							 erro = 52; // erro: modo gateway
						 }
						 else if (Modbus_PDU_r[4] == 0xFF)
						 {
							 erro = 53; // erro: não recebeu da rs485
						 }
					 }
					 erro = 99; //timeout
					 break;
				 } 
				 
				 if (Serial1.available()) //Esperar a chegada de um byte
				 {
					Modbus_PDU_r[cont]= Serial1.read();
					cont++;
					//delay(1);
				 }
			 } while(cont < (receiveBytes + 6)); //Aguardar a mensagem completa
			 
			 tries = (erro == 50 ? tries + 1 : cont_tries);
		 }while(tries < cont_tries);
		
		 delay(10); //Delay between sends
		
#ifdef DEBUG_485
		 for (int x=0; x < (receiveBytes + 6); x++)
		 {
			if (Modbus_PDU_r[x] > 0XF)
			{
				Serial.print(Modbus_PDU_r[x],HEX);
			}
			else
			{
			  Serial.print(F("0"));
			  Serial.print(Modbus_PDU_r[x],HEX);
			}
			Serial.print(F(" "));
			if (x == 3)
			{
				Serial.print(F("| "));
			}
			if (x == (3 + receiveBytes))
			{
				Serial.print(F("| "));
			}
			if (x == (receiveBytes + 5))
			{
				Serial.println(F("]\n"));
			}
		 }
#endif
		 if (erro == 0)
		 {
			 // Confirming response
			 if(!Modbus.verificaCRC(Modbus_PDU_r,receiveBytes + 4))
			 {
				 erro = 3; // CRC is right ?
			 }
			 if(Modbus_PDU_r[0] != Modbus_PDU[0])
			 {
				 erro = 4; // Same slave address ?
			 }
			 if(Modbus_PDU_r[1] != Modbus_PDU[1])
			 {
				 erro = 5; // Same function number ?
			 }
			 
			 // returning the reading values
			 for (int x=0; x<receiveBytes ;x++)
			 {
				 *(receiveValue+x)=Modbus_PDU_r[x+4];
			 }
			 return erro;
		}			
		else
		{
			return erro; //error in TX or RX
		}
	}
	else
	{
		return 46;
	}
 }
 
 void RS485Class::flush(uint16_t* receiveValue, uint16_t receiveBytes)
 {
	 for(int x=0; x<receiveBytes; x++)
	 {
		 *(receiveValue+x)=0x0;
	 }
 }
  
 void RS485Class::sniffer_seconds(uint16_t time)
 {
	 // TODO: rever
	if(RS485_active)
	{
		 // Writing the mode
		 uint16_t config[2]={3,0};
		 Modbus.Send(16,(uint16_t)Modbus.RS485_MODBUS_MODE,2,&config[0]);
		 if (ERROR !=0)
		 {
			 return ERROR;
		 }
		 Modbus.applyConfig();
		 if (ERROR !=0)
		 {
			 return ERROR;
		 }

		 uint8_t Modbus_PDU[7]={0};
		 char sniffer = ' ';
		 
		 /*                           |   0   |   1  |   2   |    3    |    4    |   5   |   6   |
		  * Encapsulate:  43 (49) --> | Slave | 0x2B | sniff | Value H | Value L | CRC L | CRC H |
		  *
		  * Just print what is received.
		  *
		  */
		  
		 Modbus_PDU[0] = Slave_addr; // Slave address
		 Modbus_PDU[1] = 43; 		 // 43- Exception function
		 Modbus_PDU[2] = 49; 		 // Function ( sniff )
		 Modbus_PDU[3] = 0; 		 // "Time configure"
		 Modbus_PDU[4] = 0; 		 // "Time configure"
		 
		 //Calcular CRC
		 uint16_t u16CRC = Modbus.getCRC( &(Modbus_PDU[0]), 5);
		 Modbus_PDU[5]  =  (uint8_t) (u16CRC & 0xFF); 
		 Modbus_PDU[6] 	=  (uint8_t) (u16CRC >> 8);
		 
		 // Enviando PDU
		 for (int x=0; x < 7; x++)
		 {
			 Serial1.write(Modbus_PDU[x]); //Enviar o valor do byte para o Renesas
			 //delay(1);
		 }
		 
		 uint16_t cont=0;
		 if (!Serial)
		 {
			 Serial.begin(9600);
		 }
		 Serial.println("Sniffer started");
		 unsigned long current=0, previous = millis();			 	 
		 //Recebendo PDU
		 do 
		 { 
		 	 current = millis();
			 if (current - previous >= time*1000 )
			 {
				Serial.println("Sniffer stoped by timer sent");
				Serial1.write(0x24);
				break;
			 }
			 
			 if (Serial1.available()) //Esperar a chegada de um byte
			 {
				sniffer = Serial1.read();
				if (sniffer > 0XF)
				{
					Serial.print(sniffer,HEX);
				}
				else
				{
				  Serial.print(F("0"));
				  Serial.print(sniffer,HEX);
				}
				
				cont ++;
				if (cont == 25)
				{
					cont = 0;
					Serial.print(F("\n"));
				}
				else
				{
					Serial.print(F(" "));						
				}
			}
		 }while(1);
	}
	else
	{
		return 46;
	}	 
 }
  
 int RS485Class::sniffer_bytes(uint16_t size, uint16_t Timeout, uint16_t* receiveValue)
 {
	if(RS485_active)
	{		 
		 uint8_t Modbus_PDU[6]={0};
		 uint8_t sniffer = ' ';
		 
		 /*                           |   0   |   1  |   2   |   3   |   4   |   5   |
		  * Encapsulate:  43 (49) --> | Slave | 0x2B | sniff | Value | CRC L | CRC H |
		  *
		  * Just print what is received.
		  *
		  */
		 
		 Modbus_PDU[0] = Slave_addr; // Slave address
		 Modbus_PDU[1] = 43; 		 // 43- Exception function
		 Modbus_PDU[2] = 49; 		 // Function ( sniff )
		 Modbus_PDU[3] = size;
		 
		 //Calcular CRC
		 uint16_t u16CRC = Modbus.getCRC( &(Modbus_PDU[0]), 4);
		 Modbus_PDU[4]  =  (uint8_t) (u16CRC & 0xFF); 
		 Modbus_PDU[5] 	=  (uint8_t) (u16CRC >> 8);
		 
		 // Enviando PDU
		 for (int x=0; x < 6; x++)
		 {
			 Serial1.write(Modbus_PDU[x]); //Enviar o valor do byte para o Renesas
			 //delay(1);
		 }
		 
		 uint16_t cont=0;
		 unsigned long previous=millis(), current=0;
		 if (!Serial)
		 {
			 Serial.begin(9600);
		 }
#ifdef DEBUG_485
		 Serial.println("Sniffer started");		 	 
#endif
		 //Recebendo PDU
		 do 
		 {
			 if (Serial1.available()) //Esperar a chegada de um byte
			 {
				sniffer = Serial1.read();
				*(receiveValue + cont) = sniffer;
				cont++;
				
				// Testing if has a message in RS485
				if (( *(receiveValue + 0) == 0x07 ) && /* Slave address */
					( *(receiveValue + 1) == 0x2B ) && /* Function MB 43 */
					( *(receiveValue + 2) == 0x32 ) && /* ERROR */
					( *(receiveValue + 3) == 0xFF ) && /* ERROR */
					( *(receiveValue + 4) == 0x24 ) && /* CRC LOW */
					( *(receiveValue + 5) == 0x78 ) )  //CRC HIGH
				{
					
#ifdef DEBUG_485
					Serial.println("\nSniffer stopped by no data in RS485");	 
#endif
					
					flush(receiveValue,size);
					return 53;
				}
				//Data completed
				if (cont >= (size +6) )
				{
#ifdef DEBUG_485
					Serial.println("\nSniffer stopped by size sent");	 
#endif
					for (int x=0; x < size; x++)
					{
						*(receiveValue + x) = *(receiveValue + x + 6); //adjust user array
						*(receiveValue + x + 6) = 0; //adjust user array
					}
					return 0;
				}
				previous=millis();
			}
			else
			{				
				current=millis();
				if (current - previous >= Timeout)
				{
#ifdef DEBUG_485
					Serial.print("\nSniffer stopped by timeout. Bytes read:");	 
					Serial.println(cont);
#endif				
					return 50;
				}
			}
		 }while(1);
	}
	else
	{
		return 46;
	}
 }
 
void RS485Class::applyConfig()
{
	Modbus.applyConfig();
}

 RS485Class Novus_RS485;


