/*
  This file is part of the ArduinoRS485 library.
  Copyright (c) 2018 Arduino SA. All rights reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "nx_virtual_rs485.h"
#include "novus/libmodbus/modbus-rtu.h" /* we need to use crc16 in this class */
#include "novus/libmodbus/modbus.h"    

#define TIMEOUT_COMM_MS 200

// Debug options
// #define DEBUG_VIRTUAL_RS485

#ifdef DEBUG_VIRTUAL_RS485
#define DUMP_PDU(buffer, size)  {for (uint16_t x = 0; x < size; x++)\
								                {\
  									            if(x == 0) \
	  									            Serial.print(F("[ "));\
		  							            if (buffer[x] > 0XF)\
			  							            Serial.print(buffer[x],HEX);\
				  					            else\
					  				            {\
			  		  					          Serial.print(F("0"));\
							  			            Serial.print(buffer[x],HEX);\
            					  				}\
						              			Serial.print(" ");\
									              if (x == (size-1))\
										              Serial.println(F("]\n"));\
		 						                } \
               									Serial.flush();}


#else
#define DUMP_PDU(buffer, size) 
#endif
// DigiRail slave address
#define INDOOR_GATEWAY_ADDRESS 0x07

// Modbus MEI (Modbus Encapsulated Interface) definitions
#define MEI_COMMAND             43
// MEI special commands
#define MEI_SEND_PACKET_SP_CMD    0x33
#define MEI_READ_PACKET_SP_CMD    0x32
#define MEI_SET_SLAVE_ADD_SP_CMD  0x34
#define MEI_GET_PACKET_SIZE_CMD   0x35
#define MEI_CLEAR_SLAVE_ADD_SP_CMD  0x36
#define MEI_GET_SLAVE_ADD_SP_CMD  0x37

#define MEI_MESSAGE_OVERHEAD    6 // Slave address (1 byte), Command (1 byte), Special command (1 byte), Count (1 byte), CRC (2 bytes)
#define MEI_MAX_PAYLOAD_SIZE    MODBUS_MAX_PDU_LENGTH - MEI_MESSAGE_OVERHEAD
#define MEI_ADDR_IDX            0
#define MEI_COMMAND_IDX         1
#define MEI_SP_COMMAND_IDX      2
#define MEI_SIZE_IDX            3
#define MEI_PAYLOAD_IDX         4
// MEI response sizes definitions
#define MEI_EMPTY_RESPONSE_SIZE 6
#define MEI_EMPTY_REQUEST_SIZE  6
#define MEI_CRC_SIZE            2

#define PACKET_SIZE_RESPONSE_LEN 7

#define CLEAR_IBUF()    { \
                          _ibuf_empty = true; \
                          _ibuf_idx = 0; \
                          _ibuf_size = 0;\
                        }
#define RELOAD_IBUF(s)   { \
                          sendMEIRequest(MEI_READ_PACKET_SP_CMD); \
                          _ibuf_size = receiveMEIResponse(_ibuf, sizeof(_ibuf)); \
                          _ibuf_idx = 0; \
                          if(_ibuf_size == 0) \
                          { \
                            _ibuf_empty = true; \
                          } \
                          else \
                          { \
                            _ibuf_empty = false; \
                          } \
                        }
#define READ_FROM_IBUF()  ({ \
                            uint8_t retval; \
                            if(!_ibuf_empty) \
                            { \
                              if (_ibuf_idx < _ibuf_size) \
                                retval = _ibuf[_ibuf_idx]; \
                              else \
                                retval = 0; \
                              _ibuf_idx++; \
                              if(_ibuf_idx >= _ibuf_size) \
                                _ibuf_empty = true; \
                            } \
                            else \
                              retval = 0; \
                            retval; \
                          })


#define INDOOR_SERIAL Serial1
NOVUSVirtualRS485Class::NOVUSVirtualRS485Class() :
  _transmisionBegun(false),
  _ibuf_empty(true),
  _ibuf_idx(0),
  _ibuf_size(0)
{
}

void NOVUSVirtualRS485Class::begin(unsigned long baudrate, uint16_t config)
{
  // TODO: configurar serial 485 do Renesas (usando NOVUS expert)
  _transmisionBegun = false;
  CLEAR_IBUF();
}

void NOVUSVirtualRS485Class::end()
{
  // do not close serial (it is shared)
  
  clearSlaveAddress();
  CLEAR_IBUF();
} 

int NOVUSVirtualRS485Class::available()
{
  if(_ibuf_empty)
    RELOAD_IBUF("a");
/*
if((_ibuf_size - _ibuf_idx) > 0) // DBG
  { Serial.print("a"); Serial.println(_ibuf_size - _ibuf_idx);} //DBG
*/
  return _ibuf_size - _ibuf_idx;
}

int NOVUSVirtualRS485Class::peek()
{
  if(_ibuf_empty)
    RELOAD_IBUF("p");

  if(!_ibuf_empty)
    return _ibuf[_ibuf_idx];
  else
    return 0;
}

int NOVUSVirtualRS485Class::read(void)
{
  if(_ibuf_empty)
    RELOAD_IBUF("r");

  if(!_ibuf_empty)
    { Serial.print("r"); Serial.print(_ibuf_idx);}
  return READ_FROM_IBUF();;
}

void NOVUSVirtualRS485Class::flush()
{
  CLEAR_IBUF();
}

size_t NOVUSVirtualRS485Class::write(const uint8_t *req, int req_length)
{
  uint8_t tx_len = sendMEIRequest(MEI_SEND_PACKET_SP_CMD, req, req_length);
  uint8_t rx_len = receiveMEIResponse(Modbus_PDU_r, MODBUS_MAX_PDU_LENGTH);

  return tx_len;
}

size_t NOVUSVirtualRS485Class::readBytes(uint8_t *rsp, int rsp_length)
{
  if(_ibuf_empty)
    RELOAD_IBUF("b");

  size_t rx_len = 0;
  for(int i = 0; i < rsp_length; i++)
  {
    if(_ibuf_empty)
      break;
    /*
    if(!_ibuf_empty)  // DBG
      { Serial.print("b"); Serial.print(_ibuf_idx);}
    */
    rsp[i] = READ_FROM_IBUF();
    rx_len++;
  }
  return rx_len;
}

uint8_t NOVUSVirtualRS485Class::sendMEIRequest(const uint8_t special_command, const uint8_t *payload, int payload_size)
{
  uint16_t crc, crc_received;
  uint8_t mei_length = MEI_EMPTY_REQUEST_SIZE;    // assume empty package
  uint8_t transfer_length = 0;

  memset (Modbus_PDU, 0, MODBUS_MAX_PDU_LENGTH);

  Modbus_PDU[MEI_ADDR_IDX] = INDOOR_GATEWAY_ADDRESS;
  Modbus_PDU[MEI_COMMAND_IDX] = MEI_COMMAND;
  Modbus_PDU[MEI_SP_COMMAND_IDX] = special_command;
  if((payload != nullptr) && (payload_size > 0))
  {
    transfer_length = payload_size > MEI_MAX_PAYLOAD_SIZE ? MEI_MAX_PAYLOAD_SIZE : payload_size;
    Modbus_PDU[MEI_SIZE_IDX] = transfer_length;
    mei_length += transfer_length;
    memcpy(Modbus_PDU + MEI_PAYLOAD_IDX, payload, transfer_length);
  }
  else
  {
    Modbus_PDU[MEI_SIZE_IDX] = 0;
  }
  
  crc = crc16(Modbus_PDU, mei_length - 2);
  Modbus_PDU[mei_length - 2] = crc >> 8;
  Modbus_PDU[mei_length - 1] = crc & 0x00FF;
  DUMP_PDU(Modbus_PDU, mei_length);

  INDOOR_SERIAL.write(Modbus_PDU, mei_length);
  return transfer_length;
}

size_t NOVUSVirtualRS485Class::receiveMEIResponse(uint8_t *rsp, int max_length)
{
  unsigned long current=0, previous = millis();
  int count = 0;
  int remaining_size = MEI_EMPTY_RESPONSE_SIZE; // this is the default response
  uint16_t crc, crc_received;

  memset (Modbus_PDU, 0, MODBUS_MAX_PDU_LENGTH);

  do
  {
    current = millis();
    if ((current - previous) >= TIMEOUT_COMM_MS )
    {
      // Serial.println("to"); // DBG
      break;
    }

    if (INDOOR_SERIAL.available()) //Wait response byte
    {
      remaining_size--;
      Modbus_PDU[count]= INDOOR_SERIAL.read();
      if(count == MEI_SIZE_IDX)
      {
        remaining_size = Modbus_PDU[count] + MEI_CRC_SIZE;
        // Serial.print("\r\nrm:"); // DBG
        // Serial.println(remaining_size); // DBG
      }
      count++;
    }
  } while((count < max_length) && (remaining_size > 0)); //Wait complete response

  DUMP_PDU(Modbus_PDU, count);
  if(remaining_size == 0)
  {
    // all expected bytes received
    crc = crc16(Modbus_PDU, count - 2);
    crc_received = (Modbus_PDU[count - 2] << 8) | Modbus_PDU[count - 1];
    if(crc == crc_received)
    {
      uint8_t transfer_length = (count - MEI_MESSAGE_OVERHEAD) > max_length ? max_length : (count - MEI_MESSAGE_OVERHEAD);
      // copy payload (count will tell the received payload)
      memcpy(rsp,Modbus_PDU + MEI_PAYLOAD_IDX, transfer_length);
      count = transfer_length;
    }
    else
      count = 0;
  }
  else
    count = 0;

  return count;
}

NOVUSVirtualRS485Class::operator bool()
{
  return true;
}

void NOVUSVirtualRS485Class::beginTransmission()
{
  _transmisionBegun = true;
}

void NOVUSVirtualRS485Class::endTransmission()
{
  INDOOR_SERIAL.flush();
  _transmisionBegun = false;
}

void NOVUSVirtualRS485Class::receive()
{
  INDOOR_SERIAL.flush();
}

void NOVUSVirtualRS485Class::noReceive()
{
}

void NOVUSVirtualRS485Class::sendBreak(unsigned int duration)
{
  INDOOR_SERIAL.flush();
  delay(duration);
}

void NOVUSVirtualRS485Class::sendBreakMicroseconds(unsigned int duration)
{
  INDOOR_SERIAL.flush();
  delayMicroseconds(duration);
}

uint8_t NOVUSVirtualRS485Class::getSlaveAddress()
{
  sendMEIRequest(MEI_GET_SLAVE_ADD_SP_CMD);

  uint8_t rx_len = receiveMEIResponse(Modbus_PDU_r, MODBUS_MAX_PDU_LENGTH);

  if(rx_len == 1)
    return Modbus_PDU_r[0];
  else
    return 0;
}

void NOVUSVirtualRS485Class::setSlaveAddress(const uint8_t address)
{
  sendMEIRequest(MEI_SET_SLAVE_ADD_SP_CMD, &address, 1);
  receiveMEIResponse(Modbus_PDU_r, MODBUS_MAX_PDU_LENGTH);
}

void NOVUSVirtualRS485Class::clearSlaveAddress()
{
  sendMEIRequest(MEI_CLEAR_SLAVE_ADD_SP_CMD);
  uint8_t rx_len = receiveMEIResponse(Modbus_PDU_r, MODBUS_MAX_PDU_LENGTH);
}

NOVUSVirtualRS485Class RS485;