/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/* ---------.---------.---------.---------.---------.---------.---------.
 * THIS LIBRARY IS USED BY ALL OTHER NOVUS LIBRARIES,,
 * BUT NOT ACCESSED DIRECTLY BY THE USER (ARDUINO IDE).
 *
 * Its function is direct communication with DigiRail baseboard, ie Modbus PDU is mounted 
 * in this library and baseboard responses PDU are handled.
 *
 * --- send method (IndoorComm.Send)
 * * Creates the PDU according to the desired MODBUS (write, read) function, 
 * * record to be accessed and value to be assigned (when a write operation);
 * *
 * * After sending the PDU to baseboard, it will wait for a response until all bytes arrive
 * * or a TIMEOUT_COMM_MS occurs.
 * *
 * * If the answer PDU is correct (check Address, CRC, Function, ...) it will save the value read
 * * in the variable 'value' of the structure 'res' (res.value).
 * * 
 * * If any error is detected, res.value = 0, and the error found the res.error will reveice 
 * * the error code (various error patterns have been created, check documentation)
 * * --- 
 *
 * * checkCRC - check if received CRC is ok
 * ---
 *
 *
 */


#include <Arduino.h>
#include "novus/libmodbus/modbus-rtu.h" /* we need to use crc16 in this class */
#include "NxIndoorComm.h"
#include "nx_shared_mem.h"

// #define INDOORCOMM_DEBUG

#ifdef INDOORCOMM_DEBUG
#define DEBUG_ERROR   debugError();
#define PRINT_DEBUG_TIMEOUT(a,c,p)	{Serial.print(F("TO, recv'd "));\
					 				Serial.print(a);\
							 		Serial.print(F(" bytes.")); \
					 				Serial.print(F(" St: "));\
							 		Serial.print(c); \
					 				Serial.print(F(". End: "));\
							 		Serial.println(p); \
									Serial.flush(); \
									}while(0==1);
#define DUMP_OUT_PDU(f,buffer,size)	{if(f == FUNC_READSINGLE)\
										Serial.println(F("exm: [ Ad Fn Rh Rl Qh Ql Cl Ch ]"));\
									else if (f == FUNC_WRITESINGLE)\
										Serial.println(F("exm: [ Ad Fn Rh Rl Vh Vl Cl Ch ]"));\
		 							else if (f == FUNC_WRITEMULTIPLE)\
										Serial.println(F("exm: [ Ad Fn Sh Sl Qh Ql NB Vh Vl Vh Vl Vh Vl Cl Ch ]"));\
									Serial.print(F("PDU: [ "));\
		 							for (unsigned int x=0; x < size; x++)\
		 							{\
			 							if (buffer[x] > 0XF)\
											Serial.print(buffer[x],HEX);\
			 							else\
			 							{\
											Serial.print(F("0"));\
											Serial.print(buffer[x],HEX);\
			 							}\
										Serial.print(F(" "));\
			 							if (x == (size-1))\
											Serial.print(F("]\n"));\
		 							}\
									Serial.flush();};

									

#define DUMP_IN_PDU(buffer, size)for (uint16_t x = 0; x < size; x++)\
								{\
									if(x == 0) \
										Serial.print(F("P_r: [ "));\
									if (buffer[x] > 0XF)\
										Serial.print(buffer[x],HEX);\
									else\
									{\
			  							Serial.print(F("0"));\
										Serial.print(buffer[x],HEX);\
									}\
									Serial.print(" ");\
									if (x == (size-1))\
										Serial.println(F("]\n"));\
		 						}\
								Serial.flush()

#define PRINT_MSG_VALUE(m,v) 	{Serial.print(F(m));\
								Serial.println(v); \
								Serial.flush(); \
								}while(0==1);
#else
#define DEBUG_ERROR
#define DUMP_IN_PDU(buffer, size)
#define PRINT_DEBUG_TIMEOUT(a,c,p)
#define DUMP_OUT_PDU(f,buffer,size)
#define PRINT_MSG_VALUE(m,v)
#endif


// Communication parameters
#define INOOR_SLAVE_ADDRESS 7
#define TRIES_MAX_COUNT 3
#define TIMEOUT_COMM_MS 50
#define INTERFRAME_DELAY (35 * 8) / 10   // Microseconds (3.5 bits)
#define DELAY_BETWEEN_COMMUNICATIONS 5  // Milliseconds
#define DELAY_BEFORE_COMMUNICATION   5

IndoorCommClass::response res;

/* --------------------------------------------------------------------------------------
 *								  	indoor communication	
 * -------------------------------------------------------------------------------------- */
void IndoorCommClass::send(function_t function, uint16_t reg, uint16_t quantity, uint16_t* value)
{
	res.error=0;
	res.value=0;
	if ((quantity <= 0))
	{
		res.error = 1;
	}
	if ((function != FUNC_READSINGLE) && (function != FUNC_WRITESINGLE) && (function != FUNC_WRITEMULTIPLE))
	{
		res.error = 2; //Function unexpected
	}
	
	if (res.error == 0)
	{	
		 uint16_t send_len = 8;
		 memset (Modbus_PDU, 0, MODBUS_MAX_PDU_LENGTH);
		 memset (Modbus_PDU_r, 0, MODBUS_MAX_PDU_LENGTH);
		 
		 /* Max PDU supported by baseboard: 16 bytes --> that means only 3 Bytes of data
		  *                          |   0   |   1  |    2    |    3    |   4   |   5   |   6   |   7   |   8  |   9  |  10  |  11  |  12  |   13  |   14  |
		  * Read register(s):  3 --> | Slave | Func | Regst H | Regst L | Qnt H | Qnt L | CRC L | CRC H | 
		  * Write register  :  6 --> | Slave | Func | Regst H | Regst L | Val H | Val L | CRC L | CRC H |
		  * Write registers : 16 --> | Slave | Func | Start H | Start L | Qnt H | Qnt L |  2*N  |  V0 H | V0 L | V1 H | V1 L | V2 H | V2 L | CRC L | CRC H |
		  *
		  */
		  
		 Modbus_PDU[0] = INOOR_SLAVE_ADDRESS; 					// Slave address
		 Modbus_PDU[1] = function; 								// 3- Read single register | 6- Write single register | 16- Write multiple register
		 Modbus_PDU[2] = (uint8_t) ((reg & 0xFF00) >> 8);		// High byte of register
		 Modbus_PDU[3] = (uint8_t)((reg & 0x00FF) >> 0);		// Low byte of register
		 if (function == FUNC_READSINGLE)
		 {
			Modbus_PDU[4] = (uint8_t)((quantity >> 8) & 0xFF);	// High byte of quantity
			Modbus_PDU[5] = (uint8_t)((quantity >> 0) & 0xFF);	// Low byte of quantity
			send_len = 8;
		 }
		 else if (function == FUNC_WRITESINGLE)
		 {
			Modbus_PDU[4] = (uint8_t)((*value >> 8) & 0xFF); 	// High byte of value
			Modbus_PDU[5] = (uint8_t)((*value >> 0) & 0xFF); 	// Low byte of value
			send_len = 8;
		 }
		 else if (function == FUNC_WRITEMULTIPLE)
		 {
			Modbus_PDU[4] = (uint8_t)((quantity >> 8) & 0xFF);	// High byte of quantity
			Modbus_PDU[5] = (uint8_t)((quantity >> 0) & 0xFF); 	// Low byte of quantity
			Modbus_PDU[6] = (uint8_t)2*quantity; 				// byte count
			send_len = 9 + 2*quantity;
			 
			for (uint16_t x=0; x<quantity ;x++)
			{
				Modbus_PDU[7+2*x] = (uint8_t)((*(value+x) >> 8) & 0xFF); // High byte of value
				Modbus_PDU[8+2*x] = (uint8_t)((*(value+x) >> 0) & 0xFF); // Low byte of value
			}		 
		}
		 
		//Calculate CRC
		int length = (function == FUNC_WRITEMULTIPLE ? 2*quantity+7 : 6);
		uint16_t u16CRC = crc16(Modbus_PDU, length);
        Modbus_PDU[length] =  (uint8_t) (u16CRC >> 8);
        Modbus_PDU[length + 1] = (uint8_t) (u16CRC & 0xFF); 

		DUMP_OUT_PDU(function,Modbus_PDU, send_len);
		delay(DELAY_BEFORE_COMMUNICATION);

		int tries = 0;
		uint16_t expected_len = 8;
		if (function == FUNC_READSINGLE)
			expected_len = 5 + quantity*2;
		else if (function == FUNC_WRITESINGLE) 
			expected_len = send_len;
		else if (function == FUNC_WRITEMULTIPLE) 
			expected_len = 8; 

		uint16_t bytes_recv = 0;
		do
		{
			res.error=0;
			 
			// Send PDU to baseboard
			Serial1.flush();
			uint16_t send_index = 0;
			int c;
			while (send_index < send_len)
			{
				c = Serial1.availableForWrite();
				if(c > 0)
				{
					c = ((send_index + c) > send_len ? send_len - send_index : c);
					Serial1.write(&Modbus_PDU[send_index], c);
					send_index += c;
				}
				Serial1.flush();
			}
			PRINT_MSG_VALUE("Send index: ",send_index);
			delayMicroseconds(INTERFRAME_DELAY);

			unsigned long current=0, previous = millis();
		 
			//Receiving PDU
			int available_bytes;
			do
			{
				current = millis();
				if (current - previous >= TIMEOUT_COMM_MS )
				{
					PRINT_DEBUG_TIMEOUT(bytes_recv, current, previous);
					res.error = 99; //timeout
					break;
				} 
				available_bytes = Serial1.available();
				if (available_bytes > 0) //Wait byte
				{
					Serial1.readBytes(&Modbus_PDU_r[bytes_recv], available_bytes);
					bytes_recv += available_bytes;
				}
			} while(bytes_recv < expected_len); // Wait message with expected length
			 
			tries = (res.error == 99 ? tries + 1 : TRIES_MAX_COUNT);
		}while(tries < TRIES_MAX_COUNT);
		
		delay(DELAY_BETWEEN_COMMUNICATIONS); //Delay between sends

		DUMP_IN_PDU(Modbus_PDU_r,bytes_recv);

		if (res.error == 0)
		{
			// Check response
			if(!checkCRC(Modbus_PDU_r,expected_len-2))
				res.error=FUNC_READSINGLE; // CRC is correct ?

			if(Modbus_PDU_r[0] != Modbus_PDU[0])
				res.error = 4; // Same slave address ?

			if(Modbus_PDU_r[1] != Modbus_PDU[1])
				res.error = 5; // Same function number ?

			if(function != FUNC_READSINGLE)
			{
				for (int x=0; x < 6; x++)
				{	
					if (Modbus_PDU[x] != Modbus_PDU_r[x])
						res.error = 10; // Write returned echo ?
				}
			} 

			// Get value from response
			if ((function == FUNC_READSINGLE) && (quantity == 1))
				res.value = ((uint16_t)Modbus_PDU_r[3]<<8) + Modbus_PDU_r[4];
		}
	}
}
 

bool IndoorCommClass::checkCRC( uint8_t *pBufferSerial, uint8_t u8Index )
{
	// Always return FALSE when there is a CRC mismatch.
    uint16_t u16CRC;

    // ucIndex is the number of bytes.
    // Does not take into account CRC, so we need to subtract 2
    u8Index -= 2;

    u16CRC = crc16( pBufferSerial, u8Index );

    if( (pBufferSerial[u8Index++] == (uint8_t)(u16CRC & 0xff)) && (pBufferSerial[u8Index] == (uint8_t)(u16CRC>>8)) )
    {
        return false;
    }
    else
    {
        return true;
    }

}

void IndoorCommClass::debugError(void)
{
	
#ifdef INDOORCOMM_DEBUG
	switch (res.error)
	{
		case 0: 
				Serial.println(F("No error occured"));
				break;
		case 1:
				Serial.println(F("ERROR DETECTED: Underflow "));
				break;
		case 2:
				Serial.println(F("ERROR DETECTED: Overflow "));
				break;
		case 3:
				Serial.println(F("ERROR DETECTED: Modbus Function "));
				break;
		case 4:
				Serial.println(F("ERROR DETECTED: Underflow "));
				break;
		case 5:
				Serial.println(F("ERROR DETECTED: Overflow "));
				break;
		case 6:
				Serial.println(F("ERROR DETECTED: Timeout "));
				break;
		case 7:
				Serial.println(F("ERROR DETECTED: CRC "));
				break;
		case 8:
				Serial.println(F("ERROR DETECTED: Slave address "));
				break;
		case 9:
				Serial.println(F("ERROR DETECTED: function response "));
				break;
		case 10:
				Serial.println(F("ERROR DETECTED: echo "));
				break;
		case 11:
				Serial.println(F("ERROR DETECTED: Configuration Failed"));
				break;
		default:
				Serial.print(F("Unkwnon error. UPDATE debugError with N: "));
				Serial.println(res.error);
				break;				
	}
#endif
	
}
IndoorCommClass IndoorComm;


