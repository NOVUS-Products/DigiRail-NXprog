#include <avr/pgmspace.h>
#include "nx_config_aux.h"


/* ------------------------------------------------ Unknown values ------------------------------------------ */
const char unknon[] PROGMEM = "????";  // tc_J = 0
const char *const unknown_strings[] PROGMEM = {
    unknon
};

/* ---------------------------------------------- Analog Input values ---------------------------------------- */
const char ai_type_0[] PROGMEM = "J";  // tc_J = 0
const char ai_type_1[] PROGMEM = "K";  // tc_K = 1
const char ai_type_2[] PROGMEM = "T";  // tc_T = 2
const char ai_type_3[] PROGMEM = "N";  // tc_N = 3
const char ai_type_4[] PROGMEM = "R";  // tc_R = 4
const char ai_type_5[] PROGMEM = "S";  // tc_S = 5
const char ai_type_6[] PROGMEM = "B";  // tc_B = 6
const char ai_type_7[] PROGMEM = "E";  // tc_E = 7
const char ai_type_8[] PROGMEM = "Pt100";  //Pt100 = 8
const char ai_type_9[] PROGMEM = "Pt1000"; // Pt1000 = 9
const char ai_type_10[] PROGMEM = "NTC";    //NTC = 10
const char ai_type_11[] PROGMEM = "0 - 60mv"; // _0_60mV = 11
const char ai_type_12[] PROGMEM = "0 - 5Vdc"; // _0_5V = 12
const char ai_type_13[] PROGMEM = "0 - 10Vdc"; // _0_10V = 13
const char ai_type_14[] PROGMEM = "0 - 20mA"; // _0_20mA = 14
const char ai_type_15[] PROGMEM = "4 - 20mA"; // _4_20mA = 15
const char *const ain_sensor[] PROGMEM = {
    ai_type_0,
    ai_type_1,
    ai_type_2,
    ai_type_3,
    ai_type_4,
    ai_type_5,
    ai_type_6,
    ai_type_7,
    ai_type_8,
    ai_type_9,
    ai_type_10,
    ai_type_11,
    ai_type_12,
    ai_type_13,
    ai_type_14,
    ai_type_15
};

const char temp_0[] PROGMEM = "Celsius"; // _CELSIUS = 0
const char temp_1[] PROGMEM = "Fahrenheit"; // _FAHRENHEIT = 1
const char * const ain_temp_unit[] PROGMEM = {
	temp_0,
    temp_1
};

const char samp_0[] PROGMEM = "1 per second"; // _1_per_sec = 0
const char samp_1[] PROGMEM = "10 per second"; // _10_per_sec = 1
const char * const ain_sampling_rate[] PROGMEM = {
    samp_0,
    samp_1
};

/* ---------------------------------------------- Analog Output values --------------------------------------- */
const char ao_type_0[] PROGMEM = "0 - 20mA";
const char ao_type_1[] PROGMEM = "4 - 20mA";
const char ao_type_2[] PROGMEM = "0 - 10V"; 
const char *const aout_type[] PROGMEM = {
    ao_type_0,
    ao_type_1,
    ao_type_2
};

const char ao_range_0[] PROGMEM = "% * 100";
const char ao_range_1[] PROGMEM = "0 - 3200";
const char *const aout_range[] PROGMEM = {
    ao_range_0,
    ao_range_1
};

const char ao_po_state_0[] PROGMEM = "Off";
const char ao_po_state_1[] PROGMEM = "Configured value";
const char ao_po_state_2[] PROGMEM = "Last valid"; 
const char *const aout_po_state[] PROGMEM = {
    ao_po_state_0,
    ao_po_state_1,
    ao_po_state_2
};

/* ---------------------------------------------- String copy macro ----------------------------------------- */
#define STRCPY_FROM_CONST_STR_LIST(a, size, b, idx) ({\
                                        				size_t numOfElements = sizeof(b)/sizeof(b[0]); \
                                                        if((idx >= 0) && (idx < numOfElements)) \
                                                        { \
                                                            if(strlen_P((char *)pgm_read_word(&(b[idx]))) >= size) \
                                                                return; \
                                                            strcpy_P(a, (char *)pgm_read_word(&(b[idx]))); \
                                                        } \
                                                        else \
                                                            strcpy_P(a, (char *)pgm_read_word(&unknown_strings[0])); \
                                                    })

void ain_sensor_to_str(nx_ain_sensor_t type, char *buffer, uint8_t max_size)
{
    STRCPY_FROM_CONST_STR_LIST(buffer, max_size, ain_sensor, type);
}

void ain_temp_unit_to_str(nx_ain_temp_unit_t unit, char *buffer, uint8_t max_size)
{
    STRCPY_FROM_CONST_STR_LIST(buffer, max_size, ain_temp_unit, unit);
}

void ain_sampling_rate_to_str(nx_ain_sampling_rate_t sampling_rate, char *buffer, uint8_t max_size)
{
    STRCPY_FROM_CONST_STR_LIST(buffer, max_size, ain_sampling_rate, sampling_rate);
}

void aout_type_to_str(nx_aout_type_t type, char *buffer, uint8_t max_size)
{
    STRCPY_FROM_CONST_STR_LIST(buffer, max_size, aout_type, type);
}

void aout_range_to_str(nx_aout_range_t range, char *buffer, uint8_t max_size)
{
    STRCPY_FROM_CONST_STR_LIST(buffer, max_size, aout_range, range);
}

void aout_pon_state_to_str(nx_aout_poweron_state_t state, char *buffer, uint8_t max_size)
{
    STRCPY_FROM_CONST_STR_LIST(buffer, max_size, aout_po_state, state);
}
