/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/* 
 *
 * NOVUS EXPERT FUNCTIONS FOR MIXIO. 
 *
 */


#include "Arduino.h"
#include "nx_expert_aout.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_registers.h"

#define DECIMAL 100 //1 for 1, 10 for 2, 100 for 3....
#define REGISTER_READ_ERROR 0xFF



#define WRITE_AO_SINGLE_REGISTER(p,r,v)     ({ \
                                                bool result = false; \
                                                if(isAOutPinNXprog(p)) \
                                                { \
	                                                uint8_t idx = PIN_TO_PORT_INDEX(p); \
                                                    NovusConfig.doutCFG[idx].read_ok = false; \
                                            	    IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::r)+(50*idx)), 1, &v); \
                                                    if(IndoorComm.res.error == 0) \
                                                    { \
                                                        NovusConfig.doutCFG[idx].read_ok = true; \
                                                        result = true; \
                                                    } \
                                                } \
                                                result; \
                                            })


bool ExpertClassAnalogOutput::setMode(const uint8_t pin, nx_aout_type_t type, nx_aout_range_t range, nx_aout_poweron_state_t poweronState, uint16_t poweronValue, uint16_t watchdogValue) 
{
    uint16_t config[5] = {0};	
    
    if(isAOutPinNXprog(pin) == false)
        return false;

    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

  
    NovusConfig.doutCFG[idx_port].read_ok = false; 

	config[0] = 1; //Enable


	IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)(NXprogRegisters::AO_ENABLE+(50*idx_port)), 1, config); //enable or disable port
    if(IndoorComm.res.error != 0)
        return false;
    NovusConfig.aoutCFG[idx_port].enabled = 1; 

	config[0] = type;
	config[1] = range;
	config[2] = poweronState;
	config[3] = poweronValue;
	config[4] = watchdogValue;
	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::AO_TYPE+(50*idx_port)), 5, config); //pulse time, period and number
    if(IndoorComm.res.error != 0)
        return false;
    NovusConfig.aoutCFG[idx_port].type= type; 
    NovusConfig.aoutCFG[idx_port].range = range; 
    NovusConfig.aoutCFG[idx_port].pon_state = poweronState; 
    NovusConfig.aoutCFG[idx_port].pon_value = poweronValue;
    NovusConfig.aoutCFG[idx_port].watchdog_value = watchdogValue;

    NovusConfig.doutCFG[idx_port].read_ok = true;

  	NovusConfig.applyConfig();

    return true;
}

bool ExpertClassAnalogOutput::setState(const uint8_t pin, bool enable)
{
	uint16_t config= (enable ? 1: 0);

    if (WRITE_AO_SINGLE_REGISTER(pin,AO_ENABLE,config))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.aoutCFG[idx_port].enabled = config; 
  	    NovusConfig.applyConfig();
        return true;
    }
    return false;
}

bool ExpertClassAnalogOutput::setPowerOnValue(const uint8_t pin, uint16_t poweronValue)
{

    if (WRITE_AO_SINGLE_REGISTER(pin,AO_PON_VALUE, poweronValue))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.aoutCFG[idx_port].pon_value = poweronValue; 
  	    NovusConfig.applyConfig();
        return true;
    }
    return false;
}

bool ExpertClassAnalogOutput::setPowerOnState(const uint8_t pin, nx_aout_poweron_state_t state)
{
	uint16_t config;
    if (state == _PO_AOUT_CONFIGURED_VALUE)
        config = 1;
    else if(state == _PO_AOUT_LAST_VALID_VALUE) 
        config = 2;
    else if(state == _PO_AOUT_DISABLED) 
        config = 0;
    else
        return false;

    if (WRITE_AO_SINGLE_REGISTER(pin,AO_PON_STATE, config))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.aoutCFG[idx_port].pon_state = state; 
  	    NovusConfig.applyConfig();
        return true;
    }
    return false;
}

bool ExpertClassAnalogOutput::setSafeValue(const uint8_t pin,uint16_t safeValue)
{
    if (WRITE_AO_SINGLE_REGISTER(pin,AO_SAFE_VALUE,safeValue))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.aoutCFG[idx_port].watchdog_value = safeValue; 
  	    NovusConfig.applyConfig();
        return true;
    }
    return false;
}


ExpertClassAnalogOutput NovusExpertAOut;