/**************************************************************************/
/*!
  RTC

  Modified: 2019-09-24 by NOVUS Automation

  Original library by JeeLabs http://news.jeelabs.org/code/, released to the public domain.

  This version: MIT (see LICENSE)
*/
/**************************************************************************/

#include <Arduino.h> // capital A so it is error prone on case-sensitive filesystems
#include <Wire.h>
#include "RTC.h"
#include <avr/pgmspace.h>


 // Macro to deal with the difference in I2C write functions from old and new Arduino versions.
 #define _I2C_WRITE write   ///< Modern I2C write
 #define _I2C_READ  read    ///< Modern I2C read

/**************************************************************************/
/*!
    @brief  Read a byte from an I2C register
    @param addr I2C address
    @param reg Register address
    @return Register value
*/
/**************************************************************************/
static uint8_t read_i2c_register(uint8_t addr, uint8_t reg) {
  Wire.beginTransmission(addr);
  Wire._I2C_WRITE((byte)reg);
  Wire.endTransmission();

  Wire.requestFrom(addr, (byte)1);
  return Wire._I2C_READ();
}

/**************************************************************************/
/*!
    @brief  Write a byte to an I2C register
    @param addr I2C address
    @param reg Register address
    @param val Value to write
*/
/**************************************************************************/
static void write_i2c_register(uint8_t addr, uint8_t reg, uint8_t val) {
  Wire.beginTransmission(addr);
  Wire._I2C_WRITE((byte)reg);
  Wire._I2C_WRITE((byte)val);
  Wire.endTransmission();
}


/**************************************************************************/
// utility code, some of this could be exposed in the DateTime API if needed
/**************************************************************************/

/** Number of days in each month */
const uint8_t daysInMonth [] PROGMEM = { 31,28,31,30,31,30,31,31,30,31,30,31 };

/**************************************************************************/
/*!
    @brief  Given a date, return number of days since 2000/01/01, valid for 2001..2099
    @param y Year
    @param m Month
    @param d Day
    @return Number of days
*/
/**************************************************************************/
static uint16_t date2days(uint16_t y, uint8_t m, uint8_t d) {
    if (y >= 2000)
        y -= 2000;
    uint16_t days = d;
    for (uint8_t i = 1; i < m; ++i)
        days += pgm_read_byte(daysInMonth + i - 1);
    if (m > 2 && y % 4 == 0)
        ++days;
    return days + 365 * y + (y + 3) / 4 - 1;
}

/**************************************************************************/
/*!
    @brief  Given a number of days, hours, minutes, and seconds, return the total seconds
    @param days Days
    @param h Hours
    @param m Minutes
    @param s Seconds
    @return Number of seconds total
*/
/**************************************************************************/
static long time2long(uint16_t days, uint8_t h, uint8_t m, uint8_t s) {
    return ((days * 24L + h) * 60 + m) * 60 + s;
}



/**************************************************************************/
/*!
    @brief  DateTime constructor from unixtime
    @param t Initial time in seconds since Jan 1, 1970 (Unix time)
*/
/**************************************************************************/
DateTime::DateTime (uint32_t t) {
  t -= SECONDS_FROM_1970_TO_2000;    // bring to 2000 timestamp from 1970

  ss = t % 60;
  t /= 60;
  mm = t % 60;
  t /= 60;
  hh = t % 24;
  uint16_t days = t / 24;
  uint8_t leap;
  for (yOff = 0; ; ++yOff) {
    leap = yOff % 4 == 0;
    if (days < (uint16_t)365 + leap)
      break;
    days -= 365 + leap;
  }
  for (m = 1; ; ++m) {
    uint8_t daysPerMonth = pgm_read_byte(daysInMonth + m - 1);
    if (leap && m == 2)
      ++daysPerMonth;
    if (days < daysPerMonth)
      break;
    days -= daysPerMonth;
  }
  d = days + 1;
}

/**************************************************************************/
/*!
    @brief  DateTime constructor from Y-M-D H:M:S
    @param year Year, 2 or 4 digits (year 2000 or higher)
    @param month Month 1-12
    @param day Day 1-31
    @param hour 0-23
    @param min 0-59
    @param sec 0-59
*/
/**************************************************************************/
DateTime::DateTime (uint16_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t min, uint8_t sec) {
    if (year >= 2000)
        year -= 2000;
    yOff = year;
    m = month;
    d = day;
    hh = hour;
    mm = min;
    ss = sec;
}

/**************************************************************************/
/*!
    @brief  DateTime copy constructor using a member initializer list
    @param copy DateTime object to copy
*/
/**************************************************************************/
DateTime::DateTime (const DateTime& copy):
  yOff(copy.yOff),
  m(copy.m),
  d(copy.d),
  hh(copy.hh),
  mm(copy.mm),
  ss(copy.ss)
{}

/**************************************************************************/
/*!
    @brief  Convert a string containing two digits to uint8_t, e.g. "09" returns 9
    @param p Pointer to a string containing two digits
*/
/**************************************************************************/
static uint8_t conv2d(const char* p) {
    uint8_t v = 0;
    if ('0' <= *p && *p <= '9')
        v = *p - '0';
    return 10 * v + *++p - '0';
}

/**************************************************************************/
/*!
    @brief  A convenient constructor for using "the compiler's time":
            DateTime now (__DATE__, __TIME__);
            NOTE: using F() would further reduce the RAM footprint, see below.
    @param date Date string, e.g. "Dec 26 2009"
    @param time Time string, e.g. "12:34:56"
*/
/**************************************************************************/
DateTime::DateTime (const char* date, const char* time) {
    // sample input: date = "Dec 26 2009", time = "12:34:56"
    yOff = conv2d(date + 9);
    // Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec
    switch (date[0]) {
        case 'J': m = (date[1] == 'a') ? 1 : ((date[2] == 'n') ? 6 : 7); break;
        case 'F': m = 2; break;
        case 'A': m = date[2] == 'r' ? 4 : 8; break;
        case 'M': m = date[2] == 'r' ? 3 : 5; break;
        case 'S': m = 9; break;
        case 'O': m = 10; break;
        case 'N': m = 11; break;
        case 'D': m = 12; break;
    }
    d = conv2d(date + 4);
    hh = conv2d(time);
    mm = conv2d(time + 3);
    ss = conv2d(time + 6);
}

/**************************************************************************/
/*!
    @brief  A convenient constructor for using "the compiler's time":
            This version will save RAM by using PROGMEM to store it by using the F macro.
            DateTime now (F(__DATE__), F(__TIME__));
    @param date Date string, e.g. "Dec 26 2009"
    @param time Time string, e.g. "12:34:56"
*/
/**************************************************************************/
DateTime::DateTime (const __FlashStringHelper* date, const __FlashStringHelper* time) {
    // sample input: date = "Dec 26 2009", time = "12:34:56"
    char buff[11];
    memcpy_P(buff, date, 11);
    yOff = conv2d(buff + 9);
    // Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec
    switch (buff[0]) {
        case 'J': m = (buff[1] == 'a') ? 1 : ((buff[2] == 'n') ? 6 : 7); break;
        case 'F': m = 2; break;
        case 'A': m = buff[2] == 'r' ? 4 : 8; break;
        case 'M': m = buff[2] == 'r' ? 3 : 5; break;
        case 'S': m = 9; break;
        case 'O': m = 10; break;
        case 'N': m = 11; break;
        case 'D': m = 12; break;
    }
    d = conv2d(buff + 4);
    memcpy_P(buff, time, 8);
    hh = conv2d(buff);
    mm = conv2d(buff + 3);
    ss = conv2d(buff + 6);
}

/**************************************************************************/
/*!
    @brief  Return DateTime in based on user defined format.
    @param buffer: array of char for holding the format description and the formatted DateTime. 
                   Before calling this method, the buffer should be initialized by the user with 
                   a format string, e.g. "YYYY-MM-DD hh:mm:ss". The method will overwrite 
                   the buffer with the formatted date and/or time.
    @return a pointer to the provided buffer. This is returned for convenience, 
            in order to enable idioms such as Serial.println(now.toString(buffer));
*/
/**************************************************************************/

char* DateTime::toString(char* buffer){
		for(int i=0;i < (int)(strlen(buffer)-1);i++){
		if(buffer[i] == 'h' && buffer[i+1] == 'h'){
			buffer[i] = '0'+hh/10;
			buffer[i+1] = '0'+hh%10;
		}
		if(buffer[i] == 'm' && buffer[i+1] == 'm'){
			buffer[i] = '0'+mm/10;
			buffer[i+1] = '0'+mm%10;
		}
		if(buffer[i] == 's' && buffer[i+1] == 's'){
			buffer[i] = '0'+ss/10;
			buffer[i+1] = '0'+ss%10;
		}
    if(buffer[i] == 'D' && buffer[i+1] =='D' && buffer[i+2] =='D'){
      static PROGMEM const char day_names[] = "SunMonTueWedThuFriSat";
      const char *p = &day_names[3*dayOfTheWeek()];
      buffer[i] = pgm_read_byte(p);
      buffer[i+1] = pgm_read_byte(p+1);
      buffer[i+2] = pgm_read_byte(p+2);
    }else
		if(buffer[i] == 'D' && buffer[i+1] == 'D'){
			buffer[i] = '0'+d/10;
			buffer[i+1] = '0'+d%10;
		}
    if(buffer[i] == 'M' && buffer[i+1] =='M' && buffer[i+2] =='M'){
      static PROGMEM const char month_names[] = "JanFebMarAprMayJunJulAugSepOctNovDec";
      const char *p = &month_names[3*(m-1)];
      buffer[i] = pgm_read_byte(p);
      buffer[i+1] = pgm_read_byte(p+1);
      buffer[i+2] = pgm_read_byte(p+2);      
    }else
		if(buffer[i] == 'M' && buffer[i+1] == 'M'){
			buffer[i] = '0'+m/10;
			buffer[i+1] = '0'+m%10;
		}
		if(buffer[i] == 'Y'&& buffer[i+1] == 'Y'&& buffer[i+2] == 'Y'&& buffer[i+3] == 'Y'){
			buffer[i] = '2';
			buffer[i+1] = '0';
			buffer[i+2] = '0'+(yOff/10)%10;
			buffer[i+3] = '0'+yOff%10;
		}else
		if(buffer[i] == 'Y'&& buffer[i+1] == 'Y'){
			buffer[i] = '0'+(yOff/10)%10;
			buffer[i+1] = '0'+yOff%10;
		}

	}
	return buffer;
}

/**************************************************************************/
/*!
    @brief  Return the day of the week for this object, from 0-6.
    @return Day of week 0-6 starting with Sunday, e.g. Sunday = 0, Saturday = 6
*/
/**************************************************************************/
uint8_t DateTime::dayOfTheWeek() const {
    uint16_t day = date2days(yOff, m, d);
    return (day + 6) % 7; // Jan 1, 2000 is a Saturday, i.e. returns 6
}

/**************************************************************************/
/*!
    @brief  Return unix time, seconds since Jan 1, 1970.
    @return Number of seconds since Jan 1, 1970
*/
/**************************************************************************/
uint32_t DateTime::unixtime(void) const {
  uint32_t t;
  uint16_t days = date2days(yOff, m, d);
  t = time2long(days, hh, mm, ss);
  t += SECONDS_FROM_1970_TO_2000;  // seconds from 1970 to 2000

  return t;
}

/**************************************************************************/
/*!
    @brief  Convert the DateTime to seconds
    @return The object as seconds since 2000-01-01
*/
/**************************************************************************/
long DateTime::secondstime(void) const {
  long t;
  uint16_t days = date2days(yOff, m, d);
  t = time2long(days, hh, mm, ss);
  return t;
}

/**************************************************************************/
/*!
    @brief  Add a TimeSpan to the DateTime object
    @param span TimeSpan object
    @return new DateTime object with span added to it
*/
/**************************************************************************/
DateTime DateTime::operator+(const TimeSpan& span) {
  return DateTime(unixtime()+span.totalseconds());
}

/**************************************************************************/
/*!
    @brief  Subtract a TimeSpan from the DateTime object
    @param span TimeSpan object
    @return new DateTime object with span subtracted from it
*/
/**************************************************************************/
DateTime DateTime::operator-(const TimeSpan& span) {
  return DateTime(unixtime()-span.totalseconds());
}

/**************************************************************************/
/*!
    @brief  Subtract one DateTime from another
    @param right The DateTime object to subtract from self (the left object)
    @return TimeSpan of the difference between DateTimes
*/
/**************************************************************************/
TimeSpan DateTime::operator-(const DateTime& right) {
  return TimeSpan(unixtime()-right.unixtime());
}

/**************************************************************************/
/*!
    @brief  Is one DateTime object less than (older) than the other?
    @param right Comparison DateTime object
    @return True if the left object is older than the right object
*/
/**************************************************************************/
bool DateTime::operator<(const DateTime& right) const {
  return unixtime() < right.unixtime();
}

/**************************************************************************/
/*!
    @brief  Is one DateTime object equal to the other?
    @param right Comparison DateTime object
    @return True if both DateTime objects are the same
*/
/**************************************************************************/
bool DateTime::operator==(const DateTime& right) const {
  return unixtime() == right.unixtime();
}

/**************************************************************************/
/*!
    @brief  ISO 8601 Timestamp
    @param opt Format of the timestamp
    @return Timestamp string, e.g. "2000-01-01T12:34:56"
*/
/**************************************************************************/
String DateTime::timestamp(timestampOpt opt){
  char buffer[20];

  //Generate timestamp according to opt
  switch(opt){
    case TIMESTAMP_TIME:
    //Only time
    sprintf(buffer, "%02d:%02d:%02d", hh, mm, ss);
    break;
    case TIMESTAMP_DATE:
    //Only date
    sprintf(buffer, "%d-%02d-%02d", 2000+yOff, m, d);
    break;
    default:
    //Full
    sprintf(buffer, "%d-%02d-%02dT%02d:%02d:%02d", 2000+yOff, m, d, hh, mm, ss);
  }
  return String(buffer);
}

/**************************************************************************/
/*!
    @brief  Check if the parameters are a valid date and time
    @param year Year, 4 digits (year 2000 or higher)
    @param month Month 1-12
    @param day Day 1-31
    @param hour 0-23
    @param min 0-59
    @param sec 0-59
    @return boolean (valid / not valid)
*/
/**************************************************************************/
bool DateTime::isValidDateTime (uint16_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t min, uint8_t sec)
{
  bool return_value = false;
  if(year>=2000 && year<=9999) {
    //check month
    if(month>=1 && month<=12) {
      //check days
      if((day>=1 && day<=31) && (month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12))
        return_value = true;
      else if((day>=1 && day<=30) && (month==4 || month==6 || month==9 || month==11))
        return_value = true;
      else if((day>=1 && day<=28) && (month==2))
        return_value = true;
      else if(day==29 && month==2 && (year%400==0 ||(year%4==0 && year%100!=0)))
        return_value = true;
    }
  }
  if(return_value) {
    return_value = false;
    if(hour <= 23) {
      if(min <= 59) {
        if(sec <= 59) {
          return_value = true;
        }
      }
    }
  }
  return return_value;  
}

/**************************************************************************/
/*!
    @brief  Create a new TimeSpan object in seconds
    @param seconds Number of seconds
*/
/**************************************************************************/
TimeSpan::TimeSpan (int32_t seconds):
  _seconds(seconds)
{}

/**************************************************************************/
/*!
    @brief  Create a new TimeSpan object using a number of days/hours/minutes/seconds
            e.g. Make a TimeSpan of 3 hours and 45 minutes: new TimeSpan(0, 3, 45, 0);
    @param days Number of days
    @param hours Number of hours
    @param minutes Number of minutes
    @param seconds Number of seconds
*/
/**************************************************************************/
TimeSpan::TimeSpan (int16_t days, int8_t hours, int8_t minutes, int8_t seconds):
  _seconds((int32_t)days*86400L + (int32_t)hours*3600 + (int32_t)minutes*60 + seconds)
{}

/**************************************************************************/
/*!
    @brief  Copy constructor, make a new TimeSpan using an existing one
    @param copy The TimeSpan to copy
*/
/**************************************************************************/
TimeSpan::TimeSpan (const TimeSpan& copy):
  _seconds(copy._seconds)
{}

/**************************************************************************/
/*!
    @brief  Add two TimeSpans
    @param right TimeSpan to add
    @return New TimeSpan object, sum of left and right
*/
/**************************************************************************/
TimeSpan TimeSpan::operator+(const TimeSpan& right) {
  return TimeSpan(_seconds+right._seconds);
}

/**************************************************************************/
/*!
    @brief  Subtract a TimeSpan
    @param right TimeSpan to subtract
    @return New TimeSpan object, right subtracted from left
*/
/**************************************************************************/
TimeSpan TimeSpan::operator-(const TimeSpan& right) {
  return TimeSpan(_seconds-right._seconds);
}



/**************************************************************************/
/*!
    @brief  Convert a binary coded decimal value to binary. RTC stores time/date values as BCD.
    @param val BCD value
    @return Binary value
*/
/**************************************************************************/
static uint8_t bcd2bin (uint8_t val) { return val - 6 * (val >> 4); }

/**************************************************************************/
/*!
    @brief  Convert a binary value to BCD format for the RTC registers
    @param val Binary value
    @return BCD value
*/
/**************************************************************************/
static uint8_t bin2bcd (uint8_t val) { return val + 6 * (val / 10); }



/** Alignment between the milis() timescale and the Unix timescale. These
  two variables are updated on each call to now(), which prevents
  rollover issues. Note that lastMillis is **not** the millis() value
  of the last call to now(): it's the millis() value corresponding to
  the last **full second** of Unix time. */
uint32_t RTC_Millis::lastMillis;
uint32_t RTC_Millis::lastUnix;

/**************************************************************************/
/*!
    @brief  Set the current date/time of the RTC_Millis clock.
    @param dt DateTime object with the desired date and time
*/
/**************************************************************************/
void RTC_Millis::adjust(const DateTime& dt) {
  lastMillis = millis();
  lastUnix = dt.unixtime();
}

/**************************************************************************/
/*!
    @brief  Return a DateTime object containing the current date/time.
            Note that computing (millis() - lastMillis) is rollover-safe as long
            as this method is called at least once every 49.7 days.
    @return DateTime object containing current time
*/
/**************************************************************************/
DateTime RTC_Millis::now() {
  uint32_t elapsedSeconds = (millis() - lastMillis) / 1000;
  lastMillis += elapsedSeconds * 1000;
  lastUnix += elapsedSeconds;
  return lastUnix;
}



/** Number of microseconds reported by micros() per "true" (calibrated) second. */
uint32_t RTC_Micros::microsPerSecond = 1000000;

/** The timing logic is identical to RTC_Millis. */
uint32_t RTC_Micros::lastMicros;
uint32_t RTC_Micros::lastUnix;

/**************************************************************************/
/*!
    @brief  Set the current date/time of the RTC_Micros clock.
    @param dt DateTime object with the desired date and time
*/
/**************************************************************************/
void RTC_Micros::adjust(const DateTime& dt) {
  lastMicros = micros();
  lastUnix = dt.unixtime();
}

/**************************************************************************/
/*!
    @brief  Adjust the RTC_Micros clock to compensate for system clock drift
    @param ppm Adjustment to make
*/
/**************************************************************************/
// A positive adjustment makes the clock faster.
void RTC_Micros::adjustDrift(int ppm) {
  microsPerSecond = 1000000 - ppm;
}

/**************************************************************************/
/*!
    @brief  Get the current date/time from the RTC_Micros clock.
    @return DateTime object containing the current date/time
*/
/**************************************************************************/
DateTime RTC_Micros::now() {
  uint32_t elapsedSeconds = (micros() - lastMicros) / microsPerSecond;
  lastMicros += elapsedSeconds * microsPerSecond;
  lastUnix += elapsedSeconds;
  return lastUnix;
}



/**************************************************************************/
/*!
    @brief  Start using the PCF2127
    @return True
*/
/**************************************************************************/
////////////////////////////////////////////////////////////////////////////////
// RTC_PCF2127 implementation
boolean RTC_PCF2127::begin(void) {
  Wire.begin();
  return true;
}

/**************************************************************************/
/*!
    @brief  Check control register 3 to see if we've run adjust() yet (setting the date/time and battery switchover mode)
    @return True if the PCF2127 has been set up, false if not
*/
/**************************************************************************/
boolean RTC_PCF2127::initialized(void) {
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)PCF2127_CONTROL_3);
  Wire.endTransmission();

  Wire.requestFrom(PCF2127_ADDRESS, 1);
  uint8_t ss = Wire._I2C_READ();
  return ((ss & 0xE0) != 0xE0);
}

/**************************************************************************/
/*!
    @brief  Set the date and time
    @param dt DateTime to set
*/
/**************************************************************************/
void RTC_PCF2127::adjust(const DateTime& dt) {
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)3); // start at location 3
  Wire._I2C_WRITE(bin2bcd(dt.second()));
  Wire._I2C_WRITE(bin2bcd(dt.minute()));
  Wire._I2C_WRITE(bin2bcd(dt.hour()));
  Wire._I2C_WRITE(bin2bcd(dt.day()));
  Wire._I2C_WRITE(bin2bcd(0)); // skip weekdays
  Wire._I2C_WRITE(bin2bcd(dt.month()));
  Wire._I2C_WRITE(bin2bcd(dt.year() - 2000));
  Wire.endTransmission();
}

/**************************************************************************/
/*!
    @brief  Get battery switchover mode
    @return mode Pcf2127SwitchOverMode
*/
/**************************************************************************/
Pcf2127SwitchOverMode RTC_PCF2127::readSwitchOverMode(void) {
  
  // Get current config 
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)PCF2127_CONTROL_3);
  Wire.endTransmission();

  Wire.requestFrom(PCF2127_ADDRESS, (byte)1);
  uint8_t inByte = Wire._I2C_READ();
  return (inByte &= 0xE0) >> 5;
}

/**************************************************************************/
/*!
    @brief  Set battery switchover mode
    @param mode Pcf2127SwitchOverMode
*/
/**************************************************************************/
void RTC_PCF2127::writeSwitchOverMode(Pcf2127SwitchOverMode mode) {
  // set to battery switchover mode
  
  // Get current config 
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)PCF2127_CONTROL_3);
  Wire.endTransmission();

  Wire.requestFrom(PCF2127_ADDRESS, (byte)1);
  uint8_t inByte = Wire._I2C_READ();
  inByte &= 0x1F; // clear positions
  inByte |= (mode << 5); // set positions
  
  // Write new config
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)PCF2127_CONTROL_3);
  Wire._I2C_WRITE((byte)inByte );
  Wire.endTransmission();
}

/**************************************************************************/
/*!
    @brief  Get battery battery low flag
    @return bool (true when battery is low)
*/
/**************************************************************************/
bool RTC_PCF2127::readBattLowFlag(void) {

  // read current configuration
  Pcf2127SqwPinMode previous_SqwPinMode = readSqwPinMode();
  Pcf2127SwitchOverMode previous_SwitchOverMode = readSwitchOverMode();
  Pcf2127TimeStampFunction previous_TimeStampFunction = readTimestampFunction();

  // put RTC Normal power setup (reading low battery flag)
  writeSqwPinMode(PCF2127_OFF);
  writeSwitchOverMode(PCF2127_SODIR_LBATEN_PWRFAILEN);
  writeTimestampFunction(PCF2127_TSOFF_DIS); 

  // Get current config 
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)PCF2127_CONTROL_3);
  Wire.endTransmission();

  Wire.requestFrom(PCF2127_ADDRESS, (byte)1);
  uint8_t inByte = Wire._I2C_READ();

  // return to previous configuration
  writeSqwPinMode(previous_SqwPinMode);
  writeSwitchOverMode(previous_SwitchOverMode);
  writeTimestampFunction(previous_TimeStampFunction); 

  return (inByte &= 0x04)  == 0x04 ? true : false;
}

/**************************************************************************/
/*!
    @brief  Get timestamp function
    @return tsoff Pcf2127TimeStampFunction
*/
/**************************************************************************/
Pcf2127TimeStampFunction RTC_PCF2127::readTimestampFunction(void) {
	
  // Get current config 
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)PCF2127_TSCONTROL);
  Wire.endTransmission();

  Wire.requestFrom(PCF2127_ADDRESS, (byte)1);
  uint8_t inByte = Wire._I2C_READ();
  return (inByte &= 0x40) >> 6;
}

/**************************************************************************/
/*!
    @brief  Set timestamp function
    @param tsoff Pcf2127TimeStampFunction
*/
/**************************************************************************/
void RTC_PCF2127::writeTimestampFunction(Pcf2127TimeStampFunction tsoff) {
	
  // Get current config 
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)PCF2127_TSCONTROL);
  Wire.endTransmission();

  Wire.requestFrom(PCF2127_ADDRESS, (byte)1);
  uint8_t inByte = Wire._I2C_READ();
  inByte &= 0xBF; // clear position
  inByte |= (tsoff << 6); // set position
	
  // Write new config
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)PCF2127_TSCONTROL);
  Wire._I2C_WRITE((byte)inByte); // 0x00
  Wire.endTransmission();
}

/**************************************************************************/
/*!
    @brief  Get the current date/time
    @return DateTime object containing the current date/time
*/
/**************************************************************************/
DateTime RTC_PCF2127::now() {
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE((byte)3);
  Wire.endTransmission();

  Wire.requestFrom(PCF2127_ADDRESS, 7);
  uint8_t ss = bcd2bin(Wire._I2C_READ() & 0x7F);
  uint8_t mm = bcd2bin(Wire._I2C_READ());
  uint8_t hh = bcd2bin(Wire._I2C_READ());
  uint8_t d = bcd2bin(Wire._I2C_READ());
  Wire._I2C_READ();  // skip 'weekdays'
  uint8_t m = bcd2bin(Wire._I2C_READ());
  uint16_t y = bcd2bin(Wire._I2C_READ()) + 2000;

  return DateTime (y, m, d, hh, mm, ss);
}

/**************************************************************************/
/*!
    @brief  Read the mode of the SQW pin on the PCF8523
    @return SQW pin mode as a Pcf2127SqwPinMode enum
*/
/**************************************************************************/
Pcf2127SqwPinMode RTC_PCF2127::readSqwPinMode() {
  int mode;

  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE(PCF2127_CLKOUTCONTROL);
  Wire.endTransmission();

  Wire.requestFrom((uint8_t)PCF2127_ADDRESS, (uint8_t)1);
  mode = Wire._I2C_READ();

  mode &= 0x7;
  return static_cast<Pcf2127SqwPinMode>(mode);
}

/**************************************************************************/
/*!
    @brief  Set the SQW pin mode on the PCF2127
    @param mode The mode to set, see the Pcf2127SqwPinMode enum for options
*/
/**************************************************************************/
void RTC_PCF2127::writeSqwPinMode(Pcf2127SqwPinMode mode) {
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE(PCF2127_CLKOUTCONTROL);
  Wire._I2C_WRITE(mode);
  Wire.endTransmission();
}

/**************************************************************************/
/*!
    @brief  Use an offset to calibrate the PCF2127. This can be used for:
            - Aging adjustment
            - Temperature compensation
            - Accuracy tuning
    @param ppm Offset value from -7 to +8. See the datasheet for exact ppm values.
*/
/**************************************************************************/
void RTC_PCF2127::calibrate(int8_t ppm) {
  uint8_t reg = (uint8_t) ppm & 0xF;

  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE(PCF2127_OFFSET);
  Wire._I2C_WRITE(reg);
  Wire.endTransmission();
}

/**************************************************************************/
/*!
    @brief  Read data from the PCF2127's NVRAM
    @param buf Pointer to a buffer to store the data - make sure it's large enough to hold size bytes
    @param size Number of bytes to read
    @param address Starting NVRAM address, from 0 to 511
*/
/**************************************************************************/
void RTC_PCF2127::readnvram(uint8_t* buf, uint16_t size, uint16_t address) {
  
  address &= PCF2127_STATIC_RAM_MASK;
  size = (address + size) > PCF2127_STATIC_RAM_MAX_ADD ? PCF2127_STATIC_RAM_MAX_ADD - address : size;
  uint8_t add_h = (address & 0x100) >> 8;
  uint8_t add_l = (address & 0xFF);
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE(PCF2127_RAM_addr_MSB);
  Wire._I2C_WRITE(add_h); 
  Wire._I2C_WRITE(add_l);
  Wire.endTransmission();

  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE(PCF2127_RAM_rd_cmd);
  Wire.endTransmission();

  Wire.requestFrom((uint8_t) PCF2127_ADDRESS, size);
  for (uint8_t pos = 0; pos < size; ++pos) {
    buf[pos] = Wire._I2C_READ();
  }
}

/**************************************************************************/
/*!
    @brief  Write data to the PCF2127's NVRAM
    @param address Starting NVRAM address, from 0 to 511
    @param buf Pointer to buffer containing the data to write
    @param size Number of bytes in buf to write to NVRAM
*/
/**************************************************************************/
void RTC_PCF2127::writenvram(uint16_t address, uint8_t* buf, uint16_t size) {

  address &= PCF2127_STATIC_RAM_MASK;
  size = (address + size) > PCF2127_STATIC_RAM_MAX_ADD ? PCF2127_STATIC_RAM_MAX_ADD - address : size;
  uint8_t add_h = (address & 0x100) >> 8;
  uint8_t add_l = (address & 0xFF);
  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE(PCF2127_RAM_addr_MSB);
  Wire._I2C_WRITE(add_h); 
  Wire._I2C_WRITE(add_l);
  Wire.endTransmission();

  Wire.beginTransmission(PCF2127_ADDRESS);
  Wire._I2C_WRITE(PCF2127_RAM_wrt_cmd);
  for (uint8_t pos = 0; pos < size; ++pos) {
    Wire._I2C_WRITE(buf[pos]);
  }
  Wire.endTransmission();
}

/**************************************************************************/
/*!
    @brief  Shortcut to read one byte from NVRAM
    @param address NVRAM address, 0 to 511
    @return The byte read from NVRAM
*/
/**************************************************************************/
uint8_t RTC_PCF2127::readnvram(uint16_t address) {
  uint8_t data;
  readnvram(&data, 1, address);
  return data;
}

/**************************************************************************/
/*!
    @brief  Shortcut to write one byte to NVRAM
    @param address NVRAM address, 0 to 511
    @param data One byte to write
*/
/**************************************************************************/
void RTC_PCF2127::writenvram(uint16_t address, uint8_t data) {
  writenvram(address, &data, 1);
}

/**************************************************************************/
/*!
    @brief  Put RTC in Low power mode
    @param none
    @param none
*/
/**************************************************************************/
void RTC_PCF2127::setLowPowerMode(void) {
  writeSqwPinMode(PCF2127_OFF);
  writeSwitchOverMode(PCF2127_SODIR_LBATDIS_PWRFAILDIS);
  writeTimestampFunction(PCF2127_TSOFF_DIS); 
}
/**************************************************************************/
/*!
    @brief  Check if RTC is in Low power mode
    @param none
    @param bool true when in low power mode
*/
/**************************************************************************/
bool RTC_PCF2127::isInLowPowerMode(void) {
  Pcf2127SqwPinMode sqwPinMode = readSqwPinMode();
  Pcf2127SwitchOverMode switchOverMode = readSwitchOverMode();
  Pcf2127TimeStampFunction timeStampFunction = readTimestampFunction();

  if ((sqwPinMode == PCF2127_OFF) && 
      (switchOverMode == PCF2127_SODIR_LBATDIS_PWRFAILDIS) && 
      (timeStampFunction == PCF2127_TSOFF_DIS))
    return true;
  else
    return false;
}