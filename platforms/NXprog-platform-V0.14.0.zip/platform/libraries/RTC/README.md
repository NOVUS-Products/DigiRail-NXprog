# NOVUS NXprog RTC library

This is a fork of JeeLab's fantastic real time clock library for Arduino (see https://jeelabs.org/2010/02/05/new-date-time-rtc-library/).

Modified to add support to onboard [NX PCF2127 Accurate RTC with integrated quartz crystal for industrial
applications](https://www.nxp.com/docs/en/data-sheet/PCF2127.pdf)

Please note that dayOfTheWeek() ranges from 0 to 6 inclusive with 0 being 'Sunday'.

