/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include "pins_arduino.h"
#include "pins_nxprog.h"
#include "NXprog.h"
#include "nx_expert_dout.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_tone.h"

// --------------------------------- NXprog extensions ---------------------------------
void nx_tone(uint8_t pin, unsigned int frequency, unsigned long duration)
{
    if(isDOutPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        // do not change current configuration
	    if (NovusConfig.doutCFG[idx_port].mode == _DOUT_PULSE_TRAIN)
	    {
            // only works if the duration is specified and smaller than maximum uint16_t
            // frequency must be  5Hz or 1Hz
            if(((duration > 100) && (duration < 65535)) &&
               ((frequency == 1) || (frequency == 5)))
            {
                uint16_t pulsePeriod = (uint16_t)(10/frequency);
                // 50% duty cycle
                uint16_t pulseTime = (uint16_t)(pulsePeriod/2);
                // duration in milliseconds
                uint16_t nPulse = (uint16_t)((duration/100)/pulsePeriod);

                if(nPulse > 1) 
                {
                    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
                    // Checks if port requires reconfiguration
                    if((NovusConfig.doutCFG[idx_port].num_pulses != nPulse) ||
                       (NovusConfig.doutCFG[idx_port].pulse_period != pulsePeriod) ||
                       (NovusConfig.doutCFG[idx_port].pulse_time != pulseTime))
                       ExpertClassDigitalOut::setActuationMode(pin, _DOUT_PULSE_TRAIN, pulseTime, pulsePeriod, nPulse);

                    digitalWrite(pin, HIGH);
                }

            }
    	}
    }
}

void nx_notone(uint8_t pin)
{
    if(isDOutPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
	    if (NovusConfig.doutCFG[idx_port].mode == _DOUT_PULSE_TRAIN)
	    {
            digitalWrite(pin, LOW);
        }
    }
}
