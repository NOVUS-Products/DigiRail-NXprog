/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include "pins_arduino.h"
#include "pins_nxprog.h"
#include "NXprog.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_registers.h"
#include "nx_wiring_digital.h"
#include "nx_expert.h"

#define UNUSED(x) (void)(x)

// --------------------------------- NXprog extensions ---------------------------------
void nx_pinMode(__attribute__((unused))uint8_t pin, __attribute__((unused))PinMode mode)
{
	/* Function not supported in NXprog. Please, use NovusIOExpert library */
	WARNING("pinMode not implemented for this port");	
}

void nx_turnOffPWM(uint8_t pin)
{
	UNUSED(pin);
	/* Function not supported in NXprog. Please, use NovusIOExpert library */
	WARNING("turnOffPWM not implemented for this port");	
}

void nx_digitalWrite(uint8_t pin, PinStatus val)
{
    if(isDOutPinNXprog(pin) == false) {
        return;
	}

	uint16_t config;
    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

	/* Set output to value */
	if (val == LOW) { /* If LOW */
		config = 0;
	} else if (val == CHANGE) { /* If TOGGLE */
		IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DI_STATE + idx_port),1,0);
		if(IndoorComm.res.error != INDOOR_OK)
			/* no action on error */
			return;
		else
		{
			if(IndoorComm.res.value == 0)
				config = 1;
			else 
				config = 0;
		}
	/* If HIGH OR  > TOGGLE  */
	} else {
		config = 1;
	}

    IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DO_VALUE + idx_port),1,&config);
}

PinStatus nx_digitalRead(uint8_t pin)
{
    if(isDInPinNXprog(pin) == false && isDOutPinNXprog(pin) == false) {
        return LOW;
	}

    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
	/*
	* Reads value in digital Input Channel, when it's  set as Instant (LOGIC) Value.
	*/

	if( isDOutPinNXprog(pin) )
	{
		IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DO_STATE + idx_port),1,0);
	}
	else
	{
		IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DI_STATE + idx_port),1,0);
	}
	
	if(IndoorComm.res.value){
		return HIGH;
	} else {
		return LOW;
	}
	return LOW;
}
