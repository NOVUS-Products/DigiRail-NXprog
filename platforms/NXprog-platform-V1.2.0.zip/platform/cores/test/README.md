Compilation/Execution of unit tests
===================================
Unit tests are automatically executed as a post-build step.
```bash
mkdir build && cd build
cmake ..
make
```
