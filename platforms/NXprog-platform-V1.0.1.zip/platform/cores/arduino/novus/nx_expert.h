/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#ifndef NXIOEXPERT_H
#define NXIOEXPERT_H

#include "NXprog.h"

#ifdef __cplusplus
extern "C" {
#endif

class ExpertClass
{
	private:

	public:
		static bool setMainsFrequency(nx_mains_freq_t freq);
    static bool getMainsFrequency(nx_mains_freq_t *freq);

    static bool analogInput_setState(const uint8_t pin, bool enable);
    static bool analogInput_setMode(const uint8_t pin, nx_ain_sensor_t type, nx_ain_temp_unit_t temp, float safeState); 
    static bool analogInput_setUnit(const uint8_t pin, nx_ain_temp_unit_t unit);
    static bool analogInput_enFilter(const uint8_t pin, int time);
    static bool analogInput_setRange(const uint8_t pin, uint32_t low, uint32_t high);
    static bool analogInput_setSamplingRate(const uint8_t pin, nx_ain_sampling_rate_t rate);

    static bool analogOutput_setMode(const uint8_t pin, nx_aout_type_t type, nx_aout_range_t range, nx_aout_poweron_state_t poweronState, uint16_t poweronValue, uint16_t watchdogValue);
    static bool analogOutput_setState(const uint8_t pin, bool enable);
    static bool analogOutput_setPowerOnValue(const uint8_t pin,uint16_t poweronValue);
    static bool analogOutput_setPowerOnState(const uint8_t pin, nx_aout_poweron_state_t state);
    static bool analogOutput_setSafeValue(const uint8_t pin,uint16_t safeValue);

    static bool digitalInput_setFunctionMode(const uint8_t pin, nx_din_function_t function);

    static void digitalOutput_setMode(uint8_t pin, nx_dout_actuation_mode_t opMode, uint16_t pulseTime, uint16_t pulsePeriod, uint16_t nPulse, nx_dout_poweron_state_t po_state, bool po_value, bool safe_state);
    static void digitalOutput_enPulse(uint8_t pin, nx_dout_actuation_mode_t opMode, uint16_t pulseTime, uint16_t pulsePeriod, uint16_t nPulse);


    static bool Modbus_configRS485(nx_modbus_baudrate_t baudrate, nx_modbus_parity_t parity, nx_modbus_stopbits_t stopbits);


};

#ifdef __cplusplus
}
#endif
#endif

extern ExpertClass NovusExpert;