/*
	Microchip 24LC256 I2C 256K EEPROM Arduino Library - Header File
	Made by Gonçalo Passos (more info @ http://diogopassos.pt) 2018
	BSD 2-Clause License
    ** Modified: 2019-08-28 by NOVUS Automation
*/

#ifndef _24LC256_H
#define _24LC256_H

#include "Arduino.h"

#define ADD_EEPROM_UTILS
#define WRITE_SUCESS 1
#define WRITE_ERROR 0xFE //-1

class E24LC256 
{
public:
	E24LC256();
	bool detect();
	int8_t writeByte(uint16_t address, byte data);
    int8_t updateByte(uint16_t address, byte data);
	int8_t writePage(uint16_t address,int size, byte *buffer);
	byte readByte(uint16_t address);
	int readPage(uint16_t address,int size, byte *buffer);
	int length();

private:
	void ack_pooling();
};

#ifdef ADD_EEPROM_UTILS
class EEPROM_UTILS {
  public:
    void printHex(Stream *dev, int num, int precision);
    void dump(Stream *ddev, E24LC256& mem, int initial_address, int final_address);
};
#endif

#endif
