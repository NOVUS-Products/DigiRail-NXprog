/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#ifndef NXIOEXPERTAIN_H
#define NXIOEXPERTAIN_H

#include "NXprog.h"

#ifdef __cplusplus
extern "C" {
#endif

class ExpertClassAnalogInput
{
	private:

	public:
    static bool setState(const uint8_t pin, bool enable);
    static bool setMode(const uint8_t pin, nx_ain_sensor_t type, nx_ain_temp_unit_t temp, float safeState); 
    static bool setModeLinear(const uint8_t pin, nx_ain_sensor_t type, float safeState); 
    static bool setUnit(const uint8_t pin, nx_ain_temp_unit_t unit);
    static bool enFilter(const uint8_t pin, int time);
    static bool setRange(const uint8_t pin, uint32_t low, uint32_t high);
    static bool setSamplingRate(const uint8_t pin, nx_ain_sampling_rate_t rate);
};

#ifdef __cplusplus
}
#endif
#endif

extern ExpertClassAnalogInput NovusExpertAIn;