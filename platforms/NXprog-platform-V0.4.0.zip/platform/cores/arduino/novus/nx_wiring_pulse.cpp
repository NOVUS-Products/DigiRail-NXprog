
/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include "pins_arduino.h"
#include "pins_nxprog.h"
#include "NXprog.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_wiring_pulse.h"

// --------------------------------- NXprog extensions ---------------------------------
// TODO: tentar desenhar solu��o que n�o seja pooling por MODBUS
// TODO: implementar mesmo com a limita��o de desempenho?
unsigned long nx_pulseIn(uint8_t pin, uint8_t state, unsigned long timeout)
{
	return nx_pulseInLong(pin, state, timeout);
}

// TODO: tentar desenhar solu��o que n�o seja pooling por MODBUS
// TODO: implementar mesmo com a limita��o de desempenho?
unsigned long nx_pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout)
{
	uint8_t bit = 0x01;
	uint8_t stateMask = (state ? bit : 0);

	unsigned long startMicros = micros();

	// wait for any previous pulse to end
	while ((digitalRead(pin) & bit) == stateMask) {
		if (micros() - startMicros > timeout)
			return 0;
	}

	// wait for the pulse to start
	while ((digitalRead(pin) & bit) != stateMask) {
		if (micros() - startMicros > timeout)
			return 0;
	}

	unsigned long start = micros();
	// wait for the pulse to stop
	while ((digitalRead(pin) & bit) == stateMask) {
		if (micros() - startMicros > timeout)
			return 0;
	}
	return micros() - start;
}