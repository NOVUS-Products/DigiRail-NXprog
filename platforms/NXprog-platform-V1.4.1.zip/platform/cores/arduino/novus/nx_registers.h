
#pragma once

#include <stdint.h>

class NXprogRegisters
{
  public:
    typedef enum 
	{
		SERIAL_NUMBER = 0,
		HARDWARE_SET = 2,
		ETH_MAC = 4,
	    FW_VERSION = 11,
		HW_ID = 12,
	} GeneralInformation;
	
	typedef enum
	{
		RS485_MODBUS_MODE = 1027,
		RS485_MODBUS_ADDR, 
		RS485_BAUDRATE,
		RS485_PARITY,
		RS485_STOPBIT,

	} RS485;
  
  	typedef enum
	{
		ETHERNET_INFO_IP0 = 100,
		ETHERNET_INFO_IP1,
		
		ETHERNET_INFO_MASK0 = 108,
		ETHERNET_INFO_MASK1,
		
		ETHERNET_INFO_GATE0 = 116,
		ETHERNET_INFO_GATE1,
		
		ETHERNET_INFO_DNS0 = 124,
		ETHERNET_INFO_DNS1,
		
		ETHERNET_ENABLE = 1033,

		ETHERNET_DHCP_ENABLE = 1036,
		ETHERNET_IP0,
		ETHERNET_IP1,
		
		ETHERNET_MASK0 = 1045,
		ETHERNET_MASK1,
		
		ETHERNET_GATE0 = 1053,
		ETHERNET_GATE1,
		
		ETHERNET_DNS0 = 1061,
		ETHERNET_DNS1,

	} Ethernet;
	
	/* General registers */
	typedef enum _gen_reg {
		MAINS_FREQ = 1024,
		IO_RECONFIG_ALL = 1082
	} GeneralRegisters;

	/* Registers for Digital Output */
	typedef enum
	{
		DO_VALUE = 500, //SET CH1
		DO_ENABLE= 1900,
		DO_FUNCTION=1925, //INSTANT 0 PULSE 1 PULSE_TRAIN 2
		DO_PULSE_TIME, //CASE PULSE OR PULSE_TRAIN
		DO_PULSE_PERIOD, //CASE PULSE OR PULSE_TRAIN
		DO_NUMBER_OF_PULSES, //CASE PULSE OR PULSE_TRAIN
		DO_POWER_ON_STATE , //OFF 0 CONFIGURED_VALUE 1 LAST 2
		DO_POWER_ON_VALUE, 
		DO_SAFE_STATE,
	} DigOutput;
  
	/* Registers for Digital Input */
	typedef enum
	{
		DI_STATE = 70, //READ CH1	
		DI_COUNTER_LO=22, //READ LOW BYTE COUNTER VALUE
		DI_COUNTER_HI, //READ HIGH BYTE COUNTER VALUE
		DI_TIMEON_LO=38, //TIME_ON VALUE
		DI_TIMEON_HI,
		DI_TIMEOFF_LO=54, //TIME_OFF VALUE
		DI_TIMEOFF_HI,
		
		DI_ENABLE=1500,
		DI_FUNCTION=1525, //LOGIC 0 COUNTER_UP 1 COUNTER_DOUNW 2 TIME 3
		DI_TYPE,
		DI_DEBOUNCE,  //Debounce in ms
		DI_PRESET,
		DI_FORCE=1533,
		DI_PAUSE //PAUSE COUNTER OR TIME
	} DigInput;

   /* Registers for Analog Output */
	typedef enum
	{
		AO_VALUE = 524, //SET VALUE CH1
		AO_ENABLE=2700,
		AO_TYPE=2725, //0-20mA 0 4-20mA 1 0-10V 2
		AO_RANGE, //%x100 0 0-32000 1 
		AO_PON_STATE, //OFF 0 CONFIGURED_VALUE 1 LAST 2
		AO_PON_VALUE,
		AO_SAFE_VALUE,
	} AnOutput;
   		
	/* Registers for Analog Input */
	typedef enum
	{
		AI_READ_LO=14,
		AI_READ_HI,

		AI_ENABLE=2300,
		AI_TYPE=2325, //TCJ TCK ....
		AI_UNIT, //TEMPERATURE UNIT - CELCIUS 0 F 1
		AI_FILTER, //FIRST ORDER FILTER
		AI_LOWSCALE_LO,
		AI_LOWSCALE_HI,
		AI_HIGHSCALE_LO,
		AI_HIGHSCALE_HI,
		AI_SAMPLING,
		AI_SAFE_VALUE_LO=2336,
		AI_SAFE_VALUE_HI
	} AnInput;

	/* NXprog special registers (general purpouse) */
	typedef enum 
	{
		NXPROG_AREA_START=400,
		NXPROG_AREA_END=499
	} SpecialReigsters;
};
