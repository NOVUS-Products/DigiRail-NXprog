

#include "novus/nx_shared_mem.h"    

/* ---------------------------------------------------------------------------------
 * Shared Modbus buffers used for internal communication
 * Thes buffers will be used by indoor communication and virtual RS485.
 * ---------------------------------------------------------------------------------*/
uint8_t Modbus_PDU[MODBUS_MAX_PDU_LENGTH]; 
uint8_t Modbus_PDU_r[MODBUS_MAX_PDU_LENGTH]; 
