/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#ifndef NXIOEXPERTAOUT_H
#define NXIOEXPERTAOUT_H

#include "NXprog.h"


#ifdef __cplusplus
extern "C" {
#endif

class ExpertClassAnalogOutput
{
	private:

	public:
    static bool setMode(const uint8_t pin, nx_aout_type_t type, nx_aout_range_t range, nx_aout_poweron_state_t poweronState, uint16_t poweronValue, uint16_t watchdogValue);
    static bool setState(const uint8_t pin, bool enable);
    static bool setPowerOnValue(const uint8_t pin,uint16_t poweronValue);
    static bool setPowerOnState(const uint8_t pin, nx_aout_poweron_state_t state);
    static bool setSafeValue(const uint8_t pin,uint16_t safeValue);
};

#ifdef __cplusplus
}
#endif
#endif

extern ExpertClassAnalogOutput NovusExpertAOut;