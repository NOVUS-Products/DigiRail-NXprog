/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#ifndef NXIOEXPERTDOUT_H
#define NXIOEXPERTDOUT_H

#include "NXprog.h"

#ifdef __cplusplus
extern "C" {
#endif


class ExpertClassDigitalOut
{
	private:

	public:
    static bool setMode(uint8_t pin, nx_dout_actuation_mode_t opMode, uint16_t pulseTime, uint16_t pulsePeriod, uint16_t nPulse, nx_dout_poweron_state_t po_state, bool po_value, bool safe_state);
    static bool setState(const uint8_t pin, bool enable);
    static bool setSafeState(const uint8_t pin, bool safe_state);
    static bool setPowerOnState(const uint8_t pin, nx_dout_poweron_state_t po_state);
    static bool setActuationMode(const uint8_t pin, nx_dout_actuation_mode_t opMode, uint16_t pulseTime, uint16_t pulsePeriod, uint16_t nPulse);
    static bool enInstant(const uint8_t pin, nx_dout_poweron_state_t po_state, bool safe_state);
};

#ifdef __cplusplus
}
#endif
#endif

extern ExpertClassDigitalOut NovusExpertDOut;