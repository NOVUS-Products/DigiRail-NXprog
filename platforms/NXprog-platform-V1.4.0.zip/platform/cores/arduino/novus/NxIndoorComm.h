/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
 *
 * 	| End |  Fun | Num | Pin | Sin | D00 | D01 | D02 | D03 | D04 | D05 | D06 | D07 | D08 | Crc | Crc |  --> Message packet
 * 	| End |  Fun | Num | Pin | D00 | D01 | D02 | D03 | D04 | D05 | D06 | D07 | D08 | D09 | Crc | Crc |  --> Configuration packet
 *
 *	xxxx.xxxx.xxxx.xxxx --> 16 Bytes
 *  ||||.||||.||||.||||
 *  ||||.||||.||||.|||V
 *  ||||.||||.||||.||V--- CRC low
 *  ||||.|VVV.VVVV.VV---- CRC high
 *  ||||.V---.----.------ Data
 *  |||V.----.----.------ Data ( SIGNAL )
 *  ||V-.----.----.------ Data ( PIN )
 *  |V--.----.----.------ Data ( # of bytes )
 *  V---.----.----.------ Function
 *  ----.----.----.------ Address
 * 
 *	-----------------------------
 *	-- Standard Payload Modbus --
 *	-----------------------------
 *
 * | Address | Function | High Register | Low Register | High Value | Low Value | Low CRC | Low CRC |
 * 		--> return ( ECHO )
 * | Address | Function | High Register | Low Register | High Quantity Registers | Low Quantity Registers | Low CRC | Low CRC |
 *		--> return( | Address | Function | Bytes Readen | High Value | Low Value | ... | Low CRC | Low CRC |
 *
 * Writting in a book and reading a book: Registers allways sequentially.
 *
 *	----------------------
 *	-- Modbus Functions --
 *	----------------------
 * 
 *	 3- Read single/block register
 * 	 6- Write single register
 * 	16- Write block of registers
 *
 *
 */
#pragma once

#include <stdint.h>

#ifndef NXINDOORCOMM_H
#define NXINDOORCOMM_H

/* Changing code */

/* Constants */
// Communication
#define BaudRate        128000
// #define MAX_INDOOR_PDU  255

// IndorComm error codes (returned in response.error)
#define INDOOR_OK 							0
#define INDOOR_ERR_EMPTY_SEND_BUF			1
#define INDOOR_ERR_FUNC_UNEXPECTED 			2   // Function unexpected
#define INDOOR_ERR_CRC_ERROR				3
#define INDOOR_ERR_NOT_SAME_SLAVE_ADDRESS	4   // not same slave address 
#define INDOOR_ERR_NOT_SAME_FUNC			5   // response has different function number 
#define INDOOR_ERR_WRONG_WRITE_RESP			10  // wrong response for '06 Write Single Register' and '16 Write Multiple Registers'
#define INDOOR_ERR_CONFIG_FAILED			11  // Tried 3 times and config didn't end, break and send an error
#define INDOOR_ERR_IN_SLAVE_MODE			51  // error: slave mode
#define INDOOR_ERR_IN_GTW_MODE				52  // error: gateway mode 
#define INDOOR_ERR_NO_DATA_FROM_SLAVE		53  // error: no data received from rs485 slave
#define INDOOR_ERR_EMPTY_RECV_BUF			60
#define INDOOR_ERR_OVERFLOW_SEND_BUF		61
#define INDOOR_ERR_UNDERFLOW_RECV_BUF		62
#define INDOOR_ERR_TIME_OUT					99

typedef enum _modbus_function {
	FUNC_READSINGLE = 3,
	FUNC_WRITESINGLE = 6,		
	FUNC_WRITEMULTIPLE = 16,
	SPECIAL_FUNCTION = 43
} function_t;

typedef enum _modbus_special_function {
	COMMUNICATER_MASTER = 0x30,
	RECEIVE_MODBUS = 0x32,
	RESPONSE_MODBUS = 0x33,		
	SET_MODBUS_ADDRESS = 0x34
} special_function_t;

/* ----------------------------------------------------------------------------------------------------
*	This class is private to core, the communication with baseboard is established here. DO NOT MODIFY
* ----------------------------------------------------------------------------------------------------	*/ 
class IndoorCommClass
{
  private:
	bool checkCRC( uint8_t *pBufferSerial, uint8_t u8Index );
  
  public:
	struct response{
		int error; // Return 0 if 'OK' and other values according to errors.txt 
		uint16_t value; // Return the value read in the input pins.
	};
	
	response res;
  	
	void send(function_t function, uint16_t reg, uint16_t quantity, uint16_t* value);
	void send_modbus_master(const uint8_t* send_buffer, uint16_t send_buffer_len, uint8_t* receive_buffer, uint16_t expected_len);
};

extern IndoorCommClass IndoorComm;


#endif