/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "Arduino.h"
#include "nx_expert.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_registers.h"

#define DECIMAL 100 //1 for 1, 10 for 2, 100 for 3....
#define REGISTER_READ_ERROR 0xFF

#define WRITE_SINGLE_REGISTER(r,v)          ({ \
                                                uint16_t value = v; \
                                                bool result = true; \
                                            	IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)(NXprogRegisters::r), 1, &value); \
                                                if(IndoorComm.res.error != INDOOR_OK)\
                                                    result = false;\
                                                result; \
                                            })

#define WRITE_MULTIPLE_REGISTER(r,v,n)      ({ \
                                                bool result = true; \
                                            	IndoorComm.send(FUNC_WRITEMULTIPLE, (NXprogRegisters::r), n, v); \
                                                if(IndoorComm.res.error != INDOOR_OK)\
                                                    result = false;\
                                                result; \
                                            })

static bool _wdt_active = false;

bool ExpertClass::Modbus_configRS485(nx_modbus_baudrate_t baudrate, nx_modbus_parity_t parity, nx_modbus_stopbits_t stopbits)
{
Serial.println("Modbus_configRS485 1");
    if(!WRITE_SINGLE_REGISTER(RS485_BAUDRATE,baudrate))
        return false;
    if(!WRITE_SINGLE_REGISTER(RS485_PARITY,parity))
        return false;
    if(!WRITE_SINGLE_REGISTER(RS485_STOPBIT,stopbits))
        return false;
    NovusConfig.applyConfig();
    
    return true;
}

void ExpertClass::enableWDT() 
{
    _wdt_active = true;
    digitalWrite(WDT_EN_A, HIGH);
    toggleWDT();
}

void ExpertClass::disableWDT()
{
    _wdt_active = false;
    digitalWrite(WDT_EN_A, LOW);
}

void ExpertClass::toggleWDT() 
{    
    if(_wdt_active) 
    {
        digitalWrite(WDI, LOW);
        delayMicroseconds(4);
        digitalWrite(WDI, HIGH);
    }
}

bool ExpertClass::isWDTActive() 
{
    if (digitalRead(WDT_EN_A) == LOW)
        _wdt_active = false;
    else
        _wdt_active = true;    

    return _wdt_active;
}

// this method uses 'config' as normaly defined in Serial configuration
bool ExpertClass::Modbus_configRS485(nx_modbus_mode_t rs485_mode, uint8_t address, unsigned long baud, uint16_t config)
{
    bool result = true;
    nx_modbus_baudrate_t baudrate;
    nx_modbus_parity_t parity;
    nx_modbus_stopbits_t stopbits;

    switch (baud)
    {
    case 1200:
        baudrate = _1200;
        break;
    case 2400:
        baudrate = _2400;
        break;
    case 4800:
        baudrate = _4800;
        break;
    case 9600:
        baudrate = _9600;
        break;
    case 19200:
        baudrate = _19200;
        break;
    case 38400:
        baudrate = _38400;
        break;
    case 57600:
        baudrate = _57600;
        break;
    case 115200:
        baudrate = _115200;
        break;
    default:
        result = false;
        break;
    }

    // serial mode
    switch (config)
    {
    case SERIAL_5N1:
    case SERIAL_6N1:
    case SERIAL_7N1:
    case SERIAL_5N2:
    case SERIAL_6N2:
    case SERIAL_7N2:
    case SERIAL_5E1:
    case SERIAL_6E1:
    case SERIAL_7E1:
    case SERIAL_5E2:
    case SERIAL_6E2:
    case SERIAL_7E2:
    case SERIAL_5O1:
    case SERIAL_6O1:
    case SERIAL_7O1:
    case SERIAL_5O2:
    case SERIAL_6O2:
    case SERIAL_7O2:
        // non-supported modes 
        result = false;
        break;
    case SERIAL_8O1:
        parity = _ODD;
        stopbits = _1_STOPBIT;
        break;
    case SERIAL_8O2:
        parity = _ODD;
        stopbits = _2_STOPBIT;
        break;
    case SERIAL_8E1:
        parity = _EVEN;
        stopbits = _1_STOPBIT;
        break;
    case SERIAL_8E2:
        parity = _EVEN;
        stopbits = _2_STOPBIT;
        break;
    case SERIAL_8N1:
        parity = _NONE;
        stopbits = _1_STOPBIT;
        break;
    case SERIAL_8N2:
        parity = _NONE;
        stopbits = _2_STOPBIT;
        break;
    default:
        result = false;
        break;
    }

    if (result)
    {
        result = ExpertClass::Modbus_configRS485(rs485_mode, address, baudrate, parity, stopbits);
    }

	return result;
}

// this method uses NOVUS semantics
bool ExpertClass::Modbus_configRS485(nx_modbus_mode_t rs485_mode, uint8_t address, nx_modbus_baudrate_t baudrate, nx_modbus_parity_t parity, nx_modbus_stopbits_t stopbits)
{
    bool result = false;
    uint16_t send_buffer[5] = {0};

    //Configure Mode and address
    send_buffer[0] = rs485_mode;
    if (rs485_mode == _SERVER)
        send_buffer[1] = (address == 0) ? 1 : address;
    else
        send_buffer[1] = 1;
    send_buffer[2] = baudrate;
    send_buffer[3] = parity;
    send_buffer[4] = stopbits;
    if(WRITE_MULTIPLE_REGISTER(RS485_MODBUS_MODE,&send_buffer[0],2))
    {
        if(WRITE_MULTIPLE_REGISTER(RS485_BAUDRATE,&send_buffer[2],3))
        {
            NovusConfig.applyConfig();
            result = true;
        }
    }
	return result;
}

ExpertClass NovusExpert;