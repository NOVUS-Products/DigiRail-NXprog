/*
 * Copyright (c) 2019, NOVUS Automation
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * 
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 * 
 * * Neither the name of Majenko Technologies nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <string.h>
#include "nxprog_analog_input.h"
#include "novus/nx_config.h"
#include "novus/nx_config_aux.h"
#include "novus/nx_expert_ain.h"

#define MAX_BUFF_SIZE 50

bool NXprogAnalogInput::basicCheck(char *port_name, int *port) {
  bool is_input; 
  *port = translatePort(port_name, &is_input);

  if(*port < 0)
  {
    dev->println("Invalid port.");
    return false;
  }

  if(!is_input)
  {
    dev->println(F("This is not an analog input port."));
    return false;
  }
  return true;
}

void NXprogAnalogInput::setState(char *port_name, bool state){
  int port;
  if(basicCheck(port_name, &port))
  {
    if(NovusExpertAIn.setState(port, state))
      dev->println(F("Ok."));
    else
      dev->println(F("FAILED!"));
  }
}

void NXprogAnalogInput::readInput(char *port_name){
  int port;
  if(basicCheck(port_name, &port))
  {
    uint32_t value;
    value = analogRead(port);
    dev->print(F(" Value: "));
    dev->println(value);
  }
}

void NXprogAnalogInput::setScale(char *port_name, int low, int high) {
  int port;
  if(basicCheck(port_name, &port))
  {
    if(NovusExpertAIn.setRange(port, low, high))
      dev->println(F("Ok."));
    else
      dev->println(F("FAILED!"));
  }
}


void NXprogAnalogInput::setInputMode(char *port_name, int type, int unit, float safeState) {
  bool is_input; 
  int port = translatePort(port_name, &is_input);
  if(port < 0)
  {
    dev->println(F("Invalid port."));
    return;
  }
  if(is_input)
  {
    nx_ain_sensor_t ain_sensor;
    if(!translateSensorType(type, &ain_sensor))
    {
      dev->println(F("Invalid sensor type."));
      return;
    }

    nx_ain_temp_unit_t temp_unit;
    if (!translateTempUnit(unit, &temp_unit))
    {
      dev->println(F("Invalid temperature unit."));
      return;
    }
    dev->print(F("Convert sensor type:"));
    dev->println(ain_sensor);
    dev->print(F("Convert temperature type:"));
    dev->println(temp_unit);
    if(NovusExpertAIn.setMode(port, ain_sensor, temp_unit, safeState)) 
      dev->println(F("Ok."));
    else
      dev->println(F("ERROR!"));
  }
  else
    dev->println(F("This is not an analog input port."));
}

void NXprogAnalogInput::setInputRange(char *port_name, uint32_t low, uint32_t high) {
  int port;
  if(basicCheck(port_name, &port))
  {
    if(NovusExpertAIn.setRange(port, low, high))
      dev->println(F("Ok."));
    else
      dev->println(F("ERROR!"));
  }
}

void NXprogAnalogInput::setInputTempUnit(char *port_name, int unit){
  int port;
  if(basicCheck(port_name, &port))
  {
    nx_ain_temp_unit_t c_unit = (unit == 0) ? CELSIUS : FAHRENHEIT;
    if(NovusExpertAIn.setUnit(port, c_unit))
      dev->println(F("Ok."));
    else
      dev->println(F("ERROR!"));
  }
}

void NXprogAnalogInput::analogInput_enFilter(char *port_name, int time) {
  int port;
  if(basicCheck(port_name, &port))
  {
    if(NovusExpertAIn.enFilter(port, time))
      dev->println(F("Ok."));
    else
      dev->println(F("ERROR!"));
  }
}

void NXprogAnalogInput::analogInput_setSamplingRate(char *port_name, int rate){
  int port;
  if(basicCheck(port_name, &port))
  {
    nx_ain_sampling_rate_t value = (rate == 0) ? _1_per_sec : _10_per_sec;
    if(NovusExpertAIn.setSamplingRate(port, value))
      dev->println(F("Ok."));
    else
      dev->println(F("ERROR!"));
  }
}
