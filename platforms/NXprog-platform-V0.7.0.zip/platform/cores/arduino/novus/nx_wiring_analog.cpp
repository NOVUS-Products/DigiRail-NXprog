/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include "pins_arduino.h"
#include "pins_nxprog.h"
#include "NXprog.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_registers.h"
#include "nx_wiring_analog.h"

void nx_analogReference(__attribute__((unused))uint8_t mode)
{
	/* Function not supported in NXprog. Please, use NovusIOExpert library */
	WARNING("analogReference not implemented for NXprog analog output");
}

uint32_t nx_analogRead(uint8_t pin)
{
	pin = pin & NXPROG_PIN_MASK;
	if ((pin > NUM_ANALOG_INPUTS) || (pin < 1)) return NOT_A_PIN;
	
	uint32_t ret=0;
	
	IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_READ_LO+2*(pin-1)),1,0);
	ret = IndoorComm.res.value;
	
	IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_READ_HI+2*(pin-1)),1,0);
	ret = ret|(((uint32_t)IndoorComm.res.value)<<16);
    return (ret); 
}

void nx_analogWrite(uint8_t pin, int val)
{
	pin = pin & NXPROG_PIN_MASK;
	if ((pin > NUM_ANALOG_OUTPUTS) || (pin < 1)) return;

	uint16_t u16value = 0;
	
	// If Mapping the value into a 0~32000bits range
	//This range is set in analogOutput_Modefunction
	if (NovusConfig.aoutCFG[pin-1].type == _AOUT_0_20mA ||
		NovusConfig.aoutCFG[pin-1].type == _AOUT_4_20mA ||
		NovusConfig.aoutCFG[pin-1].type == _AOUT_0_10V)
	{
		u16value  = val;
	}
	else 
	{
		u16value  = 0;
	}
	IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::AO_VALUE+(pin-1)),1,&u16value);
}
