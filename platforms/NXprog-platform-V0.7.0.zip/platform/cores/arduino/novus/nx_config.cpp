/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <Arduino.h>
#include "nx_config.h"
#include "nx_registers.h"
#include "pins_nxprog.h"

#define CONVERT_TO_TYPE(v,t,l)  ({\
									t result; \
									size_t numOfElements = sizeof(l)/sizeof(l[0]); \
									if (v < numOfElements) \
										result = pgm_read_byte(&l[v]); \
									else \
										result = pgm_read_byte(&l[0]); \
									result; \
								})

#define IS_VALID_TYPE(v,l) ({\
                                bool result; \
                                size_t numOfElements = sizeof(l)/sizeof(l[0]); \
                                if ((v >= 0) && (v < numOfElements)) \
                                  result = true; \
                                else \
                                  result = false; \
                                result; \
                           })

const nx_ain_sensor_t sensor_types[] PROGMEM = {tc_J, tc_K, tc_T, tc_E, tc_N, tc_R, tc_S, tc_B, Pt100, Pt1000, NTC, _0_60mV, _0_5V, _0_10V,  _0_20mA, _4_20mA};
const nx_ain_temp_unit_t temp_unit_types[] PROGMEM = {CELSIUS, FAHRENHEIT};
const nx_aout_type_t aout_types[] PROGMEM = {_AOUT_0_20mA, _AOUT_4_20mA, _AOUT_0_10V};
const nx_aout_range_t range_types[] PROGMEM = {_AOUT_RANGE_PERCENT, _AOUT_RANGE_VALUE};
const nx_aout_poweron_state_t poweron_types[] PROGMEM = {PO_AOUT_DISABLED, PO_AOUT_CONFIGURED_VALUE, PO_AOUT_LAST_VALID_VALUE};
const nx_dout_actuation_mode_t actuation_types[] PROGMEM = {DOUT_LOGICAL_STATE, DOUT_SINGLE_PULSE, DOUT_PULSE_TRAIN, DOUT_PWM_MODE};
const nx_din_function_t din_function_types[] PROGMEM = {DIN_LOGICAL_STATE, DIN_COUNTER_NEG_EDGE, DIN_COUNTER_POS_EDGE, DIN_INTEGRATOR};
const nx_din_type_t din_types[] PROGMEM = {DIN_PNP, DIN_NPN, DIN_DRY};
						

void NovusConfigClass::getChannelAInConfig(const uint8_t channel)
{
	ainCFG[channel].read_ok = false;
	IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_ENABLE+(50*channel)),1,0);
	if(IndoorComm.res.error == 0)
	{
		if (IndoorComm.res.value == 0)
			ainCFG[channel].enabled = false;
		else
		{
			ainCFG[channel].enabled = true;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_TYPE+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
				ainCFG[channel].type = CONVERT_TO_TYPE(IndoorComm.res.value, nx_ain_sensor_t, sensor_types);
			else
				return;
			if (IndoorComm.res.value < NTC)
			{
				IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_UNIT+(50*channel)),1,0);
				if(IndoorComm.res.error ==0)
					ainCFG[channel].unit = CONVERT_TO_TYPE(IndoorComm.res.value, nx_ain_temp_unit_t, temp_unit_types);
				else 
					return;
			}

			uint32_t aux2=0;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_LOWSCALE_LO+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
				aux2=IndoorComm.res.value;
			else
				return;              
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_LOWSCALE_HI+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
			{
				uint32_t val32 = IndoorComm.res.value;
				aux2+=(uint32_t)(val32<<16);
			}
			else
				return;
			ainCFG[channel].scale_bottom = aux2;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_HIGHSCALE_LO+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
				aux2=IndoorComm.res.value;
			else
				return;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_HIGHSCALE_HI+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
			{
				uint32_t val32 = IndoorComm.res.value;
				aux2+=(uint32_t)(val32<<16);
			}
			else
				return;
			ainCFG[channel].scale_top = aux2;

			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AI_FILTER+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
			{
				ainCFG[channel].filter = IndoorComm.res.value;
			}
			else
			{
				return;
			}

		}
		ainCFG[channel].read_ok = true;
	}
}

void NovusConfigClass::getChannelAOutConfig(const uint8_t channel)
{

	aoutCFG[channel].read_ok = false;
	IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AO_ENABLE+(50*channel)),1,0);
	if(IndoorComm.res.error ==0)
	{
		if (IndoorComm.res.value== 0)
			aoutCFG[channel].enabled = false;
		else if (IndoorComm.res.value== 1)
		{
			aoutCFG[channel].enabled = true;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AO_TYPE+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
				aoutCFG[channel].type = CONVERT_TO_TYPE(IndoorComm.res.value, nx_aout_type_t, aout_types);
			else 
				return;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AO_RANGE+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
				aoutCFG[channel].range = CONVERT_TO_TYPE(IndoorComm.res.value, nx_aout_range_t, range_types);
			else
				return;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AO_PON_STATE+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
				aoutCFG[channel].pon_state =  CONVERT_TO_TYPE(IndoorComm.res.value, nx_aout_poweron_state_t, poweron_types);
			else
				return;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AO_PON_VALUE+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
				aoutCFG[channel].pon_value = IndoorComm.res.value;
			else
				return;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::AO_SAFE_VALUE+(50*channel)),1,0);
			if(IndoorComm.res.error == 0)
				aoutCFG[channel].watchdog_value = IndoorComm.res.value;
			else
				return;
		}
		aoutCFG[channel].read_ok = true;
	}
}

void NovusConfigClass::getChannelDOutConfig(const uint8_t channel)
{
	doutCFG[channel].read_ok = false;
	IndoorComm.send(FUNC_READSINGLE,(uint16_t)((NXprogRegisters::DO_ENABLE)+(50*channel)),1,0);
	if(IndoorComm.res.error ==0)
	{
		if (IndoorComm.res.value == 0)
			doutCFG[channel].enabled = false;
		else if (IndoorComm.res.value == 1)
		{
			doutCFG[channel].read_ok = true;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DO_FUNCTION+(50*channel)),1,0);
			if(IndoorComm.res.error ==0)
				doutCFG[channel].mode = CONVERT_TO_TYPE(IndoorComm.res.value, nx_dout_actuation_mode_t, actuation_types);
			else
				return;
			uint16_t function = doutCFG[channel].mode;
			if((function > 0) && (function < 3))
			{
				IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DO_PULSE_TIME+(50*channel)),1,0);
				if(IndoorComm.res.error ==0)
					doutCFG[channel].pulse_time = IndoorComm.res.value;
				else
					return;
				IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DO_PULSE_PERIOD+(50*channel)),1,0);
				if(IndoorComm.res.error ==0)
					doutCFG[channel].pulse_period = IndoorComm.res.value;
				else
					return;

				if(function == 2)
				{
					IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DO_NUMBER_OF_PULSES+(50*channel)),1,0);
					if(IndoorComm.res.error ==0)
						doutCFG[channel].num_pulses = IndoorComm.res.value;
					else
						return;
				}
				IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DO_SAFE_STATE+(50*channel)),1,0);
				if(IndoorComm.res.error ==0)
					doutCFG[channel].safe_state = IndoorComm.res.value;
				else
					return;
			}
			else
				return;
			doutCFG[channel].read_ok = true;
		}
		else
			return;
	}

}

void NovusConfigClass::getChannelDInConfig(const uint8_t channel)
{
	// Channel is zero-based (it is not a pin)
	IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DI_ENABLE+(50*channel)),1,0);
	dinCFG[channel].read_ok = false;
	if (IndoorComm.res.error == 0)
	{
		if (IndoorComm.res.value== 0)
			dinCFG[channel].enabled = false;
		else if (IndoorComm.res.value== 1)
		{   
			dinCFG[channel].enabled = true;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DI_FUNCTION+(50*channel)),1,0);
			if(IndoorComm.res.error ==0)
				dinCFG[channel].function = CONVERT_TO_TYPE(IndoorComm.res.value, nx_din_function_t, din_function_types);
			else
				return;
			
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DI_TYPE+(50*channel)),1,0);
			if(IndoorComm.res.error ==0)
				dinCFG[channel].connection_type = CONVERT_TO_TYPE(IndoorComm.res.value, nx_din_type_t, din_types);
			else
				return;
			IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::DI_DEBOUNCE+(50*channel)),1,0);
			if(IndoorComm.res.error ==0)
				dinCFG[channel].debounce = IndoorComm.res.value;
			else
				return;
		}
		else
			return;
		
	}	
	dinCFG[channel].read_ok = true;
}

void NovusConfigClass::readAInConfig()
{
	// Friendly reminder: channel is zero-based (it is not a pin)
    for(uint8_t channel = 0; channel < NUM_ANALOG_INPUTS; channel++)
		this->getChannelAInConfig(channel);
}

void NovusConfigClass::readAOutConfig()
{
	// Friendly reminder: channel is zero-based (it is not a pin)
    for(uint8_t channel = 0; channel < NUM_ANALOG_OUTPUTS; channel++)
		this->getChannelAOutConfig(channel);
}

void NovusConfigClass::getDOutConfig()
{
	// Friendly reminder: channel is zero-based (it is not a pin)
    for(uint8_t channel = 0; channel < NUM_DIGITAL_OUTPUT_PINS; channel++)
		this->getChannelDOutConfig(channel);
}

void NovusConfigClass::getDInConfig()
{
	// Friendly reminder: channel is zero-based (it is not a pin)
    for(uint8_t channel = 0; channel < NUM_DIGITAL_INPUT_PINS; channel++)
		this->getChannelDInConfig(channel);
}

/* --- applyConfig method
 * * This method should be called whenever it is necessary to reconfigure the baseboard,
 * * such as after configuring some analog / digital input / output;
 * *
 * * Writes in the baseboard reset register and waits for it to return to zero.
 * *
 * * After writing 1 to the register, read it 3 times. If the register does not return to zero,
 * * indicates that a configuration error has occurred (it is expected that this will never occur if the functions
 * * settings are used correctly).
 * ---
*/
void NovusConfigClass::applyConfig()
{
	uint16_t config = 1;
	int i=1;
	
	//Trigger reconfig
	IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::IO_RECONFIG_ALL),1,&config); 	

	do
	{
		delay(500*i); // wait 500ms at first time, 1s at second time, ...
		IndoorComm.send(FUNC_READSINGLE,(uint16_t)NXprogRegisters::IO_RECONFIG_ALL,1,&config);
		i++;
		if(i==4 && IndoorComm.res.value ==1)
		{
			// Tried 3 times and config didn't end, break and send an error
			IndoorComm.res.error=11;
			break;
		}		
	} while(IndoorComm.res.value == 1);
}

bool NovusConfigClass::getAInConfig(const int pin, ain_cfg_t *output)
{
	if(!isAInPinNXprog(pin))
		return false;

	uint8_t pin_idx = PIN_TO_PORT_INDEX(pin);

    // refresh configuration
	this->getChannelAInConfig(pin_idx);

    if(!ainCFG[pin_idx].read_ok)
		return false;

	memcpy(output, &ainCFG[pin_idx], sizeof(ain_cfg_t));
	return true;
}

bool NovusConfigClass::getAOutConfig(const int pin, aout_cfg_t *output)
{
	if(!isAOutPinNXprog(pin))
		return false;

	uint8_t pin_idx = PIN_TO_PORT_INDEX(pin);

    // refresh configuration
	this->getChannelAOutConfig(pin_idx);

    if(!aoutCFG[pin_idx].read_ok)
		return false;

	memcpy(output, &aoutCFG[pin_idx], sizeof(aout_cfg_t));
	return true;
}

bool NovusConfigClass::getDInConfig(const int pin, din_cfg_t *input)
{
	if(!isDInPinNXprog(pin))
		return false;

	uint8_t pin_idx = PIN_TO_PORT_INDEX(pin);

    // refresh configuration
	this->getChannelDInConfig(pin_idx);

    if(!dinCFG[pin_idx].read_ok)
		return false;

	memcpy(input, &dinCFG[pin_idx], sizeof(din_cfg_t));
	return true;
}

bool NovusConfigClass::getDOutConfig(const int pin, dout_cfg_t *output)
{
	if(!isDOutPinNXprog(pin))
		return false;

	uint8_t pin_idx = PIN_TO_PORT_INDEX(pin);

    // refresh configuration
	this->getChannelDOutConfig(pin_idx);

    if(!doutCFG[pin_idx].read_ok)
		return false;

	memcpy(output, &doutCFG[pin_idx], sizeof(dout_cfg_t));
	return true;

}

bool NovusConfigClass::getDigiRailFWVersion(uint16_t *value)
{
	bool return_value = false; 
	IndoorComm.send(FUNC_READSINGLE,(uint16_t)(NXprogRegisters::FW_VERSION),1,value); 	
	if(IndoorComm.res.error == 0)
	{
		*value = IndoorComm.res.value;
		return_value = true;
	}
	return return_value;
}


NovusConfigClass NovusConfig;


