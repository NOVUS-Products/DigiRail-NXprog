/*
	Microchip 24LC256 I2C 256K EEPROM Arduino Library - Code File
	Made by Gonçalo Passos (more info @ http://diogopassos.pt) 2018
	BSD 2-Clause License
    ** Modified: 2019-08-28 by NOVUS Automation
*/

#include "EEPROM.h"
#include "Wire.h"


// ----------- E24LC256 type memory
#define ONBOARD_E24LC256_ADD 0x50
#define E24LC256_SIZE 0X7D00

E24LC256::E24LC256()
{
	Wire.begin();
}

/*
	Function to detect if 24LC256 is present in bus with the address passed in constructor.
	Returns true if eeprom is present in i2c bus.
*/

bool E24LC256::detect() {
	byte code;
	Wire.beginTransmission(ONBOARD_E24LC256_ADD);
	code = Wire.endTransmission();
	return (code == 0);
}

/*
	Acknowledge Pooling Algoritihm recomended by Manufacturer	
*/

void E24LC256::ack_pooling()
{
	byte code = -1;
	do
	{
		Wire.beginTransmission(ONBOARD_E24LC256_ADD);
		Wire.write((byte) 0);
		code = Wire.endTransmission();
	}
	while(code != 0);
}

/*
	Function that writes a byte in EEPROM.
	address parameter: eeprom cell address between 0x0000 and 0x7CFF
	data parameter: byte to write to a eeprom cell.
	Returns the state of operation (WRITE_SUCCESS or WRITE_ERROR)
*/

int8_t E24LC256::writeByte(uint16_t address, byte data)
{
	ack_pooling();
	Wire.beginTransmission(ONBOARD_E24LC256_ADD);
	Wire.write((byte)((address & 0xFF00) >> 8));
	Wire.write((byte)(address & 0x00FF));
	Wire.write((byte) data);

	if(Wire.endTransmission() == 0)
	{
		return WRITE_SUCCESS;
	}
	else
	{
		return WRITE_ERROR;
	}
}

/*
	Function that reads one byte from eeprom.
	address parameter: eeprom cell address between 0x0000 and 0x7CFF
	Returns the byte readed from eeprom.
*/

byte E24LC256::readByte(uint16_t address)
{
	ack_pooling();
	Wire.beginTransmission(ONBOARD_E24LC256_ADD);
	Wire.write((byte)((address & 0xFF00) >> 8));
	Wire.write((byte)(address & 0x00FF));
	Wire.endTransmission();

	Wire.requestFrom(ONBOARD_E24LC256_ADD,(int) 1);
	Wire.available();
	return Wire.read();
}

/*
	Write multiple bytes into eeprom
	address parameter:	address of the first eeprom cell to write
	size parameter:	size of buffer
	buffer parameter: address of buffer in primary memory.
	Returns the state of operation (WRITE_ERROR or WRITE_SUCCESS) 

	To do: Check memory size.
*/

int8_t E24LC256::writePage(uint16_t address,int size, byte *buffer)
{
	ack_pooling();
	if((address + size) >= E24LC256_SIZE)
		return WRITE_ERROR;
	
	bool error = false;

	if(size > 64)
	{
		
		uint16_t new_size = size;
		uint16_t current_buffer_loc;
		uint16_t base_addr = address;
		while(new_size > 64)
		{
			Wire.beginTransmission(ONBOARD_E24LC256_ADD);
			Wire.write((byte)((base_addr & 0xFF00) >> 8));
			Wire.write((byte)(base_addr & 0x00FF));

			for(uint16_t i = current_buffer_loc; i<current_buffer_loc + 64;i++)
			{
				Wire.write((byte) buffer[i]);
			}

			error = error || (Wire.endTransmission() == 0);

			if(error)
			{
				return WRITE_ERROR;
			}

			ack_pooling();

			current_buffer_loc += 63;
			base_addr += 63;
			new_size -= 64;
		}

		Wire.beginTransmission(ONBOARD_E24LC256_ADD);
		Wire.write((byte)((base_addr & 0xFF00) >> 8));
		Wire.write((byte)(base_addr & 0x00FF));

		for(uint16_t i = current_buffer_loc ; i<new_size;i++)
		{
			Wire.write(buffer[i]);
		}

		Wire.endTransmission();
	}
	else
	{
		Wire.beginTransmission(ONBOARD_E24LC256_ADD);
		Wire.write((byte)((address & 0xFF00) >> 8));
		Wire.write((byte)(address & 0x00FF));
		for(int i = 0; i<size;i++)
		{
			Wire.write((byte) buffer[i]);
		}

		Wire.endTransmission();
	}


	if(error)
	{
		return WRITE_ERROR;
	}
	else
	{
		return WRITE_SUCCESS;
	}
}

/*
	Read multiple eeprom cell address's and saves into a buffer
	address parameter:	address of the first eeprom cell to read
	size parameter:	size of buffer
	buffer parameter: address of buffer in primary memory.
	Returns the number of bytes readed

*/

int E24LC256::readPage(uint16_t address,int size, byte *buffer)
{
	if((address + size) >= E24LC256_SIZE)
		return WRITE_ERROR;

	int bytes_read = 0;
	Wire.beginTransmission(ONBOARD_E24LC256_ADD);
	Wire.write((byte)((address & 0xFF00) >> 8));
	Wire.write((byte)(address & 0x00FF));
	Wire.endTransmission();

	Wire.requestFrom(ONBOARD_E24LC256_ADD,size);
	Wire.available();

	for(int i = 0;i<size;i++)
	{
		buffer[i] = Wire.read();
		bytes_read++;
	}
	return bytes_read;
}

/*
	Returns EEPROM maximum storage in bytes
*/
uint16_t E24LC256::length()
{
	return E24LC256_SIZE;
}

/*
	Function that updates a byte in EEPROM.
	Only performs write operation when new value is different from existing value
	address parameter: eeprom cell address between 0x0000 and 0x7CFF
	data parameter: byte to write to a eeprom cell.
	Returns the state of operation (WRITE_SUCCESS or WRITE_ERROR)
*/
int8_t E24LC256::updateByte(uint16_t address, byte data)
{
  if(address >= E24LC256_SIZE)
    return WRITE_ERROR;
  if(this->readByte(address) != data)
      return this->writeByte(address, data);
  return WRITE_SUCCESS;
}

#ifdef ADD_EEPROM_UTILS
// --------------------- EEPROM utils
void EEPROM_UTILS::printHex(Stream *dev, int num, int precision) 
{
  char tmp[16];
  char format[128];

  sprintf(format, "0x%%.%dX", precision);

  sprintf(tmp, format, num);
  dev->print(tmp);
}

void EEPROM_UTILS::dump(Stream *dev, E24LC256& mem, int initial_address, int final_address)
{
  
  if(initial_address<final_address)
  {
      byte read_buffer[final_address-initial_address];
      dev->print("                       EEPROM Memory Dump - range: ");
      this->printHex(dev, initial_address, 4);
      dev->print(" to ");
      this->printHex(dev, final_address, 4);
      dev->print('\n');
      dev->println("---------------------------------------------------------------------------------------");
      dev->println("         0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F");
      mem.readPage(initial_address,final_address-initial_address,read_buffer);

      int i = 0;
      while(i < final_address-initial_address)
      {
        this->printHex(dev, i, 4);
        dev->print(": ");
        for(int j = 0; j < 16; j++)
        {
          if(i > final_address-initial_address)
            break;
          this->printHex(dev,read_buffer[i],2);
          dev->print(" ");
          i++;
        }
        dev->print('\n');
      }
      dev->println("---------------------------------------------------------------------------------------");
      dev->print('\n');
    
  }
  else
  {
    dev->println("Dump error!");
  }
}

#endif