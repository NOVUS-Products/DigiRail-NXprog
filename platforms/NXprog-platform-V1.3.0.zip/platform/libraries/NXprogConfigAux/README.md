# NXprog Configuration Auxiliary Library
Arduino Auxiliary Library for NXprog 

**Features:**
 - Translates numeric types used in NXprog configuration to human readable strings.
 
## ain_sensor_to_str(nx_ain_sensor_t type, char *buffer, uint8_t max_size)

Translate
**Type**: void
**Parameters**:
Member | Type | Comment
--- | --- | ---
type | `nx_ain_sensor_t` | Sensor type
buffer | `char *` | Pointer to return string
max_size | `uint8_t` | Maximum size of input string

## ain_temp_unit_to_str(nx_ain_temp_unit_t  unit, char *buffer, uint8_t max_size)
void ain_sampling_rate_to_str(nx_ain_sampling_rate_t sampling_rate, char *buffer, uint8_t max_size);

void aout_type_to_str(nx_aout_type_t type, char *buffer, uint8_t max_size);
void aout_range_to_str(nx_aout_range_t range, char *buffer, uint8_t max_size);
void aout_pon_state_to_str(nx_aout_poweron_state_t state, char *buffer, uint8_t max_size);
MIT License
