/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <Arduino.h>
#include "NovusEthernet.h"
#include <novus/nx_registers.h>
#include <novus/NxIndoorComm.h>

#define READ_SINGLE_REGISTER(r,v)             ({ \
                                                bool op_result =  false; \
                                            	IndoorComm.send(FUNC_READSINGLE, (uint16_t)(NXprogRegisters::r), 1, &v); \
                                                if(IndoorComm.res.error == INDOOR_OK)\
                                                {\
                                                    v = IndoorComm.res.value;\
													op_result = true; \
                                                }\
                                                op_result; \
                                              })
#define HIGH(v)  ((v >> 8) & 0xFF)
#define LOW(v)   (v & 0xFF)

#define READ_IP_VALUE(r,ip_high,ip_low,c)  ({ \
											if(!READ_SINGLE_REGISTER(r,c)) \
												return false; \
											ip_high = HIGH(c); \
											ip_low = LOW(c); \
            	   			   				})
/* --------------------------------------------------------------------------------------
 *								  	Ethernet configuration
 * -------------------------------------------------------------------------------------- */
bool EthernetClass::enable()
{	
	uint16_t config;
	bool return_value = false;


 	config = 1; // 0 - fixed IP, 1 - DHCP
	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::ETHERNET_DHCP_ENABLE), 1, &config);
	if(IndoorComm.res.error == INDOOR_OK)
	{	
		config = 1; // Enable
		IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::ETHERNET_ENABLE), 1, &config);
		if(IndoorComm.res.error == INDOOR_OK)
		{		
			NovusConfig.applyConfig();
			return_value = true;
		}
	}
	return return_value;
}
 
bool EthernetClass::enable(IPAddress ip, IPAddress mask, IPAddress gateway, IPAddress DNS)
{	
	uint16_t config[2] = {0};
	bool return_value = false;
	 
	config[0] = (((uint16_t)ip[0]) << 8) | ((uint16_t)ip[1]); //Ip 0 e 1
	config[1] = (((uint16_t)ip[2]) << 8) | ((uint16_t)ip[3]); //Ip 2 e 3	 
	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::ETHERNET_IP0), 2, config);
	if(IndoorComm.res.error == INDOOR_OK)
	{	
		config[0] = (((uint16_t)mask[0]) << 8) | ((uint16_t)mask[1]); //mask 0 e 1
		config[1] = (((uint16_t)mask[2]) << 8) | ((uint16_t)mask[3]); //mask 2 e 3
		IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::ETHERNET_MASK0), 2, config);
		if(IndoorComm.res.error == INDOOR_OK)
		{	
			config[0] = (((uint16_t)gateway[0]) << 8) | ((uint16_t)gateway[1]); //gateway 0 e 1
			config[1] = (((uint16_t)gateway[2]) << 8) | ((uint16_t)gateway[3]); //gateway 2 e 3
			IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::ETHERNET_GATE0), 2, config);
			if(IndoorComm.res.error == INDOOR_OK)
			{	
				config[0] = (((uint16_t)DNS[0]) << 8) | ((uint16_t)DNS[1]); //DNS 0 e 1
				config[1] = (((uint16_t)DNS[2]) << 8) | ((uint16_t)DNS[3]); //DNS 2 e 3
				IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::ETHERNET_DNS0), 2, config);
				if(IndoorComm.res.error == INDOOR_OK)
				{	
					config[0] = 0; // 0 - fixed IP, 1 - DHCP
					IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::ETHERNET_DHCP_ENABLE), 1, config);
					if(IndoorComm.res.error == INDOOR_OK)
					{	
						config[0] = 1; // Enable
						IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::ETHERNET_ENABLE), 1, config);
						if(IndoorComm.res.error == INDOOR_OK)
						{	
							NovusConfig.applyConfig();
							return_value = true;
						}
					}
				}
			}
		}
	}
	return return_value;
}
 
bool EthernetClass::disable()
{
	bool return_value = false;
	uint16_t config = 0;

	IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)(NXprogRegisters::ETHERNET_ENABLE), 1, &config);
	if(IndoorComm.res.error == INDOOR_OK)
		return_value = true;
	return return_value;
 }
 
bool EthernetClass::readConfig(nx_ethernet_cfg *cfg)
{
	uint16_t config;

	if(!READ_SINGLE_REGISTER(ETHERNET_ENABLE,config))
		return false;
	cfg->enabled = ((config == 1) ? true : false);

	if(!READ_SINGLE_REGISTER(ETHERNET_DHCP_ENABLE,config))
		return false;
	cfg->dhcp = ((config == 1) ? true : false);

	// if fixed IP, retrieve configured parameters
	if(!cfg->dhcp)
	{
		READ_IP_VALUE(ETHERNET_IP0,cfg->ip[0],cfg->ip[1],config);
		READ_IP_VALUE(ETHERNET_IP1,cfg->ip[2],cfg->ip[3],config);
		
		READ_IP_VALUE(ETHERNET_MASK0,cfg->mask[0],cfg->mask[1],config);
		READ_IP_VALUE(ETHERNET_MASK1,cfg->mask[2],cfg->mask[3],config);

		READ_IP_VALUE(ETHERNET_GATE0,cfg->gateway[0],cfg->gateway[1],config);
		READ_IP_VALUE(ETHERNET_GATE1,cfg->gateway[2],cfg->gateway[3],config);

		READ_IP_VALUE(ETHERNET_DNS0,cfg->dns[0],cfg->dns[1],config);
		READ_IP_VALUE(ETHERNET_DNS1,cfg->dns[2],cfg->dns[3],config);
	}
	else // DHCP data
	{
		READ_IP_VALUE(ETHERNET_INFO_IP0,cfg->ip[0],cfg->ip[1],config);
		READ_IP_VALUE(ETHERNET_INFO_IP1,cfg->ip[2],cfg->ip[3],config);
		
		READ_IP_VALUE(ETHERNET_INFO_MASK0,cfg->mask[0],cfg->mask[1],config);
		READ_IP_VALUE(ETHERNET_INFO_MASK1,cfg->mask[2],cfg->mask[3],config);

		READ_IP_VALUE(ETHERNET_INFO_GATE0,cfg->gateway[0],cfg->gateway[1],config);
		READ_IP_VALUE(ETHERNET_INFO_GATE1,cfg->gateway[2],cfg->gateway[3],config);

		READ_IP_VALUE(ETHERNET_INFO_DNS0,cfg->dns[0],cfg->dns[1],config);
		READ_IP_VALUE(ETHERNET_INFO_DNS1,cfg->dns[2],cfg->dns[3],config);
	}
	return true;
}


EthernetClass Novus_ETHERNET;


