/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef NovusNXprog_h
#define NovusNXprog_h

#ifdef __cplusplus
extern "C"{
#endif
// -------------------------- Analog Input types definition  --------------------------
// Identified as A1 and A2, on its front panel. 
// These channels are suitable for measuring temperature or any other values 
// represented by standard linear electrical signals. 
// -- Analog input types
typedef enum _ain_sensor {
	tc_J = 0,
	tc_K  = 1,
	tc_T = 2,
	tc_N = 3,
	tc_R = 4,
	tc_S = 5,
	tc_B = 6,
	tc_E = 7,
	Pt100 = 8,
	Pt1000 = 9,
	NTC = 10,
	_0_60mV = 11,
	_0_5V = 12,
	_0_10V = 13,
	_0_20mA = 14,
	_4_20mA = 15
} nx_ain_sensor_t;

// -- Temperature unit
typedef enum _temp_unit {
	_CELSIUS = 0,
	_FAHRENHEIT = 1
} nx_ain_temp_unit_t;

// -- Number of readings performed each second by the analog input channel on the received input signal
typedef enum _sampling_rate {
	_1_per_sec = 0,
	_10_per_sec = 1
} nx_ain_sampling_rate_t;

// -- Antinoise algorithm
typedef enum _ain_antinoise {
	_ANTINOISE_OFF = 0,
	_ANTINOISE_LOW = 1,
	_ANTINOISE_MEDIUM = 2,
	_ANTINOISE_HIGH = 3
} nx_ain_antinoise_t;

// ------------------------- Analog Output types definition  --------------------------
// Identified as O1 and O2 on NXprog front panel. 
// These channels establish analog values of voltage or current according to the digital values received.
// -- Value for the analog output when the device is turned on and 
//     before an analog output value setting command is received
typedef enum _aout_type {
	_AOUT_0_20mA = 0,
	_AOUT_4_20mA = 1,
	_AOUT_0_10V = 2
} nx_aout_type_t;

typedef enum _aout_range {
	_AOUT_RANGE_PERCENT = 0,
	_AOUT_RANGE_VALUE = 1
} nx_aout_range_t;

typedef enum _aout_poweron_state {
	_PO_AOUT_DISABLED = 0,
	_PO_AOUT_CONFIGURED_VALUE,
	_PO_AOUT_LAST_VALID_VALUE
} nx_aout_poweron_state_t;


// ------------------------- Digital Output types definition  -------------------------
// channels of transistor-sourcing digital output, identified as K1 ... K8, 
// and with 4 channels of relay-type digital outputs, identified as R1 ... R4, on
// NXprog front panel
// -- Definition of operation mode of the digital output
typedef enum _actuation_mode {
	_DOUT_LOGICAL_STATE = 0,
	_DOUT_SINGLE_PULSE,
	_DOUT_PULSE_TRAIN,
	_DOUT_PWM_MODE
} nx_dout_actuation_mode_t;

// -- initial state of the device's analog output after initializing the device until a 
//    command is acknowledged
typedef enum _dout_poweron_state {
	_PO_DOUT_OFF = 0,
	_PO_DOUT_ON,
	_PO_DOUT_LAST_VALID
} nx_dout_poweron_state_t;

// -- Condition to be adopted by the digital output when a command is 
//    interrupted due to a communication failure.
typedef enum _safe_state {
	_SAFE_DOUT_OFF = 0,
	_SAFE_DOUT_ON
} nx_dout_safe_state_t;

// ------------------------- Digital Input types definition  --------------------------
// Digital inputs, identified as D1 ... D4 ... D8, on NXprog front panel. 
// These digital channels are suitable for receiving Dry Contact, NPN and PNP electrical signals
// -- Different functions performed by a digital input
typedef enum _din_function {
	_DIN_LOGICAL_STATE = 0,
	_DIN_COUNTER_RISING_EDGE,
	_DIN_COUNTER_FALLING_EDGE,
	_DIN_INTEGRATOR
} nx_din_function_t;

typedef enum _din_type {
	_DIN_PNP = 0,
	_DIN_NPN,
	_DIN_DRY
} nx_din_type_t;

// ------------------------------- General definitions --------------------------------
typedef enum _mains_freq {
	_50Hz = 1,
	_60Hz = 2
} nx_mains_freq_t;

// --------------------------- NXprog Modbus  definitions -----------------------------
typedef enum _modbus_baudrate {
	_1200 = 0,
	_2400 = 1,
	_4800 = 2,	
	_9600 = 3,	
	_19200 = 4,	
	_38400 = 5,	
	_57600 = 6,	
	_115200 = 7
} nx_modbus_baudrate_t;

typedef enum _modbus_parity {
	_NONE = 0,
	_EVEN = 1,
	_ODD = 3
} nx_modbus_parity_t;

typedef enum _modbus_stopbits {
	_1_STOPBIT = 0,
	_2_STOPBIT = 1
} nx_modbus_stopbits_t;

typedef enum _modbus_mode {
	_SERVER = 0,
	_GATEWAY = 1,
	_MASTER = 2
} nx_modbus_mode_t;

#define WARNING(msg)    do {Serial.print("Warning: "); Serial.println(msg);} while(0==1)

#ifdef __cplusplus
} // extern "C"
#endif

#endif