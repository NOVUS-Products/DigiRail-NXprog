/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#ifndef NXIOEXPERT_DIN_H
#define NXIOEXPERT_DIN_H

#include "NXprog.h"

#define NX_INVALID_COUNTER 0xFFFFFFFF
#define NX_INVALID_TIME 0xFFFFFFFF

#ifdef __cplusplus
extern "C" {
#endif

class ExpertClassDigitalInput
{
	private:

	public:
    static bool setMode(const uint8_t pin, nx_din_function_t function, nx_din_type_t connection_type, uint16_t debounce, uint32_t preset);
    static bool setState(const uint8_t pin, bool enable);
    static bool setFunctionMode(const uint8_t pin, nx_din_function_t function);
    static bool setConnectionType(const uint8_t pin, nx_din_type_t connection_type);
    static bool setDebounce(const uint8_t pin, uint16_t debounce);
    static uint32_t readCounter(const uint8_t pin);
    static uint32_t readTimer(const uint8_t pin, bool onoff);
    static bool setPreset(const uint8_t pin, uint32_t preset);
};

#ifdef __cplusplus
}
#endif
#endif

extern ExpertClassDigitalInput NovusExpertDIn;