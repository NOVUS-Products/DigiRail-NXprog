
#ifndef NXCONFIG_H
#define NXCONFIG_H

extern "C" {
#include <stdint.h>
}
#include "pins_arduino.h"
#include "pins_nxprog.h"
#include "NxIndoorComm.h"
#include "NXprog.h"
#include "nx_expert.h"
#include "nx_expert_ain.h"



typedef struct _ain_cfg {
	bool      read_ok;
	bool      enabled;
	nx_ain_sensor_t  type; 
	nx_ain_temp_unit_t  unit;
	int32_t  scale_bottom;
	int32_t  scale_top;
	uint16_t  filter;
	nx_ain_sampling_rate_t sampling_rate;
} ain_cfg_t;

typedef struct _aout_cfg {
	bool      read_ok;
	bool      enabled;
	nx_aout_type_t  type; 
	nx_aout_range_t  range;
	nx_aout_poweron_state_t pon_state;
	uint16_t pon_value;
	uint16_t watchdog_value;
} aout_cfg_t;

typedef struct _dout_cfg {
	bool      read_ok;
	bool      enabled;
	nx_dout_actuation_mode_t mode;
	uint16_t  pulse_time;
	uint16_t  pulse_period;
	uint16_t  num_pulses;
	bool      safe_state;
	nx_dout_poweron_state_t poweron_state;
} dout_cfg_t;

typedef struct _din_cfg {
	bool      read_ok;
	bool      enabled;
	nx_din_function_t  function; 
	nx_din_type_t  connection_type;
	uint16_t  debounce;
} din_cfg_t;

class NovusConfigClass
{
	private:
		void getChannelAInConfig(const uint8_t channel);
		void getChannelAOutConfig(const uint8_t channel);
		void getChannelDOutConfig(const uint8_t channel);
		void getChannelDInConfig(const uint8_t channel);

		friend class ExpertClass;
		friend class ExpertClassAnalogInput;
		friend class ExpertClassAnalogOutput;
		friend class ExpertClassDigitalInput;
		friend class ExpertClassDigitalOut;
	public:
		ain_cfg_t ainCFG[NUM_ANALOG_INPUTS];
		aout_cfg_t aoutCFG[NUM_ANALOG_OUTPUTS]; 
		dout_cfg_t doutCFG[NUM_DIGITAL_OUTPUT_PINS];
		din_cfg_t dinCFG[NUM_DIGITAL_INPUT_PINS];

	public:
		void readAInConfig();
		void readAOutConfig();
		void getDOutConfig();
		void getDInConfig();

		bool getAInConfig(const int pin, ain_cfg_t *output);
		bool getAOutConfig(const int pin, aout_cfg_t *output);

		bool getDInConfig(const int pin, din_cfg_t *input);
		bool getDOutConfig(const int pin, dout_cfg_t *output);

		static bool getDigiRailFWVersion(uint16_t *value);
		static void applyConfig();

};

extern NovusConfigClass NovusConfig;

#endif