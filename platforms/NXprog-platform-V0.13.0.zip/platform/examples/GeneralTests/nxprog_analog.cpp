/*
 * Copyright (c) 2019, NOVUS Automation
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * 
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 * 
 * * Neither the name of Majenko Technologies nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <string.h>
#include "nxprog_analog.h"
#include "novus/nx_config.h"
#include "novus/nx_config_aux.h"
#include "novus/nx_expert.h"

#define MAX_BUFF_SIZE 50

bool NXprogAnalog::translateSensorType(int type, nx_ain_sensor_t *ain_sensor){
  nx_ain_sensor_t all_types[] = {tc_J, tc_K, tc_T, tc_E, tc_N, tc_R, tc_S, tc_B, Pt100, Pt1000, NTC, _0_60mV, _0_5V, _0_10V,  _0_20mA, _4_20mA};
  size_t numOfElements = sizeof(all_types)/sizeof(all_types[0]);
  bool ret_val = false;
  if ((type >= 0) && (type < numOfElements))
  {
    *ain_sensor = all_types[type];
    ret_val = true;
  }
  return ret_val;
}

bool NXprogAnalog::translateTempUnit(int type, nx_ain_temp_unit_t *temp_unit) {
  nx_ain_temp_unit_t all_types[] = { _CELSIUS, _FAHRENHEIT};
  size_t numOfElements = sizeof(all_types)/sizeof(all_types[0]);
  bool ret_val = false;
  if ((type >= 0) && (type < numOfElements))
  {
    *temp_unit = all_types[type];
    ret_val = true;
  }
  return ret_val;
}

int NXprogAnalog::translatePort(char *port_name, bool *is_input) {
  int ret_val = -1;
  *is_input = false;
  
  if(strcasecmp(port_name, "A1") == 0)
  {
    ret_val = A1;
    *is_input = true;
  }
  else if (strcasecmp(port_name, "A2") == 0)
  {
    ret_val = A2;
    *is_input = true;
  }
  else if (strcasecmp(port_name, "O1") == 0)
  {
    ret_val = O1;
    *is_input = false;
  }
  else if (strcasecmp(port_name, "O2") == 0)
  {
    ret_val = O2;
    *is_input = false;
  }

  return ret_val;
  
}

void NXprogAnalog::analogOutputInfo(char *port_name, int pin){
  aout_cfg_t aout_cfg;
  char message_buf[MAX_BUFF_SIZE];

  dev->print(F("-----------> Analog Output ("));
  dev->print(strupr(port_name));
  dev->println(F(") configuration"));
  if(!NovusConfig.getAOutConfig(pin, &aout_cfg))
    dev->println(F("Reading error"));
  else
  {
    dev->print(F("Enabled: "));
    dev->println(aout_cfg.enabled);
    aout_type_to_str(aout_cfg.type, message_buf, MAX_BUFF_SIZE);
    dev->print(F("Output type: ("));
    dev->print(aout_cfg.type);
    dev->print(F(") "));
    dev->println(message_buf);
    dev->print(F("Range: ("));
    dev->print(aout_cfg.range);
    dev->print(F(") "));
    aout_range_to_str(aout_cfg.range, message_buf, MAX_BUFF_SIZE);
    dev->println(message_buf);
    dev->print(F("Power-on state: ("));
    dev->print(aout_cfg.pon_state);
    dev->print(F(") "));
    aout_pon_state_to_str(aout_cfg.pon_state, message_buf, MAX_BUFF_SIZE);
    dev->println(message_buf);
    dev->print(F("Power-on value: "));
    dev->println(aout_cfg.pon_value);
    dev->print(F("Watchdog value: "));
    dev->println(aout_cfg.watchdog_value);
  }
  dev->println(""); 
}

void NXprogAnalog::analogInputInfo(char *port_name, int pin){
  ain_cfg_t ai_cfg;
  char message_buf[MAX_BUFF_SIZE];

  dev->print(F("-----------> Analog Input ("));
  dev->print(strupr(port_name));
  dev->println(F(") configuration"));
  if(!NovusConfig.getAInConfig(pin, &ai_cfg))
    dev->println(F("Reading error"));
  else
  {
    dev->print(F("Enabled: "));
    dev->println(ai_cfg.enabled);
    ain_sensor_to_str(ai_cfg.type, message_buf, MAX_BUFF_SIZE);
    dev->print(F("Sensor type: ("));
    dev->print(ai_cfg.type);
    dev->print(F(") "));
    dev->println(message_buf);
    dev->print(F("Temp unit: ("));
    dev->print(ai_cfg.unit);
    dev->print(") ");
    ain_temp_unit_to_str(ai_cfg.unit, message_buf, MAX_BUFF_SIZE);
    dev->println(message_buf);
    dev->print(F("Sampling rate: ("));
    dev->print(ai_cfg.sampling_rate);
    dev->print(F(") "));
    ain_sampling_rate_to_str(ai_cfg.sampling_rate, message_buf, MAX_BUFF_SIZE);
    dev->println(message_buf);
    dev->print(F("Scale bottom: "));
    dev->println(ai_cfg.scale_bottom);
    dev->print(F("Scale top: "));
    dev->println(ai_cfg.scale_top);
    dev->print(F("Filter: "));
    dev->println(ai_cfg.filter);
  }
  dev->println(F("")); 
}

void NXprogAnalog::info(char *port_name){
  bool is_input; 
  int port = translatePort(port_name, &is_input);

  if(port < 0)
  {
    dev->println(F("Invalid port."));
    return;
  }
  if(is_input)
    analogInputInfo(port_name, port);
  else
    analogOutputInfo(port_name, port);
}


NXprogAnalog::NXprogAnalog(Stream *d) {
    dev = d;
}
