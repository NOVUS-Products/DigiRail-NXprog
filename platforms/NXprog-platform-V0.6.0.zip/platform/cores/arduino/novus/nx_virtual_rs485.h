/*
  This file is part of the ArduinoRS485 library.
  Copyright (c) 2018 Arduino SA. All rights reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _VIRTUALRS485_H_INCLUDED
#define _VIRTUALRS485_H_INCLUDED

#include <Arduino.h>
#include "novus/nx_shared_mem.h"


class NOVUSVirtualRS485Class {
  public:
    NOVUSVirtualRS485Class();

    void begin(unsigned long baudrate, uint16_t config);
    void end();
    int available();
    int peek();
    int read(void);
    void flush();
    size_t write(const uint8_t *req, int req_length);
    size_t readBytes(uint8_t *rsp, int rsp_length);
    void setSlaveAddress(const uint8_t address);
    uint8_t getSlaveAddress();
    void clearSlaveAddress();

    operator bool();

    void beginTransmission();
    void endTransmission();
    void receive();
    void noReceive();

    void sendBreak(unsigned int duration);
    void sendBreakMicroseconds(unsigned int duration);

  private:
    bool _transmisionBegun;
    uint8_t _ibuf[MODBUS_MAX_PDU_LENGTH];
    bool _ibuf_empty;
    uint8_t _ibuf_idx;
    uint8_t _ibuf_size;

    size_t receiveMEIResponse(uint8_t *rsp, int max_length);
    uint8_t sendMEIRequest(const uint8_t special_command, const uint8_t *payload = nullptr, int payload_size = 0);

};

extern NOVUSVirtualRS485Class RS485;

#endif