CLI
===

Command Line stream interface for Arduino etc
