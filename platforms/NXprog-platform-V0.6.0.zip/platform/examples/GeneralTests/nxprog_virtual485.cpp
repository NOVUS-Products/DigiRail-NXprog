/*
 * Copyright (c) 2019, NOVUS Automation
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * 
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 * 
 * * Neither the name of Majenko Technologies nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <NOVUS/nx_virtual_rs485.h>
#include "nxprog_virtual485.h"

#define DUMP_PDU(buffer, size)  {\
                                for (uint16_t x = 0; x < size; x++)\
								                  {\
  									              if(x == 0) \
  	  									            dev->print(F("[ "));\
	  	  							            if (buffer[x] > 0XF)\
		  	  							            dev->print(buffer[x],HEX);\
			  	  					            else\
				  	  				            {\
			  	  	  					          dev->print(F("0"));\
						  	  			          dev->print(buffer[x],HEX);\
            	  				  				}\
						                			dev->print(" ");\
									                if (x == (size-1))\
										                dev->println(F("]\n"));\
		 						                  } \
               									  dev->flush(); \
                                }

void NXprog485::terminate() {
	RS485.clearSlaveAddress();
}

bool NXprog485::init() {
	RS485.setSlaveAddress(42);
	return true;
}

void NXprog485::available() {
	int available = RS485.available();
	dev->print(" Num byte available: ");
	dev->println(available);
}

void NXprog485::readBytes(){
	uint8_t buf[MODBUS_MAX_PDU_LENGTH];
	size_t read_size = RS485.readBytes(buf, MODBUS_MAX_PDU_LENGTH);
	if(read_size > 0)
		DUMP_PDU(buf,read_size)
	else
		dev->print(" No data available");
}

void NXprog485::peekAndRead(){
  uint8_t buf[MODBUS_MAX_PDU_LENGTH];
  int available = RS485.available();
  if(available > 0)
  {
    for(int i = 0; i < available; i++)
    {
      dev->print(RS485.peek());
      dev->print(":");
      dev->print(RS485.read());
      dev->print(",");
    }
  }
  else
    dev->print("No data available.");
  dev->print("\r\n");
}

void NXprog485::readInPieces(){
  uint8_t buf[MODBUS_MAX_PDU_LENGTH];
  int available = RS485.available();
  int read_bytes;
  if(available > 0)
  {
    int i = 0;
    int chunk = 2;
    do {
      read_bytes = RS485.readBytes(&buf[i], chunk);
      chunk = (i + chunk) >= available ? available - i : 2;
      i += chunk;
    } while (i < available);
    DUMP_PDU(buf,available);
    
  }
  else
    dev->print(" No data available");
}

void NXprog485::fakeResponse(){
  uint8_t response[] = {0x2A, 0x03, 0x02, 0x00, 0x01, 0x5D, 0x82};
  readBytes();
  RS485.write(response, sizeof(response));
  
}

void NXprog485::getSlaveAddress(){
  uint8_t add = RS485.getSlaveAddress();
  dev->print("Current slave address: ");
  dev->println(add);
}

NXprog485::NXprog485(Stream *d) {
    dev = d;
}
