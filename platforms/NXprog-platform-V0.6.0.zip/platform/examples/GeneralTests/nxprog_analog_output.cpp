/*
 * Copyright (c) 2019, NOVUS Automation
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * 
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 * 
 * * Neither the name of Majenko Technologies nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <string.h>
#include "NOVUS/nx_config.h"
#include "NOVUS/nx_config_aux.h"
#include "NOVUS/nx_expert.h"
#include "nxprog_analog_output.h"

#define MAX_BUFF_SIZE 50
static const nx_aout_type_t aout_types[] PROGMEM = {_AOUT_0_20mA, _AOUT_4_20mA, _AOUT_0_10V};
static const nx_aout_range_t range_types[] PROGMEM = {_AOUT_RANGE_PERCENT, _AOUT_RANGE_VALUE};
static const nx_aout_poweron_state_t poweron_types[] PROGMEM = {PO_AOUT_DISABLED, PO_AOUT_CONFIGURED_VALUE, PO_AOUT_LAST_VALID_VALUE};
#define CONVERT_TO_TYPE(v,t,l)  ({\
                                    t result; \
                                    size_t numOfElements = sizeof(l)/sizeof(l[0]); \
                                    if ((v >= 0) && (v < numOfElements)) \
                                      result = pgm_read_byte(&l[v]); \
                                    else \
                                      result = pgm_read_byte(&l[0]); \
                                    result; \
                                })

#define IS_VALID_TYPE(v,l) ({\
                                bool result; \
                                size_t numOfElements = sizeof(l)/sizeof(l[0]); \
                                if ((v >= 0) && (v < numOfElements)) \
                                  result = true; \
                                else \
                                  result = false; \
                                result; \
                           })
                           

bool NXprogAnalogOutput::basicCheck(char *port_name, int *port) {
  bool is_input; 
  *port = translatePort(port_name, &is_input);

  if(*port < 0)
  {
    dev->println(F("Invalid port."));
    return false;
  }

  bool result;
  if(is_input)
  {
    dev->println(F("Not an output port."));
    return false;
  }
  return true;
}

void NXprogAnalogOutput::setState(char *port_name, bool state){
  int port;
  if(basicCheck(port_name, &port))
  {
    if(NovusExpertAOut.setState(port, state))
      dev->println(F("Ok."));
    else
      dev->println(F("FAILED!"));
  }
}

void NXprogAnalogOutput::setPowerOnValue(char *port_name, int value){
  int port;
  if(basicCheck(port_name, &port))
  {
    if (NovusExpertAOut.setPowerOnValue(port, value))
      dev->println(F("Ok."));
    else
      dev->println(F("FAILED!"));
  }
}

void NXprogAnalogOutput::setPowerOnState(char *port_name, int value){
  int port;
  if(basicCheck(port_name, &port))
  {
    if(!IS_VALID_TYPE(value,poweron_types))
    {
      dev->println(F("Invalid analog output power on state."));
      return;
    }
    nx_aout_poweron_state_t aout_ponstate = CONVERT_TO_TYPE(value,nx_aout_poweron_state_t,poweron_types);
    
    if (NovusExpertAOut.setPowerOnState(port, aout_ponstate))
      dev->println(F("Ok."));
    else
      dev->println(F("FAILED!"));
  }
}


void NXprogAnalogOutput::setOutputMode(char *port_name, int type, int range, int po_state, uint16_t po_value, uint16_t safe_value){
  int port;
  if(basicCheck(port_name, &port))
  {
    if(!IS_VALID_TYPE(type,aout_types))
    {
      dev->println(F("Invalid output type."));
      return;
    }
    nx_aout_type_t aout_type = CONVERT_TO_TYPE(type,nx_aout_type_t,aout_types);

    if(!IS_VALID_TYPE(range,range_types))
    {
      dev->println(F("Invalid output range."));
      return;
    }
    nx_aout_range_t aout_range = CONVERT_TO_TYPE(range,nx_aout_range_t,range_types);
    
    if(!IS_VALID_TYPE(po_state,poweron_types))
    {
      dev->println(F("Invalid analog output power on state."));
      return;
    }
    nx_aout_poweron_state_t aout_ponstate = CONVERT_TO_TYPE(po_state,nx_aout_poweron_state_t,poweron_types);

    if (NovusExpertAOut.setMode(port, aout_type, aout_range, aout_ponstate, po_value, safe_value))
      dev->println(F("Ok."));
    else
      dev->println(F("FAILED!"));
  }
}

void NXprogAnalogOutput::setSafeValue(char *port_name, int value){
  int port;
  if(basicCheck(port_name, &port))
  {
    if (NovusExpertAOut.setSafeValue(port, value))
      dev->println(F("Ok."));
    else
      dev->println(F("FAILED!"));
  }
}
