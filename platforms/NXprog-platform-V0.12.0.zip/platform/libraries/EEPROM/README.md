# NXprog onboard EEPROM ibrary
Arduino Library for NXprog onboard [Microchip 24LC256 256K I2C CMOS Serial EEPROM](http://ww1.microchip.com/downloads/en/devicedoc/21203m.pdf)

**Features:**
 - Acknowledge pooling instead of delays.
 - All hardware features implemented in the library.
 - Buffer writing with wait for writing cycle.
 
## Reference
Forked from [Gonçalo Passos wiki](https://github.com/gngz/24LC256-Arduino-Library/wiki).

### Macros
Two macros are defined:
- WRITE_SUCESS - Write sucess code.
- WRITE_ERROR - Write error code.

### E24LC256(void)
**Type**: Constructor
**Parameters**: void. Address not required since it is an onboard device.
Initialize the Object.

### bool detect()
**Type**: boolean
**Parameters**: void
Returns true, if 24LC256 chip is detectable on the i2c bus.

### int8_t writeByte(int address, byte data)
**Type**: 8-bit integer
**Parameters**: int address - Address of memory cell, byte data - Information to write into the memory
Writes a byte into eeprom cell address.
Returns WRITE_SUCESS or WRITE_ERROR.

### int8_t updateByte(int address, byte data)
**Type**: 8-bit integer
**Parameters**: int address - Address of memory cell, byte data - Information to write into the memory
Update a byte in eeprom cell address. Write operation is performed when stored value is different.
Returns WRITE_SUCESS or WRITE_ERROR.

### int8_t writePage(int address,int size, byte *buffer);
**Type**: 8-bit integer
**Parameters**: int address - Page address, byte buffer - Pointer to information to write into the memory, int size - buffer lenght
Writes up to 64 byte into eeprom page addres.
Returns WRITE_SUCESS or WRITE_ERROR.

### byte readByte(int address);
**Type**: 8-bit integer
**Parameters**: int address - Address of memory cell
Reads a single byte from eeprom cell address.
Returns byte read.

### int readPage(int address,int size, byte *buffer);
**Type**: 8-bit integer
**Parameters**: int address - Page address, byte buffer - Information read from memory
Reads 64 byte from eeprom page addres.
Returns WRITE_SUCESS or WRITE_ERROR.

### int length()
**Type**: integer
**Parameters**: void
Returns EEPROM storage capacity.

License: BSD 2-Clause License
