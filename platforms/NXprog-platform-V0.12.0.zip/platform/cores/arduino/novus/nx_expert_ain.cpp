/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/* 
 *
 * NOVUS EXPERT FUNCTIONS FOR MIXIO. 
 *
 */


#include "Arduino.h"
#include "nx_expert_ain.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_registers.h"

#define DECIMAL 100 //1 for 1, 10 for 2, 100 for 3....
#define REGISTER_READ_ERROR 0xFF



#define WRITE_AI_SINGLE_REGISTER(p,r,v)     ({ \
                                                bool result = false; \
                                                if(isAInPinNXprog(p)) \
                                                { \
	                                                uint8_t idx = PIN_TO_PORT_INDEX(p); \
                                                    NovusConfig.ainCFG[idx].read_ok = false; \
                                            	    IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::r)+(50*(idx))), 1, &v); \
                                                    if(IndoorComm.res.error == 0)\
                                                    { \
                                                        NovusConfig.ainCFG[idx].read_ok = true; \
                                                        result = true; \
                                                    } \
                                                } \
                                                result;\
                                            })



bool ExpertClassAnalogInput::enFilter(const uint8_t pin, int time)
{
    bool return_value = false;
    if(isAInPinNXprog(pin))
    {
        if((time >= 0) && (time <= 1200))
        {
            uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
            uint16_t config = time;
            IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::AI_FILTER+(50*(idx_port))),1,&config); 
            if(IndoorComm.res.error == 0)
            {
                NovusConfig.applyConfig();
                return_value = true;
            }
        }
    }
    return return_value;
}

bool ExpertClassAnalogInput::setUnit(const uint8_t pin, nx_ain_temp_unit_t unit)
{
    bool return_value = false;
    if(isAInPinNXprog(pin))
    {
	    uint16_t config = (unit == _CELSIUS) ? 0 : 1;
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.ainCFG[idx_port].read_ok = false; 

	    IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::AI_UNIT+(50*(idx_port))),1,&config); 
        if(IndoorComm.res.error == 0)
        {
	        NovusConfig.applyConfig();
        	NovusConfig.ainCFG[idx_port].unit = unit;
            NovusConfig.ainCFG[idx_port].read_ok = true; 
            return_value = true;
        }
    }
    return return_value;
}

bool ExpertClassAnalogInput::setRange(const uint8_t pin, int32_t low, int32_t high)
{
	/* Enables scale for linear input (AnInput Mode >= NTC)
	   High: High scale
	   Low: Low scale
	*/
    bool return_value = false;
    if(isAInPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        if(NovusConfig.ainCFG[idx_port].type >= NTC)
        {
            uint16_t config[4] = {0};

            config[0] = (low & 0xFFFF); //Low scale low byte
            config[1] = low>>16; //low scale high byte
            config[2] = (high & 0xFFFF); //high scale Low byte
            config[3] = high>>16; //High scale High Byte

            IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::AI_LOWSCALE_LO+(50*(idx_port))), 4, config); //Send low scale + high scale
            if(IndoorComm.res.error == 0)
            {
                NovusConfig.ainCFG[idx_port].scale_bottom = low; 
                NovusConfig.ainCFG[idx_port].scale_top = high;
                return_value = true;
            }
        }

    }
    return return_value;
}

bool ExpertClassAnalogInput::setMode(const uint8_t pin, nx_ain_sensor_t sensor, nx_ain_temp_unit_t temp, int32_t safeValue) 
{
	/* Configure a pin (channel) as analog Input
       Sensor: ThermoCouple, PT, 0-10V, 0-20mA, etc. See documentation
	   Temp: _CELSIUS (0) OR _FAHRENHEIT (1)
	   safeState: Value if error detected
	*/
    if(isAInPinNXprog(pin) == false)
        return false;

    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

	uint16_t config[2]={0};
	
    NovusConfig.ainCFG[idx_port].read_ok = false; 
    
	config[0] = 1; // Enable 
	IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)(NXprogRegisters::AI_ENABLE+(50*(idx_port))), 1, config); //enable port
    IndoorComm.debugError();
    if(IndoorComm.res.error != 0)
    {
        return false;
    }

	NovusConfig.ainCFG[idx_port].enabled = true;
    memset(config, 0, sizeof(config));
	config[0] = (uint16_t)sensor; // Type of input
	config[1] = temp; //temperature unit
	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)((NXprogRegisters::AI_TYPE)+(50*(idx_port))), 2, config); //Send Sensor type and temperature unit
    IndoorComm.debugError();
	NovusConfig.ainCFG[idx_port].type = sensor;
	NovusConfig.ainCFG[idx_port].unit = temp;
    if(IndoorComm.res.error != 0)
        return false;
	
    memset(config, 0, sizeof(config));
	config[0] = (safeValue & 0xFFFF); //Safe value Low word 
	config[1] = safeValue >> 16;; //Safe value High word
	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)((NXprogRegisters::AI_SAFE_VALUE_LO)+(50*(idx_port))), 2, config); //Send Safe Value
    IndoorComm.debugError();
    if(IndoorComm.res.error != 0)
    {
        return false;
    }

    bool requires_setrange = false;
	switch (sensor)
	{   //For linear inputs it's needed to set a scale value.	
		case _0_60mV: //0-60mV
        {
            uint32_t top = ((uint32_t)600*DECIMAL);
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = top;
            requires_setrange = true;
			break;
        }
		case _0_5V: //0-5V
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = 50*DECIMAL;
            requires_setrange = true;
			break;
		case _0_10V: //0-10V
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = 100*DECIMAL;
            requires_setrange = true;
			break;
		case _0_20mA: //0-20mA
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = 200*DECIMAL;
            requires_setrange = true;
			break;			
		case _4_20mA: //4-20mA
            NovusConfig.ainCFG[idx_port].scale_bottom = 40; 
            NovusConfig.ainCFG[idx_port].scale_top = 2000;
            requires_setrange = true;
			break;
		default:
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = 0;
            requires_setrange = false;
			break;
	}

    if(requires_setrange)
        NovusConfig.ainCFG[idx_port].read_ok = ExpertClassAnalogInput::setRange(pin, NovusConfig.ainCFG[idx_port].scale_bottom, NovusConfig.ainCFG[idx_port].scale_top);
    else
        NovusConfig.ainCFG[idx_port].read_ok = true; 

    if(NovusConfig.ainCFG[idx_port].read_ok)
  	    NovusConfig.applyConfig();

    return NovusConfig.ainCFG[idx_port].read_ok;
}

bool ExpertClassAnalogInput::setModeLinear(const uint8_t pin, nx_ain_sensor_t sensor, int32_t safeState) 
{
    if(sensor > NTC)
        return ExpertClassAnalogInput::setMode(pin, sensor, _CELSIUS, safeState);
    
    return false;
}

bool ExpertClassAnalogInput::setState(const uint8_t pin, bool enable)
{
	uint16_t config= (enable ? 1: 0);

    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

    if(WRITE_AI_SINGLE_REGISTER(pin,AI_ENABLE,config))
    {
        NovusConfig.ainCFG[idx_port].enabled = 1; 
  	    NovusConfig.applyConfig();
        return true;
    }
    else
        return false;
}

bool ExpertClassAnalogInput::setSamplingRate(const uint8_t pin, nx_ain_sampling_rate_t rate) 
{
    bool return_value = false;

    if(isAInPinNXprog(pin))
    {
        uint16_t config= (rate == 0 ? _1_per_sec: _10_per_sec);
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

        NovusConfig.ainCFG[idx_port].read_ok = false; 
        NovusConfig.ainCFG[idx_port].sampling_rate = rate;
        
        IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::AI_SAMPLING)+(50*(idx_port))), 1, &config); //enable port
        IndoorComm.debugError();

        if(IndoorComm.res.error == 0)
        {
            NovusConfig.ainCFG[idx_port].read_ok = true; 
  	        NovusConfig.applyConfig();
            return_value = true;
        }
    }
    return return_value;
}

bool ExpertClassAnalogInput::setSafeValue(const uint8_t pin, int32_t safeValue)
{
    bool return_value = false;

    if(isAInPinNXprog(pin))
    {
    	uint16_t config[2]={0};
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

    	config[0] = (safeValue & 0xFFFF); //Safe value Low word 
	    config[1] = safeValue >> 16;; //Safe value High word
	    IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)((NXprogRegisters::AI_SAFE_VALUE_LO)+(50*(idx_port))), 2, config); //Send Safe Value
        if(IndoorComm.res.error == 0)
        {
  	        NovusConfig.applyConfig();
            return_value = true;
        }
    }
    return return_value;
}

ExpertClassAnalogInput NovusExpertAIn;