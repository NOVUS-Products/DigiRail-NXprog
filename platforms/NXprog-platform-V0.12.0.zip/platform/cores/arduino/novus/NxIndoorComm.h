/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
 *
 * 	| End |  Fun | Num | Pin | Sin | D00 | D01 | D02 | D03 | D04 | D05 | D06 | D07 | D08 | Crc | Crc |  --> Message packet
 * 	| End |  Fun | Num | Pin | D00 | D01 | D02 | D03 | D04 | D05 | D06 | D07 | D08 | D09 | Crc | Crc |  --> Configuration packet
 *
 *	xxxx.xxxx.xxxx.xxxx --> 16 Bytes
 *  ||||.||||.||||.||||
 *  ||||.||||.||||.|||V
 *  ||||.||||.||||.||V--- CRC low
 *  ||||.|VVV.VVVV.VV---- CRC high
 *  ||||.V---.----.------ Data
 *  |||V.----.----.------ Data ( SIGNAL )
 *  ||V-.----.----.------ Data ( PIN )
 *  |V--.----.----.------ Data ( # of bytes )
 *  V---.----.----.------ Function
 *  ----.----.----.------ Address
 * 
 *	-----------------------------
 *	-- Standard Payload Modbus --
 *	-----------------------------
 *
 * | Address | Function | High Register | Low Register | High Value | Low Value | Low CRC | Low CRC |
 * 		--> return ( ECHO )
 * | Address | Function | High Register | Low Register | High Quantity Registers | Low Quantity Registers | Low CRC | Low CRC |
 *		--> return( | Address | Function | Bytes Readen | High Value | Low Value | ... | Low CRC | Low CRC |
 *
 * Writting in a book and reading a book: Registers allways sequentially.
 *
 *	----------------------
 *	-- Modbus Functions --
 *	----------------------
 * 
 *	 3- Read single/block register
 * 	 6- Write single register
 * 	16- Write block of registers
 *
 *
 */
#pragma once

#include <stdint.h>

#ifndef NXINDOORCOMM_H
#define NXINDOORCOMM_H

/* Changing code */

/* Constants */
// Communication
#define BaudRate        128000
// #define MAX_INDOOR_PDU  255
	
typedef enum _modbus_function {
	FUNC_READSINGLE = 3,
	FUNC_WRITESINGLE = 6,		
	FUNC_WRITEMULTIPLE = 16,
	SPECIAL_FUNCTION = 43
} function_t;

typedef enum _modbus_special_function {
	RECEIVE_MODBUS = 0x32,
	RESPONSE_MODBUS = 0x33,		
	SET_MODBUS_ADDRESS = 0x34
} special_function_t;

/* ----------------------------------------------------------------------------------------------------
*	This class is private to core, the communication with baseboard is established here. DO NOT MODIFY
* ----------------------------------------------------------------------------------------------------	*/ 
class IndoorCommClass
{
  private:
	bool checkCRC( uint8_t *pBufferSerial, uint8_t u8Index );
  
  public:
	struct response{
		int error; // Return 0 if 'OK' and other values according to errors.txt 
		uint16_t value; // Return the value read in the input pins.
	};
	
	response res;
  	
	void send(function_t function, uint16_t reg, uint16_t quantity, uint16_t* value);
	void send_special_funcion(special_function_t function, uint16_t quantity, uint16_t* value);
	void debugError();
};

extern IndoorCommClass IndoorComm;


#endif