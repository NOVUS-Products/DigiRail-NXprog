/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include "Arduino.h"
#include "nx_expert.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_registers.h"

#define DECIMAL 100 //1 for 1, 10 for 2, 100 for 3....
#define REGISTER_READ_ERROR 0xFF

#define isValid_DOutPinMode(mode,pTime,pPeriod,num) (((mode == _DOUT_LOGICAL_STATE) && (num == 0)) ||\
                                                ((mode == _DOUT_SINGLE_PULSE) && (num == 1)) ||\
	                                            ((mode == _DOUT_PULSE_TRAIN) && (num > 1)) ||\
                                                ((mode == _DOUT_PWM_MODE) && (pTime > 0) && (pPeriod > 0)))


bool ExpertClassDigitalOut::setMode(uint8_t pin, 
                                                nx_dout_actuation_mode_t opMode, 
                                                uint16_t pulseTime, 
                                                uint16_t pulsePeriod, 
                                                uint16_t nPulse,
                                                nx_dout_poweron_state_t po_state,
                                                bool po_value,
                                                bool safe_state)
{
    bool return_value = false;

    if(isDOutPinNXprog(pin))
    {
        if(isValid_DOutPinMode(opMode,pulseTime,pulsePeriod,nPulse))
        {
            uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

            NovusConfig.doutCFG[idx_port].read_ok = ExpertClassDigitalOut::setActuationMode(pin, opMode, pulseTime, pulsePeriod, nPulse);

            if(NovusConfig.doutCFG[idx_port].read_ok)
            {
                NovusConfig.doutCFG[idx_port].read_ok = false;
    
    	        uint16_t config[3] = {0};
                config[0] = po_state;
                config[1] = po_value ? 1 : 0;
                config[2] = safe_state ? 1 : 0;
    	        IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)((NXprogRegisters::DO_POWER_ON_STATE)+(50*(idx_port))), 3, config); //pulse time, period and number
                if(IndoorComm.res.error == INDOOR_OK)
                    NovusConfig.doutCFG[idx_port].read_ok = ExpertClassDigitalOut::setState(pin, true);
                return_value = NovusConfig.doutCFG[idx_port].read_ok;
            }
        }
    }
    return return_value;
}

bool ExpertClassDigitalOut::setActuationMode(uint8_t pin, nx_dout_actuation_mode_t opMode, 
                                                uint16_t pulseTime, 
                                                uint16_t pulsePeriod, 
                                                uint16_t nPulse)
{
	/* Config digital output as pulse train 
	   pulseTime: High Time(x*100ms)
	   pulsePeriod: Total wave time (x*100ms)
	   nPulse: Number of pulses (max 16 bits)
	*/
    bool return_value = false;
    if(isDOutPinNXprog(pin))
    {
    	uint16_t config[5] = {0};
        if(isValid_DOutPinMode(opMode,pulseTime,pulsePeriod,nPulse))
        {
            uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

            config[1] = opMode;
            NovusConfig.doutCFG[idx_port].read_ok = false; 

            config[0] = 1; //Enable
            
            config[2] = pulseTime;
            config[3] = pulsePeriod;
            config[4] = nPulse;
            
            IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::DO_ENABLE)+(50*(idx_port))), 1, &config[0]); //enable or disable port
            if(IndoorComm.res.error == INDOOR_OK)
            {
                NovusConfig.doutCFG[idx_port].enabled = 1; 

                IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::DO_FUNCTION)+(50*(idx_port))),1, &config[1]); //function as single or pulse train
                NovusConfig.doutCFG[idx_port].mode = opMode; 
                if(IndoorComm.res.error == INDOOR_OK)
                {
                    IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)((NXprogRegisters::DO_PULSE_TIME)+(50*(idx_port))), 3, &config[2]); //pulse time, period and number
                    NovusConfig.doutCFG[idx_port].pulse_period = pulsePeriod; 
                    NovusConfig.doutCFG[idx_port].pulse_time = pulseTime; 
                    NovusConfig.doutCFG[idx_port].num_pulses = nPulse;

                    if(IndoorComm.res.error == INDOOR_OK)
                        NovusConfig.doutCFG[idx_port].read_ok = ExpertClassDigitalOut::setState(pin, true);
                }
            }
            return_value = NovusConfig.doutCFG[idx_port].read_ok; 

        }
    }
    return return_value;
}


bool ExpertClassDigitalOut::setState(const uint8_t pin, bool enable)
{
	uint16_t config= (enable ? 1: 0);
    bool return_value = false;

    if(isDOutPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DO_ENABLE+(50*(idx_port))),1,&config); 
        if(IndoorComm.res.error == INDOOR_OK)
        {
            NovusConfig.applyConfig();
            NovusConfig.doutCFG[idx_port].enabled = enable; 
  	        return_value = true;
        }
    }
    return return_value;
}

bool ExpertClassDigitalOut::setSafeState(const uint8_t pin, bool safe_state)
{
	uint16_t config= (safe_state ? 1: 0);
    bool return_value = false;

    if(isDOutPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.doutCFG[idx_port].read_ok = false;

        IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DO_SAFE_STATE+(50*(idx_port))),1,&config); 
        if(IndoorComm.res.error == INDOOR_OK)
        {
            NovusConfig.doutCFG[idx_port].safe_state = safe_state; 
            NovusConfig.doutCFG[idx_port].read_ok = ExpertClassDigitalOut::setState(pin, true);
        }
        return_value = NovusConfig.doutCFG[idx_port].read_ok; 
    }
    return return_value;
}

bool ExpertClassDigitalOut::setPowerOnState(const uint8_t pin, nx_dout_poweron_state_t po_state)
{
    bool return_value = false;

    if(isDOutPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.doutCFG[idx_port].read_ok = false;

        uint16_t config = po_state;
        IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DO_POWER_ON_STATE+(50*(idx_port))),1,&config); 
        if(IndoorComm.res.error == INDOOR_OK)
        {
            NovusConfig.doutCFG[idx_port].poweron_state = po_state; 
            NovusConfig.doutCFG[idx_port].read_ok = ExpertClassDigitalOut::setState(pin, true);
        }
        return_value = NovusConfig.doutCFG[idx_port].read_ok;
    }
    return return_value;

}

bool ExpertClassDigitalOut::enInstant(const uint8_t pin, nx_dout_poweron_state_t po_state, bool safe_state)
{
	/* Configure channel as digital output instant value.
	   powerON: Power on value
	   safeState: safe state value
	*/

    bool return_value = false;

    if(isDOutPinNXprog(pin))
    {
    	uint16_t config[4]={0};
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

	    config[0] = _DOUT_LOGICAL_STATE; //function as instant value
        config[1] = po_state; //pON state is off
	    if(po_state == _PO_DOUT_OFF)
	    {
		    config[2] = 0; //pON state is off
	    }
	    else
	    {
    		config[2] = 1;//pON state is a configured value	
    	}
    	config[3] = (safe_state ? 1 : 0); //Safe value

        NovusConfig.doutCFG[idx_port].read_ok = false;
        IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DO_FUNCTION+(50*(idx_port))),1,&config[0]); 
        if(IndoorComm.res.error == INDOOR_OK)
        {
            IndoorComm.send(FUNC_WRITEMULTIPLE,(uint16_t)(NXprogRegisters::DO_POWER_ON_STATE+(50*(idx_port))),3,&config[1]); 
            if(IndoorComm.res.error == INDOOR_OK)
            {
                NovusConfig.doutCFG[idx_port].mode = _DOUT_LOGICAL_STATE; 
                NovusConfig.doutCFG[idx_port].safe_state = safe_state; 
                NovusConfig.doutCFG[idx_port].poweron_state = po_state;
                NovusConfig.doutCFG[idx_port].read_ok = ExpertClassDigitalOut::setState(pin, true);
            }
        }
        return_value = NovusConfig.doutCFG[idx_port].read_ok;
    }
    return return_value;
}	


ExpertClassDigitalOut NovusExpertDOut;