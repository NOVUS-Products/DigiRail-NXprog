/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "Arduino.h"
#include "nx_expert_din.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_registers.h"


bool ExpertClassDigitalInput::setMode(const uint8_t pin, nx_din_function_t  function, nx_din_type_t  connection_type, uint16_t  debounce, uint32_t preset)
{
    bool return_value = false;
    if(isDInPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.dinCFG[idx_port].read_ok = false;
        uint16_t config[3] = {0};	

        config[0] = (uint16_t) function;
        config[1] = (uint16_t) connection_type;
        config[2] = debounce;
        IndoorComm.send(FUNC_WRITEMULTIPLE,(uint16_t)(NXprogRegisters::DI_FUNCTION+(50*(idx_port))),3,config); 
        if(IndoorComm.res.error == 0)
        {
            config[0] = (preset & 0xFFFF); //Preset low word
            config[1] = preset>>16; //low scale high byte
            IndoorComm.send(FUNC_WRITEMULTIPLE,(uint16_t)(NXprogRegisters::DI_PRESET+(50*(idx_port))),2,config); 
            if(IndoorComm.res.error == 0)
            {
                NovusConfig.dinCFG[idx_port].function = function;
                NovusConfig.dinCFG[idx_port].connection_type = connection_type;
                NovusConfig.dinCFG[idx_port].debounce = debounce;
                NovusConfig.dinCFG[idx_port].enabled = true;
                NovusConfig.dinCFG[idx_port].read_ok = ExpertClassDigitalInput::setState(pin, true);
            }
        }
        return_value = NovusConfig.dinCFG[idx_port].read_ok;
    }
    return return_value;
}


bool ExpertClassDigitalInput::setFunctionMode(const uint8_t pin, nx_din_function_t function)
{
    bool return_value = false;
    if(isDInPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.dinCFG[idx_port].read_ok = false;
        uint16_t config = (uint16_t) function;
        IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DI_FUNCTION+(50*(idx_port))),1,&config); 
        if(IndoorComm.res.error == 0)
        {
            NovusConfig.dinCFG[idx_port].function = function; 
            NovusConfig.dinCFG[idx_port].read_ok = ExpertClassDigitalInput::setState(pin, true);
        }
        return_value = NovusConfig.dinCFG[idx_port].read_ok;
    }
    return return_value;
}

bool ExpertClassDigitalInput::setConnectionType(const uint8_t pin, nx_din_type_t connection_type)
{
    bool return_value = false;
    if(isDInPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.dinCFG[idx_port].read_ok = false;
        uint16_t config = (uint16_t) connection_type;
        IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DI_TYPE+(50*(idx_port))),1,&config); 
        if(IndoorComm.res.error == 0)
        {
            NovusConfig.dinCFG[idx_port].connection_type = connection_type;
            NovusConfig.dinCFG[idx_port].read_ok = ExpertClassDigitalInput::setState(pin, true);
        }
        return_value = NovusConfig.dinCFG[idx_port].read_ok;
    }
    return return_value;
}

bool ExpertClassDigitalInput::setDebounce(const uint8_t pin, uint16_t debounce)
{
    bool return_value = false;
    if(isDInPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.dinCFG[idx_port].read_ok = false;
        IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DI_DEBOUNCE+(50*(idx_port))),1,&debounce); 
        if(IndoorComm.res.error == 0)
        {
	        NovusConfig.dinCFG[idx_port].debounce = debounce;
            NovusConfig.dinCFG[idx_port].read_ok = ExpertClassDigitalInput::setState(pin, true);
        }
        return_value = NovusConfig.dinCFG[idx_port].read_ok;
    }
    return return_value;
}

bool ExpertClassDigitalInput::setState(const uint8_t pin, bool enable)
{
	uint16_t config = (enable ? 1: 0);
    bool return_value = false;
    if(isDInPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.dinCFG[idx_port].read_ok = false;
        IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DI_ENABLE+(50*(idx_port))),1,&config); 
        if(IndoorComm.res.error == 0)
        {
            NovusConfig.dinCFG[idx_port].enabled = enable;
            NovusConfig.applyConfig();
            return_value = true;
        }
    }
    return return_value;

}


uint32_t ExpertClassDigitalInput::readCounter(const uint8_t pin)
{
    uint32_t return_value = NX_INVALID_COUNTER;
    if(isDInPinNXprog(pin))
    {
        uint16_t value_16;
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        IndoorComm.send(FUNC_READSINGLE, (uint16_t)(NXprogRegisters::DI_COUNTER_LO + (2*idx_port)), 1, &value_16);
        if(IndoorComm.res.error == 0)
        {
            return_value = IndoorComm.res.value;
            IndoorComm.send(FUNC_READSINGLE, (uint16_t)(NXprogRegisters::DI_COUNTER_HI + (2*idx_port)), 1, &value_16);
            if(IndoorComm.res.error == 0)
            {
                return_value = return_value | (((uint32_t)IndoorComm.res.value) << 16);
            }
            else
                return_value = NX_INVALID_COUNTER;
        }

    }
    return return_value;
}

uint32_t ExpertClassDigitalInput::readTimer(const uint8_t pin, bool onoff)
{
    uint32_t return_value = NX_INVALID_TIME;
    if(isDInPinNXprog(pin))
    {
        uint16_t value_16;
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        uint16_t address = (uint16_t)((onoff == true) ? NXprogRegisters::DI_TIMEON_LO : NXprogRegisters::DI_TIMEOFF_LO);
        IndoorComm.send(FUNC_READSINGLE, address + (2*idx_port), 1, &value_16);
        if(IndoorComm.res.error == 0)
        {
            return_value = IndoorComm.res.value;
            address =  (uint16_t)((onoff == true) ? NXprogRegisters::DI_TIMEON_HI : NXprogRegisters::DI_TIMEOFF_HI);
            IndoorComm.send(FUNC_READSINGLE, address + (2*idx_port), 1, &value_16);
            if(IndoorComm.res.error == 0)
            {
                return_value = return_value | (((uint32_t)IndoorComm.res.value) << 16);
            }
            else
                return_value = NX_INVALID_TIME;
        }

    }
    return return_value;
}

bool ExpertClassDigitalInput::setPreset(const uint8_t pin, uint32_t preset)
{
    bool return_value = false;
    if(isDInPinNXprog(pin))
    {
        uint16_t config[2];
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.dinCFG[idx_port].read_ok = false;
        config[0] = (preset & 0xFFFF);
        config[1] = preset>>16; 
        IndoorComm.send(FUNC_WRITEMULTIPLE,(uint16_t)(NXprogRegisters::DI_PRESET+(50*(idx_port))),2,config); 
        if(IndoorComm.res.error == 0)
            NovusConfig.dinCFG[idx_port].read_ok = true;
        return_value = NovusConfig.dinCFG[idx_port].read_ok;
    }
    return return_value;

}


ExpertClassDigitalInput NovusExpertDIn;