/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <Arduino.h>
#include "NXprog.h"
#include "nx_wiring_shift.h"

// --------------------------------- NXprog extensions ---------------------------------
uint8_t nx_shiftIn(__attribute__((unused)) uint8_t dataPin, __attribute__((unused)) uint8_t clockPin, __attribute__((unused)) BitOrder bitOrder) 
{
	/* Function not supported in NXprog. Please, use NovusIOExpert library */
	WARNING("shiftIn not implemented for NXprog port");
	return 0;
}

void nx_shiftOut(__attribute__((unused)) uint8_t dataPin, __attribute__((unused)) uint8_t clockPin, __attribute__((unused)) BitOrder bitOrder, __attribute__((unused)) uint8_t val)
{
	/* Function not supported in NXprog. Please, use NovusIOExpert library */
	WARNING("shiftOut not implemented for NXprog port");
}
