/*
  Copyright (c) 2019 NOVUS Automation.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/* 
 *
 * NOVUS EXPERT FUNCTIONS FOR MIXIO. 
 *
 */


#include "Arduino.h"
#include "nx_expert.h"
#include "NxIndoorComm.h"
#include "nx_config.h"
#include "nx_registers.h"

#define DECIMAL 100 //1 for 1, 10 for 2, 100 for 3....
#define REGISTER_READ_ERROR 0xFF

#define isValid_DOutPinMode(mode,pTime,pPeriod,num) (((mode == DOUT_LOGICAL_STATE) && (num == 0)) ||\
                                                ((mode == DOUT_SINGLE_PULSE) && (num == 1)) ||\
	                                            ((mode == DOUT_PULSE_TRAIN) && (num > 1)) ||\
                                                ((mode == DOUT_PWM_MODE) && (pTime > 0) && (pPeriod > 0)))


#define WRITE_AO_SINGLE_REGISTER(p,r,v)     ({ \
                                                bool result = false; \
                                                if(isAOutPinNXprog(p)) \
                                                { \
	                                                uint8_t idx = PIN_TO_PORT_INDEX(p); \
                                                    NovusConfig.doutCFG[idx].read_ok = false; \
                                            	    IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::r)+(50*idx)), 1, &v); \
                                                    if(IndoorComm.res.error == 0) \
                                                    { \
                                                        NovusConfig.doutCFG[idx].read_ok = true; \
                                                        result = true; \
                                                    } \
                                                } \
                                                result; \
                                            })

#define WRITE_AI_SINGLE_REGISTER(p,r,v)     ({ \
                                                bool result = false; \
                                                if(isAInPinNXprog(p)) \
                                                { \
	                                                uint8_t idx = PIN_TO_PORT_INDEX(p); \
                                                    NovusConfig.ainCFG[idx].read_ok = false; \
                                            	    IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::r)+(50*(idx))), 1, &v); \
                                                    if(IndoorComm.res.error == 0)\
                                                    { \
                                                        NovusConfig.ainCFG[idx].read_ok = true; \
                                                        result = true; \
                                                    } \
                                                } \
                                                result;\
                                            })

#define WRITE_SINGLE_REGISTER(r,v)          ({ \
                                                uint16_t value = v; \
                                                bool result = true; \
                                            	IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)(NXprogRegisters::r), 1, &value); \
                                                if(IndoorComm.res.error != 0)\
                                                    result = false;\
                                                result; \
                                            })

#define READ_SINGLE_REGISTER(r)             ({ \
                                                uint16_t value =  REGISTER_READ_ERROR; \
                                            	IndoorComm.send(FUNC_READSINGLE, (uint16_t)(NXprogRegisters::r), 1, &value); \
                                                if(IndoorComm.res.error == 0)\
                                                    value = IndoorComm.res.value;\
                                                value; \
                                            })


/* TODO:
 * Por sugestão de Marcus Bergel, as seguintes funcionalidades seriam interessantes
 * de serem implementadas nesta biblioteca:
 *
 * TODO: 1. Possibilidade de definir a janela de aquisição e, consequentemente, o período de amostragem;
 * TODO: 2. Possibilidade de definir a frequência da rede elétrica (necessário para janelas de aquisição não múltiplas de 100ms);
 * TODO: 3. Configuração de 3 níveis de filtro de moda para as entradas analógicas (solução para sistemas ruidosos);
 * TODO: 4. Configuração de uma saída PWM nativa à saída digital (muito útil para utilização da saída digital em um loop de controle PID); 
 *
 *
 * Caso forem implemetadas, necessário verificar seu funcionamento com o RENESAS.
 *
 */

bool ExpertClass::setMainsFrequency(nx_mains_freq_t freq)
{	
	/* Modifies the register that indicates the working frequency of the mains (50Hz or 60Hz). */
	uint16_t config = (freq == _50Hz ? 1 : 2);
   
    if(!WRITE_SINGLE_REGISTER(MAINS_FREQ,config))
        return false;
  	NovusConfig.applyConfig();
    return true;
}

bool ExpertClass::getMainsFrequency(nx_mains_freq_t *freq)
{	
    uint16_t result = READ_SINGLE_REGISTER(MAINS_FREQ);
    if(result == REGISTER_READ_ERROR)
        return false;
    *freq = (result == 1? _50Hz : _60Hz);
    return true;
}

bool ExpertClass::analogInput_enFilter(const uint8_t pin, int time)
{
    bool return_value = false;
    if(isAInPinNXprog(pin))
    {
        if((time >= 0) && (time <= 1200))
        {
            uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
            uint16_t config = time;
            IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::AI_FILTER+(50*(idx_port))),1,&config); 
            if(IndoorComm.res.error == 0)
            {
                NovusConfig.applyConfig();
                return_value = true;
            }
        }
    }
    return return_value;
}

bool ExpertClass::analogInput_setUnit(const uint8_t pin, nx_ain_temp_unit_t unit)
{
    bool return_value = false;
    if(isAInPinNXprog(pin))
    {
	    uint16_t config = (unit == CELSIUS) ? 0 : 1;
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.ainCFG[idx_port].read_ok = false; 

	    IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::AI_UNIT+(50*(idx_port))),1,&config); 
        if(IndoorComm.res.error == 0)
        {
	        NovusConfig.applyConfig();
        	NovusConfig.ainCFG[idx_port].unit = unit;
            NovusConfig.ainCFG[idx_port].read_ok = true; 
            return_value = true;
        }
    }
    return return_value;
}

bool ExpertClass::analogInput_setRange(const uint8_t pin, uint32_t low, uint32_t high)
{
	/* Enables scale for linear input (AnInput Mode >= NTC)
	   High: High scale
	   Low: Low scale
	*/
    bool return_value = false;
    if(isAInPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        if(NovusConfig.ainCFG[idx_port].type >= NTC)
        {
            uint16_t config[4] = {0};
            uint32_t int_high = high;
            uint32_t int_low = low;

            config[0] = (int_low & 0xFFFF); //Low scale low byte
            config[1] = int_low>>16; //low scale high byte
            config[2] = (int_high & 0xFFFF); //high scale Low byte
            config[3] = int_high>>16; //High scale High Byte

            IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::AI_LOWSCALE_LO+(50*(idx_port))), 4, config); //Send low scale + high scale
            if(IndoorComm.res.error == 0)
            {
                NovusConfig.ainCFG[idx_port].scale_bottom = low; 
                NovusConfig.ainCFG[idx_port].scale_top = high;
                return_value = true;
            }
        }

    }
    return return_value;
}

bool ExpertClass::analogInput_setMode(const uint8_t pin, nx_ain_sensor_t sensor, nx_ain_temp_unit_t temp, float safeState) 
{
	/* Configure a pin (channel) as analog Input
       Sensor: ThermoCouple, PT, 0-10V, 0-20mA, etc. See documentation
	   Temp: CELSIUS (0) OR FAHRENHEIT (1)
	   safeState: Value if error detected
	*/
    if(isAInPinNXprog(pin) == false)
        return false;

    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

	uint16_t config[2]={0};
	uint32_t safe = safeState;
	
    NovusConfig.ainCFG[idx_port].read_ok = false; 
    
	config[0] = 1; // Enable 
	IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)(NXprogRegisters::AI_ENABLE+(50*(idx_port))), 1, config); //enable port
    IndoorComm.debugError();
	NovusConfig.ainCFG[idx_port].enabled = true;
    if(IndoorComm.res.error != 0)

    memset(config, 0, sizeof(config));
	config[0] = (uint16_t)sensor; // Type of input
	config[1] = temp; //temperature unit
	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)((NXprogRegisters::AI_TYPE)+(50*(idx_port))), 2, config); //Send Sensor type and temperature unit
    IndoorComm.debugError();
	NovusConfig.ainCFG[idx_port].type = sensor;
	NovusConfig.ainCFG[idx_port].unit = temp;
    if(IndoorComm.res.error != 0)
        return false;
	
    memset(config, 0, sizeof(config));
	config[0] = (safe & 0xFFFF); //Safe value Low word 
	config[1] = safe>>16;; //Safe value High word
	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)((NXprogRegisters::AI_SAFE_VALUE_LO)+(50*(idx_port))), 2, config); //Send Safe Value
    IndoorComm.debugError();
    if(IndoorComm.res.error != 0)
        return false;
	
	switch (sensor)
	{   //For linear inputs it's needed to set a scale value.	
		case _0_60mV: //0-60mV
        {
            uint32_t top = ((uint32_t)600*DECIMAL);
			ExpertClass::analogInput_setRange(pin, 0, top);
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = top;
			break;
        }
		case _0_5V: //0-5V
			ExpertClass::analogInput_setRange(pin, 0, 50*DECIMAL);	
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = 50*DECIMAL;
			break;
		case _0_10V: //0-10V
			ExpertClass::analogInput_setRange(pin, 0, 100*DECIMAL);	
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = 100*DECIMAL;
			break;
		case _0_20mA: //0-20mA
			ExpertClass::analogInput_setRange(pin, 0, 200*DECIMAL);
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = 200*DECIMAL;
			break;			
		case _4_20mA: //4-20mA
			ExpertClass::analogInput_setRange(pin, 40, 2000);
            NovusConfig.ainCFG[idx_port].scale_bottom = 40; 
            NovusConfig.ainCFG[idx_port].scale_top = 2000;
			break;
		default:
			ExpertClass::analogInput_setRange(pin, 0, 0);
            NovusConfig.ainCFG[idx_port].scale_bottom = 0; 
            NovusConfig.ainCFG[idx_port].scale_top = 0;
			break;
	}
	
    if(IndoorComm.res.error == 0)
    {
        NovusConfig.ainCFG[idx_port].read_ok = true; 
        return true;
    }
    return false;
}

bool ExpertClass::analogInput_setState(const uint8_t pin, bool enable)
{
	uint16_t config= (enable ? 1: 0);

    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

    if(WRITE_AI_SINGLE_REGISTER(pin,AI_ENABLE,config))
    {
        NovusConfig.ainCFG[idx_port].enabled = 1; 
  	    NovusConfig.applyConfig();
        return true;
    }
    else
        return false;
}

bool ExpertClass::analogInput_setSamplingRate(const uint8_t pin, nx_ain_sampling_rate_t rate) 
{
    bool return_value = false;

    if(isAInPinNXprog(pin))
    {
        uint16_t config= (rate == 0 ? _1_per_sec: _10_per_sec);
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

        NovusConfig.ainCFG[idx_port].read_ok = false; 
        NovusConfig.ainCFG[idx_port].sampling_rate = rate;
        
        IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::AI_SAMPLING)+(50*(idx_port))), 1, &config); //enable port
        IndoorComm.debugError();

        if(IndoorComm.res.error == 0)
        {
            NovusConfig.ainCFG[idx_port].read_ok = true; 
            return_value = true;
        }
    }
    return return_value;
}

// TODO: certificar se RENESAS suporta PWM
void ExpertClass::digitalOutput_setMode(uint8_t pin, 
                                                nx_dout_actuation_mode_t opMode, 
                                                uint16_t pulseTime, 
                                                uint16_t pulsePeriod, 
                                                uint16_t nPulse,
                                                nx_dout_poweron_state_t po_state,
                                                bool po_value,
                                                bool safe_state)
{
    if(isDOutPinNXprog(pin) == false)
        return;

    if(!isValid_DOutPinMode(opMode,pulseTime,pulsePeriod,nPulse))
        return;

    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

    NovusConfig.doutCFG[idx_port].read_ok = false;

    ExpertClass::digitalOutput_enPulse(pin, opMode, pulseTime, pulsePeriod, nPulse);
    if(NovusConfig.doutCFG[idx_port].read_ok)
    {
        NovusConfig.doutCFG[idx_port].read_ok = false;
    
    	uint16_t config[3] = {0};
        config[0] = po_state;
        config[1] = po_value ? 1 : 0;
        config[2] = safe_state ? 1 : 0;
    	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)((NXprogRegisters::DO_POWER_ON_STATE)+(50*(idx_port))), 3, config); //pulse time, period and number
        if(IndoorComm.res.error == 0)
            NovusConfig.doutCFG[idx_port].read_ok = true;

    }
}

// TODO: certificar se RENESAS suporta PWM
void ExpertClass::digitalOutput_enPulse(uint8_t pin, nx_dout_actuation_mode_t opMode, 
                                                uint16_t pulseTime, 
                                                uint16_t pulsePeriod, 
                                                uint16_t nPulse)
{
	/* Config digital output as pulse train 
	   pulseTime: High Time(x*100ms)
	   pulsePeriod: Total wave time (x*100ms)
	   nPulse: Number of pulses (max 16 bits)
	*/
	uint16_t config[5] = {0};
	
    if(isDOutPinNXprog(pin) == false)
        return;


    if(isValid_DOutPinMode(opMode,pulseTime,pulsePeriod,nPulse))
        config[1] = opMode;
    else
        return;
    
    NovusConfig.doutCFG[pin-1].read_ok = false; 

	config[0] = 1; //Enable
	
	
	config[2] = pulseTime;
	config[3] = pulsePeriod;
	config[4] = nPulse;
	
	IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::DO_ENABLE)+(50*(pin-1))), 1, &config[0]); //enable or disable port
    if(IndoorComm.res.error != 0)
        return;
    NovusConfig.doutCFG[pin-1].enabled = 1; 

	IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)((NXprogRegisters::DO_FUNCTION)+(50*(pin-1))),1, &config[1]); //function as single or pulse train
    NovusConfig.doutCFG[pin-1].mode = opMode; 
    if(IndoorComm.res.error != 0)
        return;

	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)((NXprogRegisters::DO_PULSE_TIME)+(50*(pin-1))), 3, &config[2]); //pulse time, period and number
    NovusConfig.doutCFG[pin-1].pulse_period = pulsePeriod; 
    NovusConfig.doutCFG[pin-1].pulse_time = pulseTime; 
    NovusConfig.doutCFG[pin-1].num_pulses = nPulse;

    if(IndoorComm.res.error == 0)
        NovusConfig.doutCFG[pin-1].read_ok = true;

  	NovusConfig.applyConfig();

}

bool ExpertClass::analogOutput_setMode(const uint8_t pin, nx_aout_type_t type, nx_aout_range_t range, nx_aout_poweron_state_t poweronState, uint16_t poweronValue, uint16_t watchdogValue) 
{
    uint16_t config[5] = {0};	
    
    if(isAOutPinNXprog(pin) == false)
        return false;

    uint8_t idx_port = PIN_TO_PORT_INDEX(pin);

  
    NovusConfig.doutCFG[idx_port].read_ok = false; 

	config[0] = 1; //Enable


	IndoorComm.send(FUNC_WRITESINGLE, (uint16_t)(NXprogRegisters::AO_ENABLE+(50*idx_port)), 1, config); //enable or disable port
    if(IndoorComm.res.error != 0)
        return false;
    NovusConfig.aoutCFG[idx_port].enabled = 1; 

	config[0] = type;
	config[1] = range;
	config[2] = poweronState;
	config[3] = poweronValue;
	config[4] = watchdogValue;
	IndoorComm.send(FUNC_WRITEMULTIPLE, (uint16_t)(NXprogRegisters::AO_TYPE+(50*idx_port)), 5, config); //pulse time, period and number
    if(IndoorComm.res.error != 0)
        return false;
    NovusConfig.aoutCFG[idx_port].type= type; 
    NovusConfig.aoutCFG[idx_port].range = range; 
    NovusConfig.aoutCFG[idx_port].pon_state = poweronState; 
    NovusConfig.aoutCFG[idx_port].pon_value = poweronValue;
    NovusConfig.aoutCFG[idx_port].watchdog_value = watchdogValue;

    NovusConfig.doutCFG[idx_port].read_ok = true;

  	NovusConfig.applyConfig();

    return true;
}

bool ExpertClass::analogOutput_setState(const uint8_t pin, boolean enable)
{
	uint16_t config= (enable ? 1: 0);

    if (WRITE_AO_SINGLE_REGISTER(pin,AO_ENABLE,config))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.aoutCFG[idx_port].enabled = 1; 
  	    NovusConfig.applyConfig();
        return true;
    }
    return false;
}

bool ExpertClass::analogOutput_setPowerOnValue(const uint8_t pin, uint16_t poweronValue)
{

    if (WRITE_AO_SINGLE_REGISTER(pin,AO_PON_VALUE, poweronValue))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.aoutCFG[idx_port].pon_value = poweronValue; 
  	    NovusConfig.applyConfig();
        return true;
    }
    return false;
}

bool ExpertClass::analogOutput_setPowerOnState(const uint8_t pin, nx_aout_poweron_state_t state)
{
	uint16_t config;
    if (state == PO_AOUT_CONFIGURED_VALUE)
        config = 1;
    else if(state == PO_AOUT_LAST_VALID_VALUE) 
        config = 2;
    else if(state == PO_AOUT_DISABLED) 
        config = 0;
    else
        return false;

    if (WRITE_AO_SINGLE_REGISTER(pin,AO_PON_STATE, config))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.aoutCFG[idx_port].pon_state = state; 
  	    NovusConfig.applyConfig();
        return true;
    }
    return false;
}

bool ExpertClass::analogOutput_setSafeValue(const uint8_t pin,uint16_t safeValue)
{
    if (WRITE_AO_SINGLE_REGISTER(pin,AO_SAFE_VALUE,safeValue))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.aoutCFG[idx_port].watchdog_value = safeValue; 
  	    NovusConfig.applyConfig();
        return true;
    }
    return false;
}

bool ExpertClass::Modbus_configRS485(nx_modbus_baudrate_t baudrate, nx_modbus_parity_t parity, nx_modbus_stopbits_t stopbits)
{
    if(!WRITE_SINGLE_REGISTER(RS485_BAUDRATE,baudrate))
        return false;
    if(!WRITE_SINGLE_REGISTER(RS485_PARITY,parity))
        return false;
    if(!WRITE_SINGLE_REGISTER(RS485_STOPBIT,stopbits))
        return false;
  	NovusConfig.applyConfig();
    
    return true;
}

bool ExpertClass::digitalInput_setFunctionMode(const uint8_t pin, nx_din_function_t function)
{
    bool return_value = false;
    if(isDInPinNXprog(pin))
    {
        uint8_t idx_port = PIN_TO_PORT_INDEX(pin);
        NovusConfig.dinCFG[idx_port].read_ok = false;
        uint16_t config = (uint16_t) function;
        IndoorComm.send(FUNC_WRITESINGLE,(uint16_t)(NXprogRegisters::DI_FUNCTION+(50*(idx_port))),1,&config); 
        if(IndoorComm.res.error == 0)
        {
            NovusConfig.applyConfig();
            NovusConfig.dinCFG[idx_port].read_ok = true;
            return_value = true;
        }
    }
    return return_value;
}


ExpertClass NovusExpert;