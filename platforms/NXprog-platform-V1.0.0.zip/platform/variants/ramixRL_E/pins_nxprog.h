/*
  pins_nxprog.h - Pin definition functions for NXprog baseboard
  Based on Arduino - http://www.arduino.cc/

  Copyright (c) 2019 NOVUS Automation

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
*/
#ifndef Pins_NXprog_h
#define Pins_NXprog_h

/* -------------------------------------------------------------------------------------------
 *
 *                            DigiRail Ramix RL Definitions
 * 
 *    +----------------+----------------+----------------+----------------+----------------+
 *    |  Analog Input  |  Analog Output |  Digital Input | Digital Output |  Relay Output  |
 *    +----------------+----------------+----------------+----------------+----------------+
 *    |         2      |         2      |       4        |       x        |       2        |
 *    +----------------+----------------+----------------+----------------+----------------+
 * ----------------------------------------------------------------------------------------- */

#define NUM_DIGITAL_OUTPUT_RELAYS   2 // (virtual relay output ports)
#define DIGITAL_OUTPUT_PULSE_PIN    1 // Pulse operation (PWM, instantaneous, train, single) is supported in this port
#define NUM_DIGITAL_PINS            22 // (14 on digital headers + 8 on analog headers)

#define NXPROG_PIN_MASK        0x0F

#define NXPROG_AIN_PIN_BASE    0xA0
#define NX_A1   NXPROG_AIN_PIN_BASE + 1
#define NX_A2   NXPROG_AIN_PIN_BASE + 2

#define NXPROG_AOUT_PIN_BASE   0xB0
#define NX_O1   NXPROG_AOUT_PIN_BASE + 1
#define NX_O2   NXPROG_AOUT_PIN_BASE + 2

#define NXPROG_DIN_PIN_BASE    0xC0
#define NX_D1   NXPROG_DIN_PIN_BASE + 1
#define NX_D2   NXPROG_DIN_PIN_BASE + 2
#define NX_D3   NXPROG_DIN_PIN_BASE + 3
#define NX_D4   NXPROG_DIN_PIN_BASE + 4

#define NXPROG_DOUT_PIN_BASE   0xD0
#define NX_R1   NXPROG_DOUT_PIN_BASE + 1
#define NX_R2   NXPROG_DOUT_PIN_BASE + 2

#define isDInPinNXprog(pin)  ((pin & NXPROG_PIN_MASK) == NXPROG_DIN_PIN_BASE ? true : false)
#define isDOutPinNXprog(pin) ((pin & NXPROG_PIN_MASK) == NXPROG_DOUT_PIN_BASE ? true : false)
#define isAInPinNXprog(pin)  ((pin & NXPROG_PIN_MASK) == NXPROG_AIN_PIN_BASE ? true : false)
#define isAOutPinNXprog(pin) ((pin & NXPROG_PIN_MASK) == NXPROG_AOUT_PIN_BASE ? true : false)

#endif