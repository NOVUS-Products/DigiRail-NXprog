/*
 * Copyright (c) 2019, NOVUS Automation
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * 
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 * 
 * * Neither the name of Majenko Technologies nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "RTC.h"
#include "nxprog_rtc.h"

RTC_PCF2127 rtc;

void NXprogRTC::show_timedate() {
	DateTime now = rtc.now();
  dev->print(now.timestamp(DateTime::TIMESTAMP_FULL));
  dev->print(" ");
  dev->print(now.dayOfTheWeek());
}

void NXprogRTC::running_status() {
  if (! rtc.initialized()) 
    dev->println("RTC is NOT running!");
  else
    dev->println("RTC is running!");
}

void NXprogRTC::datetime (int year, int month, int day, int hour, int min, int sec) {
   rtc.adjust(DateTime(year, month, day, hour, min, sec));
}

void NXprogRTC::test_ram (){
  bool check = true;
  dev->println("Writing data....");
  for(uint16_t i = 0; i < PCF2127_STATIC_RAM_MAX_ADD; i++)
  {
    rtc.writenvram(i, (uint8_t)(i & 0xFF));
  }

  dev->println("Reading data....");
  uint8_t data;
  for(uint16_t i = 0; i < PCF2127_STATIC_RAM_MAX_ADD; i++)
  {
    data = rtc.readnvram(i);
    if(data != (uint8_t)(i & 0xFF))
    {
      dev->print("Error readind address: ");
      dev->println(i, HEX); 
      check = false;    
    }
  }

  if(check)
    dev->println("Ok!");
  else
    dev->println("FAILED !!!!!");
}


NXprogRTC::NXprogRTC(Stream *d) {
    dev = d;
}
