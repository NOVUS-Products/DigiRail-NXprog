/*
 * Copyright (c) 2019, NOVUS Automation
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * 
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 * 
 * * Neither the name of Majenko Technologies nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <Modbus.h>
#include "nxprog_modbus.h"

static RTC_PCF2127 rtc;
static int analog_input;

void NXprogModbus::terminate() {
  ModbusRTUServer.end();
}

bool NXprogModbus::init() {
	// start the Modbus RTU server, with (slave) id 42
	if (!ModbusRTUServer.begin(42, 9600)) {
		dev->println("Failed to start Modbus RTU Server!");
		while (1);
	}

	// configure coils at address 0x00
	ModbusRTUServer.configureCoils(0x00, numCoils);

	// configure discrete inputs at address 0x00
	ModbusRTUServer.configureDiscreteInputs(0x00, numDiscreteInputs);

	// configure holding registers at address 0x00
	ModbusRTUServer.configureHoldingRegisters(0x00, numHoldingRegisters);

	// configure input registers at address 0x00
	ModbusRTUServer.configureInputRegisters(0x00, numInputRegisters);
	
	return true;
}

void NXprogModbus::loop() {
	// poll for Modbus RTU requests
	ModbusRTUServer.poll();

	// map the coil values to the discrete input values
	for (int i = 0; i < numCoils; i++) {
		int coilValue = ModbusRTUServer.coilRead(i);

		ModbusRTUServer.discreteInputWrite(i, coilValue);
	}

	// map the holiding register values to the input register values
	for (int i = 0; i < numHoldingRegisters; i++) {
		long holdingRegisterValue = ModbusRTUServer.holdingRegisterRead(i);

		ModbusRTUServer.inputRegisterWrite(i, holdingRegisterValue);
	}
  _now = rtc.now();
  ModbusRTUServer.holdingRegisterWrite(0, _now.second());
  ModbusRTUServer.holdingRegisterWrite(1, _now.minute());
  ModbusRTUServer.holdingRegisterWrite(2, _now.hour());
  ModbusRTUServer.holdingRegisterWrite(3, _now.day());
  ModbusRTUServer.holdingRegisterWrite(4, _now.month());
  ModbusRTUServer.holdingRegisterWrite(5, _now.year());
  analog_input = analogRead(A1);
  ModbusRTUServer.holdingRegisterWrite(6, analog_input);
 }

NXprogModbus::NXprogModbus(Stream *d) {
    dev = d;
}
