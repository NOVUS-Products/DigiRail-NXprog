/*
 * Copyright (c) 2019, NOVUS Automation
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * 
 * * Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 * 
 * * Neither the name of Majenko Technologies nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "EEPROM.h"
#include "nxprog_eeprom.h"

E24LC256 eeprom;

void NXprogEEPROM::printHex(int num, int precision) 
{
  char tmp[16];
  char format[128];

  sprintf(format, "0x%%.%dX", precision);

  sprintf(tmp, format, num);
  dev->print(tmp);
}

void NXprogEEPROM::test(){
  bool check = true;
  dev->println("Writing data....");
  for(uint16_t i = 0; i < eeprom.length(); i++)
  {
    eeprom.writeByte(i, (uint8_t)(i & 0xFF));
  }

  dev->println("Reading data....");
  uint8_t data;
  for(uint16_t i = 0; i < eeprom.length(); i++)
  {
    data = eeprom.readByte(i);
    if(data != (uint8_t)(i & 0xFF))
    {
      dev->print("Error readind address: ");
      dev->println(i, HEX); 
      check = false;    
    }
  }

  if(check)
    dev->println("Ok!");
  else
    dev->println("FAILED !!!!!");
}

void NXprogEEPROM::write(int add, uint8_t value) {
    eeprom.writeByte(add, value); 
}

void NXprogEEPROM::read(int add) {
    dev->print("[");
    printHex(add, 4);
    dev->print("] : ");
    this->printHex(eeprom.readByte(add), 2);
    dev->println("");
}


NXprogEEPROM::NXprogEEPROM(Stream *d) {
    dev = d;
}
